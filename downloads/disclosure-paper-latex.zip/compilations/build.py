"""Compile the three root documents; keep all generated files in compilations."""
from pathlib import Path
import argparse,subprocess,os,json,hashlib,shutil
R=Path(__file__).resolve().parents[1];B=R/'compilations/current';B.mkdir(parents=True,exist_ok=True);parser=argparse.ArgumentParser();parser.add_argument('--document',choices=['paper','appendix','appendix_excess','all'],default='all');args=parser.parse_args();names=['paper','appendix','appendix_excess'] if args.document=='all' else [args.document];binary=Path(r'C:\Users\hia_n\AppData\Local\Programs\MiKTeX\miktex\bin\x64');env=os.environ.copy();env['BIBINPUTS']=str(R)+os.pathsep+env.get('BIBINPUTS','');records=[]
for name in names:
 commands=[[str(binary/'pdflatex.exe'),'--disable-installer','-interaction=nonstopmode','-halt-on-error','-output-directory='+str(B),name+'.tex'],[str(binary/'bibtex.exe'),str(B/name)],[str(binary/'pdflatex.exe'),'--disable-installer','-interaction=nonstopmode','-halt-on-error','-output-directory='+str(B),name+'.tex'],[str(binary/'pdflatex.exe'),'--disable-installer','-interaction=nonstopmode','-halt-on-error','-output-directory='+str(B),name+'.tex']]
 for i,command in enumerate(commands):
  if i==1 and '\\bibdata{' not in (B/(name+'.aux')).read_text(encoding='utf8',errors='replace'):continue
  p=subprocess.run(command,cwd=R,env=env,capture_output=True,text=True,errors='replace',timeout=120);(B/(name+f'-pass-{i+1}.txt')).write_text(p.stdout+p.stderr,encoding='utf8')
  if p.returncode:print((p.stdout+p.stderr)[-5000:]);raise SystemExit(p.returncode)
 log=(B/(name+'.log')).read_text(encoding='utf8',errors='replace');warnings=[line for line in log.splitlines() if 'Overfull' in line or ('undefined' in line.lower() and ('Citation' in line or 'references' in line))];pdf=B/(name+'.pdf');records.append({'source':name+'.tex','PDF':str(pdf.relative_to(R)),'source_SHA256':hashlib.sha256((R/(name+'.tex')).read_bytes()).hexdigest(),'PDF_SHA256':hashlib.sha256(pdf.read_bytes()).hexdigest(),'warnings':warnings})
(B/'build-manifest.json').write_text(json.dumps(records,indent=2),encoding='utf8');print(json.dumps(records))
