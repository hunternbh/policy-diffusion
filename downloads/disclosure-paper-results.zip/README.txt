Disclosure regulation: aggregate analysis bundle

Primary scope: ten identified public-disclosure families; eight support the
following year and six the longer window. Confidential and broader categories
are separate sensitivities. All reported signs and failed estimates are kept.

Tables and country-cohort rows contain aggregate public research outputs.
The licensed Datastream security panel, issuer mapping, original third-party
papers and Worldscope exports are not redistributed. Full reconstruction of
the company samples and event profiles requires authorised access to the
project inputs at the paths documented in the scripts. Saved family weights
and country influences allow reconstruction of the reported pooled estimates.
The JSON analysis plan records retrospective choices; it is not preregistration.
See submission-readiness.txt for unresolved historical and design issues.
