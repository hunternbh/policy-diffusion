from pathlib import Path
source=Path('work/design-audit/fit_jibs.py').read_text(encoding='utf8');source=source.replace("O=R/'26-adoption-weighting-and-design-audit/2026-10-19'","O=R/'27-literature-and-regression-paper/2026-10-21'")
Path('work/jar-paper/fit_public_diffusion.py').write_text(source,encoding='utf8')
