from pathlib import Path
import subprocess
subprocess.run([r'C:\poppler-24.02.0\Library\bin\pdftoppm.exe','-scale-to','1350','-png',str(Path('tmp/latex-paper/paper.pdf').resolve()),str(Path('outputs/latex-paper-page').resolve())],check=True)
