from pathlib import Path
import sys,json,html,hashlib,shutil
sys.path.insert(0,'work/empirical-deps')
import pandas as pd,numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,Image,PageBreak,KeepTogether
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from pypdf import PdfReader
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'27-literature-and-regression-paper/2026-10-21';doc=json.loads((O/'paper/manuscript-prose.json').read_text(encoding='utf8'));tables=json.loads((O/'paper/tables.json').read_text(encoding='utf8'));F=pd.read_csv(O/'tables/main-family-estimates.csv');W=pd.read_csv(O/'tables/main-family-weights.csv');E=pd.read_csv(O/'tables/public-event-profiles.csv');L=pd.read_csv(O/'tables/diffusion-country-family-FE.csv');scope=set(json.loads((O/'analysis-plan.json').read_text(encoding='utf8'))['headline_families']);labels={'AUDIT_REPORTING':'Auditor reporting','CBCR_BANK_PUBLIC':'Public bank country reports','CBCR_PUBLIC':'Public multinational country reports','CLIMATE_DISCLOSURE':'Climate / emissions disclosure','ESG_MANDATORY_REVIEWED':'Nonfinancial reporting','EXTRACTIVE_PAYMENTS':'Payments to governments','IFRS':'IFRS financial reporting','SUPPLY_CHAIN':'Supply-chain reporting','SUSTAINABILITY_FINANCIAL':'Financial-focus sustainability','XBRL':'Electronic financial reporting'};outs=['log_spread','log_impact','zero_fraction'];labs=['Log spread','Log price impact','Zero-return share'];schemes=['equal_family','baseline_market_cap_family'];palette=['#23695e','#a77940']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8.5,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','svg.hashsalt':'disclosure-paper-20261021'})
def save(fig,name):
 for ext in ['png','svg']:
  p=O/'figures'/(name+'.'+ext);fig.savefig(p,dpi=210,bbox_inches='tight',metadata={'Date':None} if ext=='svg' else None)
  if ext=='svg':p.write_text('\n'.join(line.rstrip() for line in p.read_text(encoding='utf8').splitlines())+'\n',encoding='utf8')
 plt.close(fig)
ff=F[F.outcome.eq('log_spread')&F.post_window.eq('first_year')&F.family.isin(scope)].set_index('family');ww=W[W.scope.eq('public_disclosure')&W.outcome.eq('log_spread')&W.post_window.eq('first_year')&W.family_weight.eq('baseline_market_cap_family')].set_index('family');order=list(ff.sort_values('estimate').index);y=np.arange(len(order));fig,ax=plt.subplots(1,2,figsize=(10.8,4.8),sharey=True,gridspec_kw={'width_ratios':[3,1]});ax[0].errorbar(ff.loc[order,'estimate'],y,xerr=1.96*ff.loc[order,'country_se'],fmt='o',color=palette[0],capsize=2);ax[0].axvline(0,color='#888',lw=.7);ax[0].set_yticks(y,[labels[f] for f in order]);ax[0].set_xlabel('Following-year log spread change');ax[1].barh(y,100*ww.loc[order,'weight'],color=palette[1]);ax[1].axvline(100/len(order),ls='--',color='#666',lw=.8);ax[1].set_xlabel('Market-cap weight (%)');fig.tight_layout();save(fig,'disclosure-family-effects')
fig,axes=plt.subplots(1,3,figsize=(10.8,3.4))
for ax,out,lab in zip(axes,outs,labs):
 for w,col,label in zip(schemes,palette,['Equal family','Market-cap family']):
  z=E[E.outcome.eq(out)&E.across_weight.eq(w)];z=pd.concat([z,pd.DataFrame([{'event_time':-1,'estimate':0.,'conditional_ci_low':0.,'conditional_ci_high':0.}])]).sort_values('event_time');x=z.event_time.to_numpy();ax.plot(x,z.estimate.to_numpy(),'o-',color=col,label=label,lw=1.4,ms=3);ax.fill_between(x,z.conditional_ci_low.to_numpy(),z.conditional_ci_high.to_numpy(),color=col,alpha=.1)
 ax.axhline(0,color='#888',lw=.6);ax.axvline(-.5,color='#888',ls='--',lw=.6);ax.set_title(lab);ax.set_xticks([-3,-2,-1,0,1,2,3]);ax.set_xlabel('Years from implementation')
axes[0].legend(frameon=False,fontsize=7);fig.tight_layout();save(fig,'disclosure-event-profiles')
fig,axes=plt.subplots(2,2,figsize=(10.5,6.5));mechs=['trade_fixed2000','gdp_learning_known_universe','language','financial_dependence'];mlabs=['Competition: per 10pp peer adoption','Learning: binary GDP-growth comparison','Language peers: per 10pp adoption','External finance: per 1pp GDP']
for ax,term,lab in zip(axes.ravel(),mechs,mlabs):
 for j,fe in enumerate(['country_family_and_year','country_family_and_family_year']):
  for k,(w,col) in enumerate(zip(schemes,palette)):
   z=L[L.model.eq('separate_status_event')&L.term.eq(term)&L.fixed_effects.eq(fe)&L.family_weight.eq(w)].iloc[0]
   if z.status=='estimated':ax.errorbar(z.estimate,j+(k-.5)*.18,xerr=np.array([[z.estimate-z.ci_low],[z.ci_high-z.estimate]]),fmt='o',color=col,capsize=2,label=['Equal family','Market-cap family'][k] if j==0 else None)
 ax.axvline(0,color='#888',lw=.7);ax.set_yticks([0,1],['Country-family + year','Country-family + family-year']);ax.set_ylim(1.45,-.45);ax.set_title(lab,fontsize=9);ax.set_xlabel('Adoption-status probability-point association')
axes[0,0].legend(frameon=False,fontsize=7);fig.tight_layout();save(fig,'disclosure-diffusion-comparison')
for name,file in [('TR','times.ttf'),('TB','timesbd.ttf'),('TI','timesi.ttf')]:pdfmetrics.registerFont(TTFont(name,str(Path('C:/Windows/Fonts')/file)))
body=ParagraphStyle('Body',fontName='TR',fontSize=11,leading=15,spaceAfter=9,firstLineIndent=14);abstract=ParagraphStyle('Abstract',parent=body,fontSize=10.5,leading=14,firstLineIndent=0);small=ParagraphStyle('Small',fontName='TR',fontSize=8.3,leading=10.6,spaceAfter=6);head=ParagraphStyle('Head',fontName='TB',fontSize=12,leading=15,spaceBefore=14,spaceAfter=9,keepWithNext=True);sub=ParagraphStyle('Sub',parent=head,fontName='TI',fontSize=11,spaceBefore=10);title=ParagraphStyle('Title',fontName='TB',fontSize=20,leading=24,spaceAfter=18,alignment=1);centre=ParagraphStyle('Centre',parent=abstract,alignment=1,spaceAfter=12);cell=ParagraphStyle('Cell',fontName='TR',fontSize=7.8,leading=9.6)
def p(x,style=body):return Paragraph(html.escape(str(x)).replace('\n','<br/>').replace('–','-').replace('—','-').replace('−','-'),style)
story=[Spacer(1,55),p(doc['title'],title),p(doc['author'],centre),p(doc['date'],centre),Spacer(1,20),p('Abstract',head),p(doc['abstract'],abstract),Spacer(1,15),p('Keywords: disclosure regulation; stock liquidity; international reporting; policy diffusion',small),p('Research working paper',centre),PageBreak()]
for section in doc['sections']:
 story.append(p(section['heading'],head))
 for text in section['paragraphs']:
  style=sub if len(text)<100 and text[:1].isdigit() and text.count('.')>=2 else body
  story.append(p(text,style))
story.extend([PageBreak(),p('References',head)])
for r in sorted(doc['references'],key=lambda r:r['citation']):story.append(p(r['citation']+'. '+r['title']+'. '+r['publication']+'. '+r['primary_url'],small))
def tab(rows,columns,widths,padding=4):
 data=[[p(x,cell) for x in columns]]+[[p(x,cell) for x in r] for r in rows];v=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT');v.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LINEABOVE',(0,0),(-1,0),.8,colors.black),('LINEBELOW',(0,0),(-1,0),.5,colors.black),('LINEBELOW',(0,-1),(-1,-1),.7,colors.black),('TOPPADDING',(0,0),(-1,-1),padding),('BOTTOMPADDING',(0,0),(-1,-1),padding),('LEFTPADDING',(0,0),(-1,-1),4),('RIGHTPADDING',(0,0),(-1,-1),4)]));return v
for t in tables:
 story.extend([PageBreak(),p(f'Table {t["number"]}. '+t['title'],head)])
 nc=len(t['columns']);widths=[130,62,62,62,62,62,64] if nc==7 else [170,66,81,91,96] if t['number']==2 else [180,48,92,92,92] if t['number']==5 else [150,88,133,133] if nc==4 else [144,90,90,90,90]
 story.extend([tab(t['rows'],t['columns'],widths,2.5 if t['number']==12 else 4),Spacer(1,9),p(t['note'],small)])
 for panel in t.get('panels',[]):story.extend([Spacer(1,10),p(panel['title'],sub),tab(panel['rows'],panel['columns'],[210]+[(504-210)/(len(panel['columns'])-1)]*(len(panel['columns'])-1))])
figures=[('disclosure-family-effects','Figure 1. Public-disclosure family estimates and weights','Following-year GDP-weighted country comparisons. All eight supported families are shown. Bars are 95% normal-reference conditional country intervals. Right panel: sampled pre-policy market-cap masses, normalised across these families; dashed line is equal family weight. Each family has its own supported countries and cohorts.',258),('disclosure-event-profiles','Figure 2. Public-disclosure liquidity before and after implementation',f'Five public-disclosure families on fixed company support in years -3 through +3. Year -1 is the reference. Pointwise 95% conditional country intervals are shaded. The sample differs from the eight-family short window and six-family longer-window main samples. Pre-policy differences and common legal waves limit a causal interpretation.',178),('disclosure-diffusion-comparison','Figure 3. Diffusion associations and common policy waves','Separate adoption-status linear probability models under both family weights. Compare country-family plus common year effects with country-family plus family-year effects on identical rows. Horizontal intervals are 95% country-clustered t intervals. Predictor units differ by panel and are stated in each heading. A change across fixed-effect structures is not evidence that either coefficient is causal.',315)]
story.append(PageBreak())
for k,(name,heading,note,height) in enumerate(figures):
 if k==2:story.append(PageBreak())
 story.extend([p(heading,head),Image(str(O/'figures'/(name+'.png')),width=504,height=height,kind='proportional'),p(note,small),Spacer(1,10)])
def footer(c,d):c.setFont('TR',8);c.setFillColor(colors.HexColor('#555'));c.drawString(54,28,'Disclosure regulation, liquidity, and international diffusion');c.drawRightString(558,28,str(d.page))
pdf=O/'paper/disclosure-regulation-paper.pdf';SimpleDocTemplate(str(pdf),pagesize=letter,leftMargin=54,rightMargin=54,topMargin=43,bottomMargin=47,title=doc['title'],author=doc['author']).build(story,onFirstPage=footer,onLaterPages=footer)
reader=PdfReader(pdf);pages=[page.extract_text() for page in reader.pages];snapshot={'pages':len(pages),'prose_words':len((doc['abstract']+' '+' '.join(' '.join(s['paragraphs']) for s in doc['sections'])).split()),'references':len(doc['references']),'tables':len(tables),'estimated_regression_tables':sum(t['is_regression_table'] for t in tables),'figures':3,'PDF_sha256':hashlib.sha256(pdf.read_bytes()).hexdigest(),'table_pages':{str(t['number']):[i+1 for i,s in enumerate(pages) if f'Table {t["number"]}. '+t['title'] in s] for t in tables},'figure_notes':[{'name':n,'title':h,'note':x} for n,h,x,_ in figures]};(O/'paper/paper-data-snapshot.json').write_text(json.dumps(snapshot,indent=2),encoding='utf8')
out=Path('outputs');out.mkdir(exist_ok=True)
for src,dst in [(pdf,out/'disclosure-regulation-paper.pdf'),(O/'paper/manuscript-draft.txt',out/'disclosure-regulation-manuscript.txt'),(O/'paper/manuscript-prose.json',out/'disclosure-regulation-manuscript.json')]:shutil.copy2(src,dst)
print(json.dumps(snapshot))
