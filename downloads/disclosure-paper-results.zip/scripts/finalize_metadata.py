from pathlib import Path
import json
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'27-literature-and-regression-paper/2026-10-21'
p=Path('work/jar-paper/build_pdf.py');s=p.read_text(encoding='utf8').replace('def tab(rows,columns,widths):','def tab(rows,columns,widths,padding=4):').replace("('TOPPADDING',(0,0),(-1,-1),4)","('TOPPADDING',(0,0),(-1,-1),padding)").replace("('BOTTOMPADDING',(0,0),(-1,-1),4)","('BOTTOMPADDING',(0,0),(-1,-1),padding)").replace("tab(t['rows'],t['columns'],widths)","tab(t['rows'],t['columns'],widths,2.5 if t['number']==12 else 4)");p.write_text(s,encoding='utf8')
p=Path('work/jar-paper/public_events.py');s=p.read_text(encoding='utf8').replace("'families_attempted':17","'families_attempted':len(famnames)");p.write_text(s,encoding='utf8')
for p in (O/'event-diagnostics/audit').glob('*summary.json'):
 d=json.loads(p.read_text(encoding='utf8'))
 if 'families_attempted' in d:d['families_attempted']=10;p.write_text(json.dumps(d,indent=2),encoding='utf8')
p=O/'literature/literature-evidence-matrix.json';d=json.loads(p.read_text(encoding='utf8'))
records=d if isinstance(d,list) else d.get('records',[])
for r in records:
 if r.get('citation')=='Healy and Palepu (2001)':r['primary_url']='https://doi.org/10.1016/S0165-4101(01)00018-0'
p.write_text(json.dumps(d,indent=2,ensure_ascii=False),encoding='utf8')
p=O/'literature/search-protocol-and-novelty.json';d=json.loads(p.read_text(encoding='utf8'));d['curated_literature_records']=len(records);p.write_text(json.dumps(d,indent=2),encoding='utf8')
p=Path('work/jar-paper/assemble_tables.py');s=p.read_text(encoding='utf8').replace("'Does disclosure regulation generally change liquidity?',commoncols,rows","'Does disclosure regulation generally change liquidity?',[commoncols[0],'Families',*commoncols[2:]],rows")
# Balance descriptions must use cohorts retained by the matched regressions.
s=s.replace("B=B[B.family.isin(scope)];br=[]", "BM=pd.read_csv(O/'audit/country-cohort-memberships.csv');BM=BM[BM.model.eq('matching_nearest_three')&BM.family.isin(scope)][['family','cohort']].drop_duplicates();B=B.merge(BM,on=['family','cohort'],validate='many_to_one');br=[]")
p.write_text(s,encoding='utf8')
print('Metadata, table precision and layout updated.')
