from pathlib import Path
import shutil
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'27-literature-and-regression-paper/2026-10-21'
for src,dst in [('issuer-exposure-pooled-events.csv','public-event-profiles.csv'),('issuer-exposure-principal-estimates.csv','public-event-principal.csv')]:shutil.copy2(O/'event-diagnostics/tables'/src,O/'tables'/dst)
