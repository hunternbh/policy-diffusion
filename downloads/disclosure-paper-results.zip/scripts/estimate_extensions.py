"""Declared cross sections and matched country-cohort WLS; no sign selection."""
import os
for k in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys,json,itertools
sys.path.insert(0,'work/empirical-deps')
import pandas as pd,numpy as np
from scipy.stats import t
from statsmodels.stats.multitest import multipletests
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'27-literature-and-regression-paper/2026-10-21';P=R/'26-adoption-weighting-and-design-audit/2026-10-19';plan=json.loads((O/'analysis-plan.json').read_text(encoding='utf8'));C=pd.read_csv(P/'data/reviewed-policy-calendar.csv');raw=pd.read_parquet(R/'09-expanded-policy-paper/2026-10-18/data/security-year-liquidity.parquet');mapping=pd.read_parquet(R/'17-issuer-regulation-expansion/2026-10-19/data/all-annual-company-mapping.parquet');raw=raw.merge(mapping[['security_id','year','dscompcode']].drop_duplicates(['security_id','year']),on=['security_id','year'],validate='one_to_one');outs=['log_spread','log_impact','zero_fraction'];isos=sorted(raw.iso3.unique());ix={c:j for j,c in enumerate(isos)};K=len(isos);annual={int(y):z for y,z in raw.groupby('year')};macro=pd.read_csv(P/'data/macro-country-year.csv').merge(pd.read_csv(P/'data/JIBS-domestic-controls.csv')[['iso3','year','reg_quality','stock_market_cap_gdp_pct']],on=['iso3','year'],validate='one_to_one').set_index(['iso3','year']);cache={};coefs=[];members=[];balance=[];countrydata=[];poolrows=[];familyrows=[];allinfs={}
def panel(g):
 if g in cache:return cache[g]
 pre=annual[g-1].query('market_cap_usd>0').sort_values(['dscompcode','market_cap_usd','security_id'],ascending=[True,False,True]).drop_duplicates('dscompcode');post=annual[g+1];z=pre.merge(post[['security_id','dscompcode','iso3']+outs],on=['security_id','dscompcode','iso3'],suffixes=('_pre','_post'),validate='one_to_one').replace([np.inf,-np.inf],np.nan).dropna(subset=[v+'_'+s for v in outs for s in ['pre','post']]);z=z[z.groupby('iso3').security_id.transform('size').ge(30)]
 for out in outs:z[out]=z[out+'_post']-z[out+'_pre']
 a=z.groupby('iso3')[outs+[v+'_pre' for v in outs]].mean();a['companies']=z.groupby('iso3').size();a['cap']=z.groupby('iso3').market_cap_usd.sum();a['g']=g
 for col in ['gdp_constant_usd','gdp_pc_constant','gdp_growth_pct','trade_gdp_pct','reg_quality','stock_market_cap_gdp_pct']:a[col]=[macro.loc[(i,g-1),col] if (i,g-1) in macro.index else np.nan for i in a.index]
 a['ln_gdp_pc']=np.log(a.gdp_pc_constant.where(a.gdp_pc_constant.gt(0)));a['country_index']=[ix[i] for i in a.index];a=a[a.gdp_constant_usd.gt(0)];cache[g]=a;return a
def fit(a,out,mode,moderator=None,custom_weights=None):
 X=pd.DataFrame({'constant':1.,'treated':a.Treat},index=a.index)
 if mode=='controlled':
  for col in ['ln_gdp_pc','gdp_growth_pct','trade_gdp_pct']:
   sd=a[col].std(ddof=0)
   if sd<=1e-10:return None
   X[col]=(a[col]-a[col].mean())/sd
 if moderator:
  sd=a[moderator].std(ddof=0)
  if sd<=1e-10:return None
  X['moderator']=(a[moderator]-a[moderator].mean())/sd;X['treated_x_moderator']=a.Treat*X.moderator
 n,k=X.shape
 if n<k+3 or np.linalg.matrix_rank(X.to_numpy())<k:return None
 w=a.gdp_constant_usd.to_numpy(float).copy() if custom_weights is None else custom_weights.copy();w/=w.mean();xx=X.to_numpy(float);y=a[out].to_numpy();bread=np.linalg.inv(xx.T@(w[:,None]*xx));beta=bread@(xx.T@(w*y));res=y-xx@beta;infl=(xx@bread)*(w*res*np.sqrt(n/(n-k)))[:,None];infs=np.zeros((k,K));infs[:,a.country_index.astype(int)]=infl.T;r2=1-float(np.dot(w,res*res))/float(np.dot(w,(y-np.average(y,weights=w))**2)) if np.std(y)>0 else np.nan
 return {'beta':dict(zip(X.columns,beta)),'influence':dict(zip(X.columns,infs)),'rows':n,'treated_countries':set(a.index[a.Treat.eq(1)]),'comparison_countries':set(a.index[a.Treat.eq(0)]),'mass':float(a.loc[a.Treat.eq(1),'gdp_constant_usd'].sum()),'cap':float(a.loc[a.Treat.eq(1),'cap'].sum()),'r_squared':r2,'sample':a}
def infer(value,inf):
 nc=int(np.count_nonzero(abs(inf)>1e-13));se=float(np.linalg.norm(inf));crit=t.ppf(.975,max(1,nc-1));p=2*t.sf(abs(value/se),max(1,nc-1)) if se>1e-14 else 1.
 return {'estimate':float(value),'country_se':se,'ci_low':float(value-crit*se),'ci_high':float(value+crit*se),'p_value':float(p),'influence_countries':nc}
def record(label,fam,g,out,res,moderator=None):
 if res is None:return
 for term,value in res['beta'].items():coefs.append({'model':label,'family':fam,'cohort':g,'outcome':out,'term':term,'coefficient':float(value),'rows':res['rows'],'r_squared':res['r_squared']})
 for iso in res['sample'].index:members.append({'model':label,'family':fam,'cohort':g,'outcome':out,'iso3':iso,'treated':int(res['sample'].loc[iso,'Treat'])})
def pool(label,out,results,term):
 fits=[]
 for fam,rr in results.items():
  if fam not in plan.get('headline_families',families):continue
  if not rr:continue
  cm=np.array([r['mass'] for r in rr]);cm/=cm.sum();b=sum(w*r['beta'][term] for w,r in zip(cm,rr));inf=sum(w*r['influence'][term] for w,r in zip(cm,rr));cap=sum(r['cap'] for r in rr);tr=set.union(*(r['treated_countries'] for r in rr));co=set.union(*(r['comparison_countries'] for r in rr));row={'model':label,'outcome':out,'term':term,'family':fam,'cohorts':len(rr),'country_cohort_rows':sum(r['rows'] for r in rr),'treated_countries':len(tr),'comparison_countries':len(co),'cap_mass':cap,**infer(b,inf)};familyrows.append(row);fits.append((fam,row,inf,tr,co))
 for scheme in ['equal_family','baseline_market_cap_family']:
  base={'model':label,'outcome':out,'term':term,'family_weight':scheme,'families':len(fits),'status':'estimated' if fits else 'insufficient_support'}
  if fits:
   mass=np.ones(len(fits)) if scheme=='equal_family' else np.array([v[1]['cap_mass'] for v in fits]);mass/=mass.sum();value=sum(w*v[1]['estimate'] for w,v in zip(mass,fits));inf=sum(w*v[2] for w,v in zip(mass,fits));base.update(**infer(value,inf),country_cohort_rows=sum(v[1]['country_cohort_rows'] for v in fits),treated_countries=len(set.union(*(v[3] for v in fits))),comparison_countries=len(set.union(*(v[4] for v in fits))));allinfs[(label,out,term,scheme)]=inf
  poolrows.append(base)
mods=['pre_own_outcome','reg_quality','stock_market_cap_gdp_pct','ln_gdp_pc','trade_gdp_pct'];families=sorted(C.regulation_family.unique());allfits={}
for fam in families:
 ev=C[C.regulation_family.eq(fam)];dates=ev.set_index('iso3').reviewed_G
 for g in sorted(ev.reviewed_G.astype(int).unique()):
  if g<2001 or g>2024:continue
  a=panel(g).copy();a['G']=a.index.map(dates);a=a[a.G.eq(g)|a.G.gt(g+1)]
  if g+1>=2025 and fam in ['BENEFICIAL_OWNERSHIP','SUPPLY_CHAIN']:a=a.drop(index='USA' if fam=='BENEFICIAL_OWNERSHIP' else 'DEU',errors='ignore')
  a['Treat']=a.G.eq(g).astype(float)
  if a.Treat.sum()<1 or (1-a.Treat).sum()<3:continue
  countrydata.extend({'family':fam,'cohort':g,'iso3':iso,**{col:float(v) for col,v in row.items()}} for iso,row in a.iterrows())
  for out in outs:
   b=a.dropna(subset=['ln_gdp_pc','gdp_growth_pct','trade_gdp_pct']);pair=[]
   if b.Treat.sum()>=1 and (1-b.Treat).sum()>=3:
    for mode in ['uncontrolled','controlled']:pair.append(fit(b,out,mode))
   if len(pair)==2 and all(r is not None for r in pair):
    for name,r in zip(['paired_no_controls','paired_controls'],pair):allfits.setdefault((name,out),{}).setdefault(fam,[]).append(r);record(name,fam,g,out,r)
   for mod in mods:
    col=out+'_pre' if mod=='pre_own_outcome' else mod;b=a.dropna(subset=[col])
    if b.Treat.sum()<2 or (1-b.Treat).sum()<6:continue
    r=fit(b,out,'interaction',col)
    if r is not None:name='interaction_'+mod;allfits.setdefault((name,out),{}).setdefault(fam,[]).append(r);record(name,fam,g,out,r,col)
  fields=['ln_gdp_pc','trade_gdp_pct']+[v+'_pre' for v in outs];b=a.dropna(subset=fields)
  if b.Treat.sum()<1 or (1-b.Treat).sum()<3:continue
  xx=b[fields].to_numpy();cov=np.cov(xx,rowvar=False);ridge=1e-6*np.trace(cov)/len(fields);inv=np.linalg.inv(cov+np.eye(len(fields))*max(ridge,1e-12));tr=np.flatnonzero(b.Treat.eq(1));co=np.flatnonzero(b.Treat.eq(0));mw=np.zeros(len(b));mw[tr]=b.iloc[tr].gdp_constant_usd.to_numpy()
  for j in tr:
   delta=xx[co]-xx[j];dist=np.einsum('ij,jk,ik->i',delta,inv,delta);chosen=co[np.argsort(dist,kind='stable')[:3]];mw[chosen]+=b.iloc[j].gdp_constant_usd/3
  for col in fields:
   sd=b[col].std(ddof=0);treated=np.average(b.iloc[tr][col],weights=b.iloc[tr].gdp_constant_usd);before=np.average(b.iloc[co][col],weights=b.iloc[co].gdp_constant_usd);after=np.average(b.iloc[co][col],weights=mw[co]);balance.append({'family':fam,'cohort':g,'variable':col,'before_standardised_difference':(treated-before)/sd,'after_standardised_difference':(treated-after)/sd,'treated_countries':len(tr),'available_controls':len(co),'selected_controls':int((mw[co]>0).sum())})
  used=mw>0
  for out in outs:
   rr=[fit(b,out,'uncontrolled'),fit(b.iloc[np.flatnonzero(used)],out,'matched',custom_weights=mw[used])]
   if all(v is not None for v in rr):
    for name,r in zip(['matching_eligible_unmatched','matching_nearest_three'],rr):allfits.setdefault((name,out),{}).setdefault(fam,[]).append(r);record(name,fam,g,out,r)
for (label,out),rr in allfits.items():
 for term in (['treated','treated_x_moderator'] if label.startswith('interaction_') else ['treated']):pool(label,out,rr,term)
# Explicitly retain planned unsupported pooled cells.
for label,out,term,scheme in itertools.product(['paired_no_controls','paired_controls','matching_eligible_unmatched','matching_nearest_three']+['interaction_'+m for m in mods],outs,['treated','treated_x_moderator'],['equal_family','baseline_market_cap_family']):
 if term=='treated_x_moderator' and not label.startswith('interaction_'):continue
 if not any(r['model']==label and r['outcome']==out and r['term']==term and r['family_weight']==scheme for r in poolrows):poolrows.append({'model':label,'outcome':out,'term':term,'family_weight':scheme,'families':0,'status':'insufficient_support'})
T=pd.DataFrame(poolrows);T['holm_new_family_p']=np.nan;ok=T.status.eq('estimated');pv=T.p_value.fillna(1).to_numpy();T.loc[ok,'holm_new_family_p']=multipletests(pv,method='holm')[1][ok];T.to_csv(O/'tables/new-liquidity-regressions.csv',index=False);pd.DataFrame(familyrows).to_csv(O/'tables/new-liquidity-family-regressions.csv',index=False);pd.DataFrame(coefs).to_csv(O/'audit/all-cohort-WLS-coefficients.csv',index=False);pd.DataFrame(members).to_csv(O/'audit/country-cohort-memberships.csv',index=False);pd.DataFrame(countrydata).to_csv(O/'data/country-cohort-regression-inputs.csv',index=False);pd.DataFrame(balance).to_csv(O/'tables/matching-balance.csv',index=False)
IF=pd.DataFrame([{'model':a,'outcome':b,'term':c,'family_weight':d,'iso3':iso,'influence':float(v)} for (a,b,c,d),inf in allinfs.items() for iso,v in zip(isos,inf)]);IF.to_csv(O/'audit/pooled-country-influences.csv',index=False)
summary={'attempted_new_focal_coefficients':len(T),'estimated':int(ok.sum()),'unsupported':int((~ok).sum()),'Holm_below_05':int(T.holm_new_family_p.lt(.05).sum()),'cohort_regression_coefficients':len(coefs),'raw_country_cohort_rows':len(countrydata),'matching_covariate_cells':len(balance),'inference':'95% t country-influence intervals; fixed-calendar and fixed-match conditional, not full law-assignment uncertainty.'};(O/'audit/new-liquidity-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary))
