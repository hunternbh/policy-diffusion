from pathlib import Path
import sys,json
sys.path.insert(0,'work/empirical-deps')
import pandas as pd,numpy as np
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'27-literature-and-regression-paper/2026-10-21';P=R/'26-adoption-weighting-and-design-audit/2026-10-19';plan=json.loads((O/'analysis-plan.json').read_text(encoding='utf8'));scope=set(plan['headline_families']);Q=pd.read_csv(O/'tables/main-liquidity.csv');F=pd.read_csv(O/'tables/main-family-estimates.csv');N=pd.read_csv(O/'tables/new-liquidity-regressions.csv');D=pd.read_csv(O/'tables/JIBS-aligned-diffusion-models.csv');L=pd.read_csv(O/'tables/diffusion-country-family-FE.csv');A=pd.read_csv(O/'data/country-cohort-regression-inputs.csv');E=pd.read_csv(P/'event-diagnostics/tables/issuer-exposure-pooled-events.csv');C=pd.read_csv(P/'data/reviewed-policy-calendar.csv');outs=['log_spread','log_impact','zero_fraction'];olabs={'log_spread':'Log spread','log_impact':'Log price impact','zero_fraction':'Zero-return share'};schemes=['equal_family','baseline_market_cap_family'];labels={'AUDIT_REPORTING':'Auditor reporting','CBCR_BANK_PUBLIC':'Public bank country reports','CBCR_CONFIDENTIAL':'Confidential tax country reports','CBCR_PUBLIC':'Public multinational country reports','CLIMATE_DISCLOSURE':'Climate / emissions disclosure','ESG_MANDATORY_REVIEWED':'Nonfinancial reporting','EXTRACTIVE_PAYMENTS':'Payments to governments','IFRS':'IFRS financial reporting','SUPPLY_CHAIN':'Supply-chain reporting','SUSTAINABILITY_FINANCIAL':'Financial-focus sustainability','XBRL':'Electronic financial reporting'};mechs={'trade_fixed2000':'Competition','gdp_learning_known_universe':'Learning','language':'Emulation','financial_dependence':'External finance'};tables=[]
def add(title,cols,rows,note,reg=False,panels=None):
 t={'number':len(tables)+1,'title':title,'columns':cols,'rows':rows,'note':note,'is_regression_table':reg}
 if panels:t['panels']=panels
 tables.append(t)
def cell(r,se='country_se',adj='holm_new_family_p',digits=3):
 if r.get('status','estimated')!='estimated':return 'Not estimated'
 value=r.get('estimate',np.nan);err=r.get(se,np.nan);q=r.get(adj,np.nan)
 fmt=lambda x,sign=False: f'{x:+.2e}' if sign and 0<abs(x)<.5*10**(-digits) else f'{x:.2e}' if not sign and 0<abs(x)<.5*10**(-digits) else format(x,('+' if sign else '')+f'.{digits}f')
 return fmt(value,True)+'\n('+fmt(err)+')'+(('\nq<0.001' if q<.001 else f'\nq={q:.3f}') if np.isfinite(q) else '')
def pick(model,out,term,scheme):return N[N.model.eq(model)&N.outcome.eq(out)&N.term.eq(term)&N.family_weight.eq(scheme)].iloc[0]
def simple_rows(models,interaction=False):
 rr=[]
 for model,title in models:
  for out in outs:
   for term,term_label in ([('treated','Treatment at mean'),('treated_x_moderator','Treatment x moderator')] if interaction else [('treated','Treatment')]):
    z=[pick(model,out,term,w) for w in schemes];r=z[0];rr.append([title+'\n'+olabs[out]+'\n'+term_label,f'{int(r.families)} / {int(r.country_cohort_rows)}',*[cell(v,digits=4 if out=='zero_fraction' else 3) for v in z]])
 return rr
commoncols=['Outcome and coefficient','Families /\ncountry-cohort rows','Equal family\nCoefficient (SE), q','Market-cap family\nCoefficient (SE), q']
commonnote='Country-cohort WLS, prior-year GDP within families. Parentheses are conditional country-influence standard errors; q is Holm-adjusted p across all 108 newly declared focal coefficients, including audience diagnostics. Each weighting pair uses identical family estimates. Family and country support may differ across rows. These are exploratory comparisons, not policy-assignment or causal-mechanism inference.'
# Sample moments refer to observed stock-year inputs, not country pseudo-replication.
raw=pd.read_parquet(R/'09-expanded-policy-paper/2026-10-18/data/security-year-liquidity.parquet');moments=[]
for col in outs:
 z=raw[col].replace([np.inf,-np.inf],np.nan).dropna();moments.append([olabs[col],f'{len(z):,}',*[f'{v:.4f}' for v in [z.mean(),z.std(),*z.quantile([.25,.5,.75]).tolist()]]])
add('Sample and liquidity measures',['Measure','Stock-years','Mean','SD','P25','Median','P75'],moments,'Datastream security-year inventory: 1,055,142 observations, 99,100 vendor company records and 90 jurisdictions, 2000-2025. All three measures are jointly available for 636,960 stock-years in 86 jurisdictions. Estimation uses fixed company cohorts and smaller documented country comparisons. Higher values indicate less liquidity. Logs and fractions are not percentage changes.')
W=pd.read_csv(O/'tables/main-family-weights.csv');z=W[W.scope.eq('public_disclosure')&W.outcome.eq('log_spread')&W.post_window.eq('first_year')&W.family_weight.eq('baseline_market_cap_family')].set_index('family');inst=[]
for fam in plan['all_disclosure_families']:
 ev=C[C.regulation_family.eq(fam)&C.reviewed_G.le(2025)];v=F[F.family.eq(fam)&F.outcome.eq('log_spread')&F.post_window.eq('first_year')];inst.append([labels[fam],'Tax authority' if fam=='CBCR_CONFIDENTIAL' else 'Public',str(len(ev)),str(int(v.treated_countries.iloc[0])) if len(v) else '-',f'{100*z.loc[fam,"weight"]:.1f}%' if fam in z.index else '-'])
add('Disclosure families and information audiences',['Family','Audience','Recorded\ncountries','Supported\nadopters','Public-pool\ncap weight'],inst,'The main pool comprises ten identified public-disclosure families; eight support following-year comparisons and six support years 1-3. Confidential tax reporting is shown separately and enters a combined disclosure sensitivity. Recorded country counts include implemented phases through 2025 across the wider source register, not only countries with market data. Dashes denote unsupported estimates or exclusion from the public-only weight. The calendar is not a census of all historical disclosure laws; broader governance and register categories remain in the 17-family appendix.')
rows=[]
for sc,label in [('public_disclosure','Public disclosures'),('public_and_confidential','Public + confidential')]:
 for win,horizon in [('first_year','Year 1'),('mean_0_2','Years 1-3')]:
  for out in outs:
   zz=[Q[Q.scope.eq(sc)&Q.post_window.eq(win)&Q.outcome.eq(out)&Q.family_weight.eq(w)].iloc[0] for w in schemes];rows.append([label+'\n'+horizon+': '+olabs[out],str(int(zz[0].families)),*[cell(v,se='conditional_country_se',adj='holm_primary_12_p',digits=4 if out=='zero_fraction' else 3) for v in zz]])
add('Does disclosure regulation generally change liquidity?',[commoncols[0],'Families',*commoncols[2:]],rows,'Primary pool: public disclosures. Secondary pool: public plus confidential disclosures. Country-cohort comparisons exclude already-treated countries and unknown policy histories. Baseline is year -1; outcomes are year 1 or the mean of years 1-3. Parentheses are conditional country standard errors. Public-pool q values adjust over its 12 principal tests; the separate 36-cell scope correction is in the accompanying data. Cohort and family weights are positive and normalised. A common average is a specified weighted target, not a claim that each law has the same effect.',True)
add('Country controls on identical samples',commoncols,simple_rows([('paired_no_controls','No controls'),('paired_controls','Prior domestic controls')]),commonnote+' The paired regressions use the same eligible country rows and supported cohorts. Controls are prior log GDP per capita, GDP growth and trade/GDP, standardised within cohort. Each cohort regression includes an intercept; sample restriction and regression adjustment are distinct from the primary estimate.',True)
rr=[]
for fam in sorted(scope):
 vals=F[F.family.eq(fam)&F.post_window.eq('first_year')].set_index('outcome')
 if vals.empty:continue
 rr.append([labels[fam],str(int(vals.iloc[0].treated_countries)),*[f'{vals.loc[out,"estimate"]:+.4f}\n({vals.loc[out,"country_se"]:.4f})' for out in outs]])
add('Liquidity estimates by public-disclosure family',['Family','Adopting\ncountries','Log spread\nCoefficient (SE)','Log price impact\nCoefficient (SE)','Zero-return share\nCoefficient (SE)'],rr,'All eight supported public-disclosure families are reported, including positive and negative estimates. GDP weights within each family. Estimates compare year 1 with year -1, using fixed company cohorts. Country-influence uncertainty is conditional on legal histories and does not capture common supranational assignment. These are family estimates underlying the primary pool, not eight independent confirmations.',True)
rr=[]
for group in ['Public disclosure','Confidential tax','Other rules','Public minus confidential']:
 for out in outs:
  zz=[pick('audience_'+group,out,'difference' if group=='Public minus confidential' else 'treated',w) for w in schemes];rr.append([group+'\n'+olabs[out],str(int(zz[0].families)),*[cell(v,digits=4 if out=='zero_fraction' else 3) for v in zz]])
add('Does the audience for disclosure matter?',commoncols,rr,commonnote+' The public-minus-confidential row is a formal difference using shared country covariance, not a comparison of significance labels. Other rules refers to the four supported nonheadline families in the wider registry. Families differ in legal content, scope and implementation periods, so these contrasts are not randomised audience effects. Confidential reporting can have indirect real and market effects and is not a negative-control outcome.',True)
for mod,title in [('pre_own_outcome','Cross section: prior market illiquidity'),('reg_quality','Cross section: regulatory quality'),('stock_market_cap_gdp_pct','Cross section: financial development')]:
 add(title,commoncols,simple_rows([('interaction_'+mod,'')],True),commonnote+' Each cohort regression includes treatment, the centred moderator and their interaction. Moderator is measured in year -1 and scaled by the unweighted eligible-country standard deviation. At least two adopting and six comparison countries, full rank and three residual degrees of freedom are required. The main treatment coefficient is evaluated at the cohort mean moderator. Prior illiquidity can reflect mean reversion; regulatory quality is not policy-specific enforcement; market capitalisation/GDP is financial development, not issuer eligibility.',True)
add('Cross sections: income and international openness',commoncols,simple_rows([('interaction_ln_gdp_pc','Log GDP per capita'),('interaction_trade_gdp_pct','Trade/GDP')],True),commonnote+' Income and openness enter separate interaction regressions. Each includes the moderator main effect. Timing, scaling and support requirements are the same as Tables 7-9. These country moderators cannot substitute for missing firm information-environment variables such as analyst following or institutional ownership.',True)
B=pd.read_csv(O/'tables/matching-balance.csv');BM=pd.read_csv(O/'audit/country-cohort-memberships.csv');BM=BM[BM.model.eq('matching_nearest_three')&BM.family.isin(scope)][['family','cohort']].drop_duplicates();B=B.merge(BM,on=['family','cohort'],validate='many_to_one');br=[]
for variable,b in B.groupby('variable'):br.append([variable,f'{b.before_standardised_difference.abs().mean():.3f}',f'{b.after_standardised_difference.abs().mean():.3f}',f'{100*b.after_standardised_difference.abs().gt(.25).mean():.1f}%'])
add('Matched-country liquidity comparisons',commoncols,simple_rows([('matching_eligible_unmatched','Eligible, unmatched'),('matching_nearest_three','Three nearest controls')]),commonnote+' Each adopting country is matched to three documented not-yet-treated countries within the same cohort using Mahalanobis distances in prior income, trade/GDP and all three pre-policy liquidity levels. Controls can be reused. Distances use no future outcome values, but the complete-outcome sample is conditional on future availability. Matching uncertainty is not included. Balance statistics are shown below; residual imbalance is not declared solved.',True,panels=[{'title':'Matching balance: mean absolute standardised differences across supported cohorts','columns':['Covariate','Before','After','After > 0.25'],'rows':br}])
# Re-estimate event pooling on public families using preserved family influence
# arrays from the balanced event estimator rather than reweighting pointwise SEs.
eventfile=P/'event-diagnostics/audit/issuer-exposure-family-influences.npz'
# Public event estimates are prepared separately with the same fixed-seven-year
# observations and only public families. No point-estimate-only SE reconstruction.
EP=pd.read_csv(O/'tables/public-event-profiles.csv');PP=pd.read_csv(O/'tables/public-event-principal.csv');rr=[]
for out in outs:
 for e in [-3,-2,0,1,2,3]:
  zz=[EP[EP.outcome.eq(out)&EP.event_time.eq(e)&EP.across_weight.eq(w)].iloc[0] for w in schemes];rr.append([olabs[out]+f'\nYear {e:+d}',str(int(zz[0].families)),*[f'{v.estimate:+.4f}\n({v.country_cluster_se_diagnostic:.4f})' for v in zz]])
pre=[]
for out in outs:pre.append([olabs[out],*[f'{PP[PP.outcome.eq(out)&PP.across_weight.eq(w)].joint_lead_p_diagnostic.iloc[0]:.4f}' for w in schemes]])
add('Dynamics and pre-policy comparisons',['Outcome / event year','Families','Equal family\nCoefficient (SE)','Market-cap family\nCoefficient (SE)'],rr,'Fixed company sample in years -3 through +3; year -1 is the omitted reference. Public-disclosure families only. GDP within families. Pointwise conditional country standard errors are in parentheses. The joint lead test evaluates years -3 and -2 together; neither rejection nor nonrejection establishes the size of post-policy trend violations. The seven-year sample differs from the primary shorter-window sample.',True,panels=[{'title':'Joint lead p-values','columns':['Outcome','Equal family','Market-cap family'],'rows':pre}])
rr=[]
for kind,prefix in [('Separate','separate_maximal_'),('Joint','primary_joint')]:
 for term,label in mechs.items():
  zz=[D[D.specification.eq(prefix+term if kind=='Separate' else prefix)&D.term.eq(term)&D.family_weight.eq(w)].iloc[0] for w in schemes];r=zz[0];rr.append([kind+': '+label,f'{int(r.rows):,} / {int(r.countries)} / {int(r.families)}',*[f'{v.odds_ratio:.3f}\n[{v.odds_low:.3f}, {v.odds_high:.3f}]' if v.status=='estimated' else 'Not estimated\n'+str(v.status).replace('_',' ') for v in zz]])
add('Policy diffusion: reference-style logit',['Model and mechanism','Rows / countries /\nfamilies','Equal family\nOdds ratio [95% CI]','Market-cap family\nOdds ratio [95% CI]'],rr,'Adoption-status logit, family and year effects, independent focal decisions and lagged signals. Public-disclosure liquidity-supported family set; equal/cap likelihood mass divided by usable family rows. Competition and language shares are per ten percentage points, learning binary and external finance per one percentage point of GDP. Failed or unsupported fits remain explicit. The entire 104-attempt sensitivity matrix and adjusted p-values accompany the paper. Status associations are not first-adoption hazards or causal contagion.',True)
for outcome,title in [('status_event','Policy diffusion: within-country adoption status'),('first_event','Policy diffusion: first-adoption timing')]:
 rr=[]
 for mode in ['separate','joint']:
  for term,label in mechs.items():
   zz=[]
   for fe in ['country_family_and_year','country_family_and_family_year']:
    for w in schemes:zz.append(L[L.model.eq(mode+'_'+outcome)&L.term.eq(term)&L.fixed_effects.eq(fe)&L.family_weight.eq(w)].iloc[0])
   r=zz[0];rr.append([mode.title()+': '+label+f'\nN={int(r.rows):,}; C={int(r.countries)}; F={int(r.families)}',*[cell(v,adj='holm_within_matrix_p') for v in zz]])
 add(title,['Model / sample','Country-family + year\nEqual','Country-family + year\nMarket-cap','Country-family + family-year\nEqual','Country-family + family-year\nMarket-cap'],rr,'Weighted linear probability models. N denotes country-family-year rows; C countries; F families. Cells show coefficient, country-clustered SE and q across all 64 planned coefficient attempts. Predictor units match Table 13. The outcome is whether the policy is in place (Table 14) or first adoption while still at risk (Table 15). Country-family effects remove persistent national policy-family differences; family-year effects additionally absorb common family adoption waves. Adding family-year effects was declared after initial within-year results were seen; both designs and every coefficient are retained. LPM coefficients are probability-point associations and can imply out-of-range fitted probabilities. They are not odds ratios or causal peer effects.',True)
tables[12]['is_regression_table']=False;tables[12]['is_regression_support_diagnostic']=True
assert sum(t['is_regression_table'] for t in tables)==12 and len(tables)==15
(O/'paper/tables.json').write_text(json.dumps(tables,indent=2,ensure_ascii=False),encoding='utf8');print(json.dumps({'tables':len(tables),'estimated_regression_tables':12,'regression_support_diagnostics':1,'cross_section_tables':4,'public_policy_families_attempted':len(scope)}))
