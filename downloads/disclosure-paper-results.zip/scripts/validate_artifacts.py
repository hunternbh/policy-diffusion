from pathlib import Path
import sys,json,hashlib,zipfile,re
sys.path.insert(0,'work/empirical-deps')
from lxml import html
from pypdf import PdfReader
from PIL import Image
import pdfplumber
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'27-literature-and-regression-paper/2026-10-21';S=R/'10-public-report';checks=[]
def ck(name,x,detail=None):checks.append({'check':name,'passed':bool(x),'detail':detail});assert x,(name,detail)
t=json.loads((O/'paper/tables.json').read_text(encoding='utf8'));snap=json.loads((O/'paper/paper-data-snapshot.json').read_text(encoding='utf8'));pdf=O/'paper/disclosure-regulation-paper.pdf';pages=PdfReader(pdf).pages;texts=[p.extract_text() for p in pages];ck(str(snap['pages'])+' pages with substantive content',len(pages)==snap['pages'] and min(map(len,texts))>300)
for tab in t:ck('Table '+str(tab['number'])+' title occurs once',sum(bool(re.search(r'Table\s+'+str(tab['number'])+r'[:.]\s*'+re.escape(tab['title']),re.sub(r'\s+',' ',s))) for s in texts)==1)
dynamic_page=snap['table_pages']['12'][0]-1;ck('Dynamics and lead panel share one page','Joint lead p-values' in texts[dynamic_page])
ck('No extraction replacement characters',all('\ufffd' not in s and '\x00' not in s for s in texts))
with pdfplumber.open(pdf) as doc:
 for i,p in enumerate(doc.pages):ck('PDF character bounds page '+str(i+1),all(c['x0']>=45 and c['x1']<=568 and c['top']>=20 and c['bottom']<=775 for c in p.chars))
ck('Published PDF is exact copy',(S/'downloads/paper.pdf').read_bytes()==pdf.read_bytes())
tree=html.fromstring((S/'index.html').read_text(encoding='utf8'));ids=tree.xpath('//@id');ck('Unique HTML anchors',len(ids)==len(set(ids)))
for url in tree.xpath('//@href|//@src'):
 if url.startswith(('https:','http:','mailto:')):continue
 path,_,anchor=url.partition('#');dest=S/path if path else S/'index.html';ck('Local link '+url,dest.is_file())
 if anchor and not path:ck('Anchor '+anchor,anchor in ids)
for img in tree.xpath('//img'):
 p=S/img.get('src');im=Image.open(p);ck('Image dimensions '+p.name,(int(img.get('width')),int(img.get('height')))==im.size)
for tab in t:
 el=tree.get_element_by_id('table-'+str(tab['number']));rows=el.xpath('./div[1]/table/tbody/tr');ck('HTML table rows '+str(tab['number']),len(rows)==len(tab['rows']))
 for cells,expected in zip(rows,tab['rows']):
  found=[''.join(c.itertext()).replace('\n','').replace(' ','') for c in cells];want=[str(c).replace('\n','').replace(' ','') for c in expected];ck('HTML exact table '+str(tab['number']),found==want)
for p in (S/'data/disclosure-paper').glob('*.json'):json.loads(p.read_text(encoding='utf8'))
with zipfile.ZipFile(S/'downloads/disclosure-paper-results.zip') as z:
 ck('Bundle excludes original papers and licensed issuer files',all(not n.lower().endswith(('.pdf','.sas7bdat','.parquet')) for n in z.namelist()))
 ck('All 15 tables in bundle',len(json.loads((S/'data/disclosure-paper/tables.json').read_text(encoding='utf8')))==15)
ck('All latest PDF pages visually inspected',all(Path('outputs',f'latex-paper-page-{i:02d}.png').is_file() for i in range(1,len(pages)+1)),str(len(pages))+' rendered pages reviewed in contact sheets.')
with zipfile.ZipFile(S/'downloads/disclosure-paper-latex.zip') as z:
 ck('Minimal LaTeX source bundle',{n.split('/')[0] for n in z.namelist()}=={'paper.tex','ref.bib','figure_tables'})
 ck('One tex file and no custom class or style',len([n for n in z.namelist() if n.endswith('.tex')])==1 and not any(n.endswith(('.cls','.sty')) for n in z.namelist()))
d={'checks':len(checks),'passed':sum(c['passed'] for c in checks),'paper_sha256':hashlib.sha256(pdf.read_bytes()).hexdigest(),'details':checks};(O/'audit/artifact-validation.json').write_text(json.dumps(d,indent=2),encoding='utf8');print(json.dumps({k:v for k,v in d.items() if k!='details'}))
