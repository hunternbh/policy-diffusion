from pathlib import Path
import sys,json,re
sys.path.insert(0,'work/empirical-deps')
from pypdf import PdfReader
from PIL import Image,ImageDraw
import pdfplumber
P=Path('tmp/latex-paper/paper.pdf');reader=PdfReader(P);pages=[p.extract_text() for p in reader.pages];short=[(i+1,len(s),s[:90]) for i,s in enumerate(pages) if len(s)<350];bad=[]
with pdfplumber.open(P) as pdf:
 for i,p in enumerate(pdf.pages):
  b=[c for c in p.chars if c['x0']<65 or c['x1']>549 or c['top']<45 or c['bottom']>764]
  if b:bad.append({'page':i+1,'outside_chars':len(b),'text':''.join(c['text'] for c in b)[:100]})
for start in range(0,len(pages),4):
 sheet=Image.new('RGB',(1640,2190),'#d8d8d8');draw=ImageDraw.Draw(sheet)
 for j in range(min(4,len(pages)-start)):
  n=start+j+1;im=Image.open(Path('outputs')/f'latex-paper-page-{n:02d}.png').convert('RGB');im.thumbnail((800,1050));x=20+(j%2)*820;y=30+(j//2)*1090;sheet.paste(im,(x,y));draw.text((x,y-18),f'Page {n}',fill='black')
 sheet.save(Path('outputs')/f'latex-contact-{start//4+1}.png')
out={'pages':len(pages),'short_pages':short,'out_of_bounds_text':bad,'tables':{str(n):[i+1 for i,s in enumerate(pages) if re.search(r'Table\s+'+str(n)+r':',s)] for n in range(1,16)},'figure_pages':[i+1 for i,s in enumerate(pages) if re.search(r'Figure\s+\d:',s)],'unknown_citation_marker':'(?)' in '\n'.join(pages)};Path('tmp/latex-paper/layout-audit.json').write_text(json.dumps(out,indent=2),encoding='utf8');print(json.dumps(out))
