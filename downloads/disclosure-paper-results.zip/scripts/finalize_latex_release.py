"""Promote the compiled, reviewed LaTeX manuscript; preserve original estimates."""
from pathlib import Path
import sys,json,shutil,hashlib,re,zipfile
sys.path.insert(0,'work/empirical-deps')
from pypdf import PdfReader
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'27-literature-and-regression-paper/2026-10-21';P=O/'paper/latex';compiled=Path('tmp/latex-paper/paper.pdf');pdf=O/'paper/disclosure-regulation-paper.pdf';archive=R/'90-archives/2026-10-21-format-change';archive.mkdir(parents=True,exist_ok=True)
if not (archive/'disclosure-regulation-compact.pdf').exists():shutil.copy2(pdf,archive/'disclosure-regulation-compact.pdf')
shutil.copy2(compiled,pdf)
pages=[p.extract_text() for p in PdfReader(pdf).pages];snap=json.loads((O/'paper/paper-data-snapshot.json').read_text(encoding='utf8'));snap.update(pages=len(pages),PDF_sha256=hashlib.sha256(pdf.read_bytes()).hexdigest(),format='12-point Times-style, double-spaced manuscript with one-inch margins',source='latex/paper.tex',bibliography='latex/ref.bib',table_pages={str(n):[i+1 for i,s in enumerate(pages) if re.search(r'Table\s+'+str(n)+r':',s)] for n in range(1,16)})
(O/'paper/paper-data-snapshot.json').write_text(json.dumps(snap,indent=2),encoding='utf8')
assert all(len(v)==1 for v in snap['table_pages'].values()),snap['table_pages']
assert sorted(p.name for p in P.iterdir())==['figure_tables','paper.tex','ref.bib']
for p in [Path('outputs/disclosure-regulation-paper.pdf'),Path('outputs/expanded-policy-paper-draft.pdf'),R/'09-expanded-policy-paper/disclosure-regulation-paper.pdf']:shutil.copy2(pdf,p)
# Synchronise the short abstract and added review citation with the editable
# manuscript; numerical results and full table data are unchanged.
docpath=O/'paper/manuscript-prose.json';d=json.loads(docpath.read_text(encoding='utf8'));src=(P/'paper.tex').read_text(encoding='utf8');a=re.search(r'\\begin\{abstract\}\s*\\noindent (.*?)\\end\{abstract\}',src,re.S).group(1).strip();d['abstract']=a.replace('--','–').replace('\\%','%');sentence='Leuz and Wysocki (2016) place these reporting choices within the wider economics of disclosure regulation.'
for section in d['sections']:
 for j,text in enumerate(section['paragraphs']):
  if text.startswith('The disclosure literature consequently') and sentence not in text:section['paragraphs'][j]+=' '+sentence
d['editable_source']='latex/paper.tex';docpath.write_text(json.dumps(d,indent=2,ensure_ascii=False),encoding='utf8');text=d['title']+'\n\n'+d['abstract']+'\n\n'+'\n\n'.join(s['heading']+'\n\n'+'\n\n'.join(s['paragraphs']) for s in d['sections'])+'\n\nReferences\n'+'\n\n'.join(r['citation']+'. '+r['title']+'. '+r['publication']+'. '+r['primary_url'] for r in d['references']);(O/'paper/manuscript-draft.txt').write_text(text,encoding='utf8')
snap['prose_words']=len((d['abstract']+' '+' '.join(' '.join(s['paragraphs']) for s in d['sections'])).split());(O/'paper/paper-data-snapshot.json').write_text(json.dumps(snap,indent=2),encoding='utf8')
for name,target in [('manuscript-draft.txt','disclosure-regulation-manuscript.txt'),('manuscript-prose.json','disclosure-regulation-manuscript.json')]:shutil.copy2(O/'paper'/name,Path('outputs')/target)
layout=json.loads(Path('tmp/latex-paper/layout-audit.json').read_text(encoding='utf8'));review=O/'audit/latex-visual-review.json';reviewed=review.exists() and json.loads(review.read_text(encoding='utf8'))['PDF_sha256']==snap['PDF_sha256'];layout.update(PDF_sha256=snap['PDF_sha256'],all_pages_visually_reviewed=reviewed,extra_TeX_files=False,source_structure=['paper.tex','ref.bib','figure_tables/']);(O/'audit/latex-layout-validation.json').write_text(json.dumps(layout,indent=2),encoding='utf8');assert not layout['out_of_bounds_text']
with zipfile.ZipFile(Path('outputs/disclosure-paper-latex.zip'),'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(P.rglob('*')):
  if p.is_file():z.write(p,p.relative_to(P).as_posix())
guide=R/'README.txt';s=guide.read_text(encoding='utf8').replace('31-page working draft','41-page working draft');line='Editable source: 27-literature-and-regression-paper/2026-10-21/paper/latex/paper.tex\n'
if line not in s:s=s.replace('CURRENT MAIN PAPER:',line+'CURRENT MAIN PAPER:',1)
guide.write_text(s,encoding='utf8');print(json.dumps({'pages':snap['pages'],'prose_words':snap['prose_words'],'tables':snap['tables'],'source':str(P/'paper.tex'),'PDF_sha256':snap['PDF_sha256']}))
