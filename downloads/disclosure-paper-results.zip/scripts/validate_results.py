"""Independent reconstruction from saved aggregate rows, not estimator helpers."""
import os
for k in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys,json,hashlib,datetime
sys.path.insert(0,'work/empirical-deps')
import pandas as pd,numpy as np,statsmodels.api as sm
from statsmodels.stats.multitest import multipletests
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'27-literature-and-regression-paper/2026-10-21';P=R/'26-adoption-weighting-and-design-audit/2026-10-19';checks=[]
def check(name,condition,detail=None):
 checks.append({'check':name,'passed':bool(condition),'detail':detail});assert condition,(name,detail)
plan=json.loads((O/'analysis-plan.json').read_text(encoding='utf8'));public=set(plan['headline_families']);check('Public scope includes ten named families; confidential excluded',len(public)==10 and 'CBCR_CONFIDENTIAL' not in public)
Q=pd.read_csv(O/'tables/main-liquidity.csv');W=pd.read_csv(O/'tables/main-family-weights.csv');I=pd.read_csv(O/'audit/main-country-influences.csv')
for _,r in Q.iterrows():
 w=W[W.specification_id.eq(r.specification_id)];inf=I[I.specification_id.eq(r.specification_id)];check('Reconstruct main '+r.specification_id,np.isclose(w.weight.sum(),1) and w.weight.gt(0).all() and np.isclose((w.weight*w.family_estimate).sum(),r.estimate,atol=1e-12) and np.isclose(np.linalg.norm(inf.influence),r.conditional_country_se,atol=1e-12))
 if r.scope=='public_disclosure':check('Public membership '+r.specification_id,set(w.family)<=public and len(w)==(8 if r.post_window=='first_year' else 6))
 if r.family_weight=='equal_family':check('Equal weight '+r.specification_id,np.allclose(w.weight,1/len(w)))
 else:check('Pre-policy cap weight '+r.specification_id,np.allclose(w.weight,w.pre_cap_mass/w.pre_cap_mass.sum()))
A=pd.read_csv(O/'data/country-cohort-regression-inputs.csv');M=pd.read_csv(O/'audit/country-cohort-memberships.csv');C=pd.read_csv(O/'audit/all-cohort-WLS-coefficients.csv');N=pd.read_csv(O/'tables/new-liquidity-regressions.csv');F=pd.read_csv(O/'tables/new-liquidity-family-regressions.csv');NIF=pd.read_csv(O/'audit/pooled-country-influences.csv');cal=pd.read_csv(O/'data/reviewed-policy-calendar.csv');models=[];maxerr=0.;maxmatched=0.;balance=[]
for (model,fam,g,out),z in C.groupby(['model','family','cohort','outcome']):
 a=A[A.family.eq(fam)&A.cohort.eq(g)].set_index('iso3');m=M[M.model.eq(model)&M.family.eq(fam)&M.cohort.eq(g)&M.outcome.eq(out)];a=a.loc[m.iso3];w=a.gdp_constant_usd.to_numpy().copy()
 if model=='matching_nearest_three':
  fields=['ln_gdp_pc','trade_gdp_pct','log_spread_pre','log_impact_pre','zero_fraction_pre'];b=A[A.family.eq(fam)&A.cohort.eq(g)].set_index('iso3').dropna(subset=fields);xx=b[fields].to_numpy();cov=np.cov(xx,rowvar=False);ridge=max(1e-6*np.trace(cov)/len(fields),1e-12);inv=np.linalg.inv(cov+ridge*np.eye(len(fields)));tr=np.flatnonzero(b.Treat.eq(1));co=np.flatnonzero(b.Treat.eq(0));mw=pd.Series(0.,index=b.index);mw.iloc[tr]=b.iloc[tr].gdp_constant_usd
  for j in tr:
   d=xx[co]-xx[j];distance=np.sum((d@inv)*d,axis=1);chosen=co[np.argsort(distance,kind='stable')[:3]];mw.iloc[chosen]+=b.iloc[j].gdp_constant_usd/3
  check('Matched membership '+fam+str(g)+out,set(a.index)==set(mw[mw>0].index));w=mw.loc[a.index].to_numpy();maxmatched=max(maxmatched,abs(w[a.Treat.eq(1)].sum()-w[a.Treat.eq(0)].sum()))
 x=pd.DataFrame({'constant':1.,'treated':a.Treat},index=a.index)
 if model=='paired_controls':
  for c in ['ln_gdp_pc','gdp_growth_pct','trade_gdp_pct']:x[c]=(a[c]-a[c].mean())/a[c].std(ddof=0)
 if model.startswith('interaction_'):
  c=model[len('interaction_'):];c=out+'_pre' if c=='pre_own_outcome' else c;x['moderator']=(a[c]-a[c].mean())/a[c].std(ddof=0);x['treated_x_moderator']=a.Treat*x.moderator
 fit=sm.WLS(a[out],x,weights=w).fit();expected=z.set_index('term').coefficient.loc[x.columns];err=float(np.max(abs(fit.params-expected)));maxerr=max(maxerr,err)
 check('Independent WLS '+model+fam+str(g)+out,err<1e-9,err)
 dates=cal[cal.regulation_family.eq(fam)].set_index('iso3').reviewed_G
 check('Documented timing and untreated controls '+fam+str(g)+out,(dates.loc[a.index[a.Treat.eq(1)]]==g).all() and (dates.loc[a.index[a.Treat.eq(0)]]>g+1).all())
 models.append((model,fam,int(g),out,len(a)))
for keys,z in M.groupby(['family','cohort','outcome']):
 u=z[z.model.eq('paired_no_controls')];v=z[z.model.eq('paired_controls')]
 if len(u) or len(v):check('Paired control sample '+str(keys),set(u.iso3)==set(v.iso3))
check('All saved new cohort coefficients reconstructed',sum(len(C[(C.model.eq(k[0]))&(C.family.eq(k[1]))&(C.cohort.eq(k[2]))&(C.outcome.eq(k[3]))]) for k in models)==len(C),{'coefficients':len(C),'maximum_absolute_error':maxerr})
check('Matched treated/comparison GDP masses equal',maxmatched<1,{'maximum_dollar_difference':maxmatched})
for _,r in N[N.status.eq('estimated')&~N.model.str.startswith('audience_')].iterrows():
 f=F[F.model.eq(r.model)&F.outcome.eq(r.outcome)&F.term.eq(r.term)];w=np.ones(len(f)) if r.family_weight=='equal_family' else f.cap_mass.to_numpy();w=w/w.sum();inf=NIF[NIF.model.eq(r.model)&NIF.outcome.eq(r.outcome)&NIF.term.eq(r.term)&NIF.family_weight.eq(r.family_weight)];check('Reconstruct extension '+r.model+r.outcome+r.term+r.family_weight,set(f.family)<=public and np.isclose(np.dot(w,f.estimate),r.estimate,atol=1e-12) and np.isclose(np.linalg.norm(inf.influence),r.country_se,atol=1e-12))
check('108 extension coefficients and Holm correction',len(N)==108 and np.allclose(multipletests(N.p_value.fillna(1),method='holm')[1],N.holm_new_family_p))
# Independently fit explicit dummy-variable WLS rather than alternating demeaning.
D=pd.read_parquet(P/'data/lagged-mechanism-panel.parquet');D['row_id']=np.arange(len(D));D=D.set_index('row_id');DM=pd.read_parquet(O/'audit/diffusion-within-memberships-local.parquet');L=pd.read_csv(O/'tables/diffusion-country-family-FE.csv');differr=[]
for _,r in L[L.status.eq('estimated')].iterrows():
 m=DM[DM.model.eq(r.model)&DM.fixed_effects.eq(r.fixed_effects)&DM.terms.eq(r.term)&DM.family_weight.eq(r.family_weight)];a=D.loc[m.row_id];w=m.weight.to_numpy();y=a[r.outcome].to_numpy();xx=a[r.term].to_numpy()/(.1 if r.term in ['trade_fixed2000','language'] else 1.)
 cf=pd.get_dummies(a.iso3+'_'+a.family,dtype=float).to_numpy();fe=pd.get_dummies(a.year if r.fixed_effects=='country_family_and_year' else a.family+'_'+a.year.astype(str),dtype=float).to_numpy();X=np.column_stack([xx,cf,fe]);sw=np.sqrt(w);U,s,V=np.linalg.svd(X*sw[:,None],full_matrices=False);rank=int((s>s[0]*max(X.shape)*np.finfo(float).eps).sum());V=V[:rank];s=s[:rank];b=V.T@((U[:,:rank].T@(y*sw))/s);res=y-X@b;bread=(V.T/s**2)@V;score=X*(w*res)[:,None];scores=pd.DataFrame(score).assign(iso=a.iso3.to_numpy()).groupby('iso').sum().to_numpy();nc=a.iso3.nunique();n=len(a);cov=bread@(scores.T@scores)@bread*nc/(nc-1)*(n-1)/(n-rank);se=np.sqrt(cov[0,0]);err=max(abs(b[0]-r.estimate),abs(se-r.country_se));differr.append(err)
 check('Dense-dummy WLS '+r.model+r.term+r.family_weight+r.fixed_effects,err<2e-7,{'coefficient_error':float(b[0]-r.estimate),'SE_error':float(se-r.country_se),'matrix_rank':rank,'reported_FE_plus_terms':int(r.absorbed_df+1)})
check('Diffusion Holm and failed cells retained',len(L)==64 and L.status.eq('estimated').sum()==32 and np.allclose(multipletests(L.p_value.fillna(1),method='holm')[1],L.holm_within_matrix_p))
check('Absorbed or unsupported outcomes withheld',L[L.status.eq('estimated')].within_outcome_sd.gt(1e-9).all())
for _,z in L.groupby(['model','term']):check('Diffusion fixed-effect and weighting paired samples',z.sample_sha256.nunique()==1)
T=json.loads((O/'paper/tables.json').read_text(encoding='utf8'));check('Twelve estimable regression tables, fifteen total',len(T)==15 and sum(t['is_regression_table'] for t in T)==12 and not T[12]['is_regression_table'])
out={'validated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':len(checks),'passed':sum(c['passed'] for c in checks),'independent_WLS_models':len(models),'independent_cohort_coefficients':len(C),'independent_dense_FE_models':len(differr),'maximum_WLS_coefficient_error':maxerr,'maximum_dense_FE_coefficient_or_SE_error':max(differr),'limitations':'These checks establish numerical reconstruction and declared support. They do not validate causal identification, completeness of historical nonadoption or global issuer eligibility.','details':checks};(O/'audit/validation-results.json').write_text(json.dumps(out,indent=2),encoding='utf8');print(json.dumps({k:v for k,v in out.items() if k!='details'}))
