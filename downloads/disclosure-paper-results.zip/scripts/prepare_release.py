from pathlib import Path
import json,shutil
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'27-literature-and-regression-paper/2026-10-21';H=Path('work/jar-paper')
for name in ['prepare_git.py','verify_publication.py']:
 s=(Path('work/design-audit')/name).read_text(encoding='utf8').replace('26-adoption-weighting-and-design-audit/2026-10-19','27-literature-and-regression-paper/2026-10-21').replace("Path('work/design-audit')","Path('work/jar-paper')")
 (H/name).write_text(s,encoding='utf8')
guide=R/'09-expanded-policy-paper/reference-writing-and-methods.json'
if guide.exists():
 d=json.loads(guide.read_text(encoding='utf8'));d['Dube_Zhu_2021_extension']={'writing_logic':'27-literature-and-regression-paper/2026-10-21/literature/Dube-Zhu-writing-logic.json','paper':'27-literature-and-regression-paper/2026-10-21/paper/disclosure-regulation-paper.pdf','primary_question':'Do identified disclosure requirements generally affect liquidity?','public_and_confidential':'Public main; combined and confidential comparisons retained.'};guide.write_text(json.dumps(d,indent=2),encoding='utf8')
# A public summary of the numerical checks, without machine-specific paths.
v=json.loads((O/'audit/validation-results.json').read_text(encoding='utf8'));a=json.loads((O/'audit/artifact-validation.json').read_text(encoding='utf8'));snap=json.loads((O/'paper/paper-data-snapshot.json').read_text(encoding='utf8'));(O/'audit/verification-summary.json').write_text(json.dumps({'numerical_checks':v['checks'],'numerical_passed':v['passed'],'artifact_checks':a['checks'],'artifact_passed':a['passed'],'PDF_pages_visually_reviewed':snap['pages'],'causal_identification_certified':False},indent=2),encoding='utf8')
shutil.copy2(O/'audit/verification-summary.json',R/'10-public-report/data/disclosure-paper/verification-summary.json')
print('Release helpers and verification summary prepared.')
