from pathlib import Path
import json,shutil
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'27-literature-and-regression-paper/2026-10-21';P=R/'26-adoption-weighting-and-design-audit/2026-10-19/event-diagnostics';E=O/'event-diagnostics'
for sub in ['data','tables','audit']:(E/sub).mkdir(parents=True,exist_ok=True)
shutil.copy2(P/'geographic-analysis-plan.json',E/'geographic-analysis-plan.json')
for name in ['macro-country-year.csv','classified-dated-policy-cases.csv']:shutil.copy2(P/'data'/name,E/'data'/name)
scope=json.loads((O/'analysis-plan.json').read_text(encoding='utf8'))['headline_families'];script=Path('work/design-audit/event_diagnostics.py').read_text(encoding='utf8').replace('26-adoption-weighting-and-design-audit/2026-10-19/event-diagnostics','27-literature-and-regression-paper/2026-10-21/event-diagnostics');script=script.replace('famnames=sorted(cases.regulation_family.unique())','cases=cases[cases.regulation_family.isin('+repr(scope)+')];famnames=sorted(cases.regulation_family.unique())');Path('work/jar-paper/public_events.py').write_text(script,encoding='utf8')
