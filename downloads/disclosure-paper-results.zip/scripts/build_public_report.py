"""Publish the paper's frozen estimates and sources; never select by result."""
from pathlib import Path
import sys,json,shutil,html,zipfile,datetime,hashlib
sys.path.insert(0,'work/empirical-deps')
import pandas as pd
from PIL import Image
from lxml import html as LH
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'27-literature-and-regression-paper/2026-10-21';S=R/'10-public-report';D=S/'data/disclosure-paper';D.mkdir(parents=True,exist_ok=True);H=Path('work/jar-paper');old=(S/'index.html').read_text(encoding='utf8');prior=LH.fromstring(old);T=json.loads((O/'paper/tables.json').read_text(encoding='utf8'));Q=pd.read_csv(O/'tables/main-liquidity.csv');L=pd.read_csv(O/'tables/diffusion-country-family-FE.csv');snap=json.loads((O/'paper/paper-data-snapshot.json').read_text(encoding='utf8'));validation=json.loads((O/'audit/validation-results.json').read_text(encoding='utf8'))
archive=S/'downloads/brief-paper-2026-10-19.pdf'
if not archive.exists():shutil.copy2(S/'downloads/paper.pdf',archive)
shutil.copy2(O/'paper/disclosure-regulation-paper.pdf',S/'downloads/paper.pdf');shutil.copy2(O/'paper/manuscript-draft.txt',S/'downloads/manuscript.txt');shutil.copy2(O/'paper/manuscript-prose.json',D/'manuscript.json');shutil.copy2(O/'paper/tables.json',D/'tables.json');shutil.copy2(O/'analysis-plan.json',D/'analysis-plan.json')
for p in (O/'tables').glob('*.csv'):shutil.copy2(p,D/p.name)
for name in ['Dube-Zhu-writing-logic.json','literature-evidence-matrix.json','search-protocol-and-novelty.json']:shutil.copy2(O/'literature'/name,D/name)
for name in ['validation-results.json','submission-readiness.json','submission-readiness.txt','disclosure-main-summary.json','new-liquidity-summary.json','diffusion-within-summary.json','literature-source-manifest.json']:shutil.copy2(O/'audit'/name,D/name)
if (O/'audit/artifact-validation.json').exists():shutil.copy2(O/'audit/artifact-validation.json',D/'artifact-validation.json')
shutil.copy2(O/'paper/paper-data-snapshot.json',D/'paper-data-snapshot.json')
if (O/'paper/latex/paper.tex').exists():
 LP=S/'latex';LP.mkdir(exist_ok=True)
 for p in (O/'paper/latex').rglob('*'):
  if p.is_file():dest=LP/p.relative_to(O/'paper/latex');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
 shutil.copy2(Path('outputs/disclosure-paper-latex.zip'),S/'downloads/disclosure-paper-latex.zip')
 for name in ['latex-source-audit.json','latex-compilation.json','latex-layout-validation.json']:
  if (O/'audit'/name).exists():shutil.copy2(O/'audit'/name,D/name)
for name in ['disclosure-family-effects','disclosure-event-profiles','disclosure-diffusion-comparison']:
 for ext in ['png','svg']:shutil.copy2(O/'figures'/(name+'.'+ext),S/'assets'/(name+'.'+ext))
def esc(s):return html.escape(str(s)).replace('\n','<br>')
def table(t,rows=None,identifier=None):
 return '<div class="table-scroll" tabindex="0"><table'+(' id="'+identifier+'"' if identifier else '')+'><thead><tr>'+''.join('<th scope="col">'+esc(c)+'</th>' for c in t['columns'])+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+esc(c)+'</td>' for c in row)+'</tr>' for row in (t['rows'] if rows is None else rows))+'</tbody></table></div>'
def fig(name,alt):
 im=Image.open(O/'figures'/(name+'.png'));return f'<div class="chart-scroll" tabindex="0"><img src="assets/{name}.png" width="{im.width}" height="{im.height}" alt="{esc(alt)}" loading="lazy"></div>'
def mainrow(out,win):
 z=Q[Q.scope.eq('public_disclosure')&Q.outcome.eq(out)&Q.post_window.eq(win)]
 def c(w):
  r=z[z.family_weight.eq(w)].iloc[0];n=4 if out=='zero_fraction' else 3;return f'{r.estimate:+.{n}f}\n[{r.ci_low:.{n}f}, {r.ci_high:.{n}f}]'
 return [('Following year' if win=='first_year' else 'Years 1–3')+'\n'+{'log_spread':'Spread','log_impact':'Price impact','zero_fraction':'Zero-return share'}[out],str(int(z.families.iloc[0])),c('equal_family'),c('baseline_market_cap_family')]
primary={'columns':['Outcome','Families','Equal family\nEstimate [95% interval]','Market-cap family\nEstimate [95% interval]'],'rows':[mainrow(o,w) for w in ['first_year','mean_0_2'] for o in ['log_spread','log_impact','zero_fraction']]}
details=[]
for t in T:
 panels=''.join('<p><em>'+esc(p['title'])+'</em></p>'+table(p) for p in t.get('panels',[]));details.append('<details id="table-'+str(t['number'])+'"><summary>Table '+str(t['number'])+'. '+esc(t['title'])+'</summary>'+table(t)+panels+'<p class="note">'+esc(t['note'])+'</p></details>')
retained=[]
keep=['Adoption dates, source reviews and scope','Reference-paper methods and benchmarks','Measurement and inference','Company studies and earlier evidence','All 1,296 liquidity specifications']
for el in prior.xpath('//details'):
 title=''.join(el.xpath('./summary//text()'))
 if title in keep or title in ['Broader 17-family analysis and all 1,296 specifications','Earlier reference-paper benchmarks']:
  if title=='All 1,296 liquidity specifications':
   el.find('summary').text='Broader 17-family analysis and all 1,296 specifications'
  if title=='Reference-paper methods and benchmarks':el.find('summary').text='Earlier reference-paper benchmarks'
  retained.append(LH.tostring(el,encoding='unicode'))
literature=json.loads((O/'literature/literature-evidence-matrix.json').read_text(encoding='utf8'));refs=''.join('<p>'+esc(r['citation'])+'. <a href="'+html.escape(r['primary_url'],quote=True)+'">'+esc(r['title'])+'</a>.</p>' for r in sorted(literature,key=lambda r:r['citation']))
body='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Disclosure regulation and liquidity | Policy diffusion</title><meta name="description" content="Global disclosure regulation: sample, liquidity results and international policy diffusion. Paper, regression tables and source records."><link rel="icon" href="assets/favicon.svg"><link rel="stylesheet" href="assets/international.css"></head><body><a class="skip" href="#main">Skip to content</a><header><a class="brand" href="#top">POLICY DIFFUSION</a><nav aria-label="Report sections"><a href="#sample">Sample</a><a href="#overview">Liquidity</a><a href="#diffusion">Diffusion</a><a href="#appendix">Paper and tables</a></nav><a href="downloads/paper.pdf">Paper ↗</a></header><main id="main"><div id="top" class="intro"><h1>Disclosure regulation and liquidity</h1><p>Do disclosure requirements improve stock-market liquidity? How do they spread across countries?</p></div>
<section id="sample"><h2>Sample and data</h2><div class="table-scroll" tabindex="0"><table><tbody>
<tr><th scope="row">Market data</th><td>Datastream, 2000–2025. 90 jurisdictions, 99,100 company records and 1,055,142 stock-year observations.</td></tr>
<tr><th scope="row">Liquidity measures</th><td>Quoted spread, price impact and zero-return share. All three are available for 636,960 stock-years in 86 jurisdictions.</td></tr>
<tr><th scope="row">Disclosure rules</th><td>Ten identified public-disclosure families. Eight support following-year comparisons; six support years 1–3. Confidential tax reporting is a separate comparison.</td></tr>
<tr><th scope="row">Policy sources</th><td>482 documented country-family histories in the wider register. Legal sources distinguish covered periods, implementation and public information. Historical gaps remain.</td></tr>
<tr><th scope="row">Country data</th><td>GDP, income, trade, regulatory quality and financial development. Diffusion tests add trade peers, geographic peers, shared languages and external finance.</td></tr></tbody></table></div>
<p>We compare changes within the same companies around each policy’s implementation, then aggregate by country and regulation family. Comparisons use countries with a documented later implementation date. Unknown histories and already-treated countries do not become controls.</p>
<details><summary>Which disclosure rules?</summary>'''+table(T[1])+'''<p class="note">The public pool includes financial reporting, auditor reporting, nonfinancial reporting, climate disclosure, public country reports, payments to governments, supply-chain reporting and electronic reporting. This is a comparison across identified families, not a census of every disclosure law.</p></details></section>
<section id="overview"><span id="expanded-liquidity"></span><span id="liquidity"></span><h2>1. Liquidity</h2>'''+table(primary,identifier='main-results')+'''
<p>Public-disclosure spread estimates imply about 2.2% lower spreads under equal family weights and 4.5% under market-cap family weights in the following year. Both intervals include zero. The longer-window spread estimates are also negative, but use a narrower sample. Together with the other outcomes and pre-policy patterns, these results do not yet establish a general causal liquidity improvement.</p>
<p>GDP weights combine countries within each family. Equal family weights describe the typical supported family; market-cap weights put more weight on larger sampled market exposures. Both use the same underlying family estimates. A company can be exposed to several policies.</p>
<h3>Results across disclosure families</h3>'''+fig('disclosure-family-effects','Following-year spread estimates and conditional 95% intervals for eight public-disclosure families, alongside their market-cap weights.')+'''
<p>The average combines different reporting requirements. Nonfinancial reporting has a negative spread estimate across 22 adopting jurisdictions. Other family estimates differ in direction and precision. The chart shows all eight supported families; unsupported families receive no estimated effect.</p>
<h3>Before and after implementation</h3>'''+fig('disclosure-event-profiles','Three liquidity measures from three years before to three years after implementation; equal and market-cap family weights, year minus one reference.')+'''
<p>The fixed seven-year sample covers five families. Spread differences are already visible before implementation, so the post-policy decline alone cannot identify an effect of the rules. Matching and domestic-control comparisons are in Tables 4 and 11.</p>
<details><summary>Public and confidential reporting</summary><p>Public reports can reach investors directly. Confidential country-by-country tax reports go to tax authorities and may affect enforcement, tax costs or investment. They can matter for markets through those channels, but measure a different information change. Table 3 reports the combined pool; Table 6 reports both audiences and their formal difference.</p><p><a href="data/disclosure-paper/main-liquidity.csv">Every pooled estimate</a> · <a href="data/disclosure-paper/audience-contrasts.csv">Audience comparisons</a></p></details></section>
<section id="diffusion"><h2>2. Policy diffusion</h2>'''+fig('disclosure-diffusion-comparison','Competition, learning, language-peer and external-finance adoption associations, comparing common-year and family-year controls under both weights.')+'''
<p>In the separate equal-family model, a ten-percentage-point increase in prior language-peer adoption is associated with a 6.6-point higher probability that a policy is in place. The association survives the stated multiple-test adjustment with common year effects. With family-specific year effects, its estimate changes to −8.4 points and no longer survives that adjustment.</p>
<p>This comparison separates shared adoption waves from possible peer transmission. The evidence does not yet establish emulation, learning or competition as a global causal mechanism. First-adoption timing, both weights and all failed models remain in Tables 13–15.</p>
<p class="note">Country-family effects account for persistent differences in each country’s policy regime. Family-year effects also account for international waves specific to a regulation family. Predictor units differ across the four panels.</p></section>
<section id="appendix"><h2>Paper and regression tables</h2><p class="downloads"><a href="downloads/paper.pdf">Download paper ↗</a><a href="downloads/disclosure-paper-results.zip">Tables and code ↗</a><a href="downloads/manuscript.txt">Manuscript ↗</a></p>
<p>'''+str(snap['pages'])+''' pages, 15 tables and three figures. Twelve tables contain regression estimates, including four cross-sectional tables. Table 13 records the support and estimation failures of the reference-style logit; it is not counted as an estimated regression table.</p>
<p><a href="data/disclosure-paper/Dube-Zhu-writing-logic.json">Dube–Zhu writing and argument notes</a> · <a href="data/disclosure-paper/literature-evidence-matrix.json">34-paper literature matrix</a> · <a href="data/disclosure-paper/analysis-plan.json">Analysis choices</a> · <a href="data/disclosure-paper/validation-results.json">Numerical validation</a> · <a href="data/disclosure-paper/submission-readiness.txt">Next research steps</a></p>
'''+''.join(details)+'''
<details><summary>What remains before submission?</summary><p>The paper is a research working draft. The next tasks are to complete earliest-law and verified nonadoption histories, distinguish actual public-release dates, and strengthen identification against overlapping reforms and coordinated adoption waves. Current cross-sectional support and the public-sample joint diffusion model also limit the claims.</p><p>Independent checks reproduce 315 country-cohort regressions and 32 diffusion models. Numerical agreement does not establish causality or a complete historical treatment universe.</p><p><a href="data/disclosure-paper/submission-readiness.txt">Research priorities and completion criteria</a></p></details>
'''+''.join(retained)+'''<details><summary>Literature</summary><p class="note">The matrix records the depth of each review. Dube and Zhu was read in full; the wider matrix includes primary abstracts, selected text and bibliographic checks.</p>'''+refs+'''</details></section></main><footer><a href="https://github.com/hunternbh/policy-diffusion">Research repository ↗</a><a href="#top">Top ↑</a></footer></body></html>'''
if (S/'downloads/disclosure-paper-latex.zip').exists():body=body.replace('<a href="downloads/manuscript.txt">Manuscript ↗</a>','<a href="downloads/manuscript.txt">Manuscript ↗</a><a href="downloads/disclosure-paper-latex.zip">LaTeX source ↗</a>')
(S/'index.html').write_text(body,encoding='utf8')
# Preserve the prior appendix when the current report is rebuilt.
localappendix=O/'paper/retained-public-appendix.html'
if retained:localappendix.write_text('\n'.join(retained),encoding='utf8')
css=S/'assets/international.css';style=css.read_text(encoding='utf8')
if 'h3{font-size:19px' not in style:css.write_text(style+'\nh3{font-size:19px;font-weight:normal;margin:28px 0 12px}#table-2 table{min-width:700px}details table{min-width:650px}details .note{max-width:950px}\n',encoding='utf8')
# Bundle aggregate results, analysis code and metadata only. Never copy source
# papers, issuer identifiers, the licensed price panel or original data exports.
for p in H.glob('*.py'):
 if p.name not in ['inspect_inputs.py','read_reference.py']:shutil.copy2(p,O/'scripts'/p.name)
readme='''Disclosure regulation: aggregate analysis bundle

Primary scope: ten identified public-disclosure families; eight support the
following year and six the longer window. Confidential and broader categories
are separate sensitivities. All reported signs and failed estimates are kept.

Tables and country-cohort rows contain aggregate public research outputs.
The licensed Datastream security panel, issuer mapping, original third-party
papers and Worldscope exports are not redistributed. Full reconstruction of
the company samples and event profiles requires authorised access to the
project inputs at the paths documented in the scripts. Saved family weights
and country influences allow reconstruction of the reported pooled estimates.
The JSON analysis plan records retrospective choices; it is not preregistration.
See submission-readiness.txt for unresolved historical and design issues.
'''
(O/'README.txt').write_text(readme,encoding='utf8')
with zipfile.ZipFile(S/'downloads/disclosure-paper-results.zip','w',zipfile.ZIP_DEFLATED) as z:
 z.write(O/'README.txt','README.txt');z.write(O/'analysis-plan.json','analysis-plan.json')
 for folder in ['tables','scripts']:
  for p in (O/folder).glob('*'):
   if p.is_file():z.write(p,folder+'/'+p.name)
 for name in ['country-cohort-regression-inputs.csv','reviewed-policy-calendar.csv','macro-country-year.csv','JIBS-domestic-controls.csv']:z.write(O/'data'/name,'data/'+name)
 for name in ['main-country-influences.csv','pooled-country-influences.csv','audience-country-influences.csv','all-cohort-WLS-coefficients.csv','country-cohort-memberships.csv','validation-results.json','submission-readiness.json','submission-readiness.txt']:z.write(O/'audit'/name,'audit/'+name)
 for name in ['Dube-Zhu-writing-logic.json','literature-evidence-matrix.json','search-protocol-and-novelty.json']:z.write(O/'literature'/name,'literature/'+name)
# Maintain existing project entry points, retaining earlier releases in place.
canonical=R/'09-expanded-policy-paper';shutil.copy2(O/'paper/disclosure-regulation-paper.pdf',canonical/'disclosure-regulation-paper.pdf');shutil.copy2(O/'paper/manuscript-draft.txt',canonical/'disclosure-regulation-manuscript.txt');shutil.copy2(O/'paper/manuscript-prose.json',canonical/'disclosure-regulation-manuscript.json');shutil.copy2(O/'paper/disclosure-regulation-paper.pdf',Path('outputs/expanded-policy-paper-draft.pdf'))
guide=R/'README.txt';previous=guide.read_text(encoding='utf8')
line='CURRENT MAIN PAPER: 27-literature-and-regression-paper/2026-10-21\nDisclosure regulation: public primary, confidential comparison; both family weights.\n31-page working draft, 15 tables, 12 estimated regression tables.\nPaper: 27-literature-and-regression-paper/2026-10-21/paper/disclosure-regulation-paper.pdf\nNext steps: 27-literature-and-regression-paper/2026-10-21/audit/submission-readiness.txt\nPublic report: https://hunternbh.github.io/policy-diffusion/\n\n'
line=line.replace('31-page',str(snap['pages'])+'-page').replace('Paper: 27-','Editable source: 27-literature-and-regression-paper/2026-10-21/paper/latex/paper.tex\nPaper: 27-',1)
if 'ADOPTION, WEIGHTING AND REFERENCE-DESIGN AUDIT' in previous:previous=previous[previous.index('ADOPTION, WEIGHTING AND REFERENCE-DESIGN AUDIT'):]
elif previous.startswith('CURRENT MAIN PAPER: 27-'):previous=previous.split('\n\n',1)[-1]
guide.write_text(line+previous,encoding='utf8')
(S/'README.md').write_text('# Disclosure regulation, liquidity and policy diffusion\n\n[Read the report](https://hunternbh.github.io/policy-diffusion/) · [Paper](downloads/paper.pdf) · [Aggregate tables and code](downloads/disclosure-paper-results.zip)\n\nGlobal country-level analysis of identified disclosure regulations. Public requirements form the primary pool; confidential reporting and broader regulation categories remain separate sensitivities. Both equal-family and pre-policy market-cap family weights are reported.\n\nThe working paper has 15 tables, including 12 with estimated regression results, and three figures. Historical treatment gaps, policy identification and limited joint diffusion support remain research priorities. The report does not assert a general causal liquidity benefit or submission readiness. See [next steps](data/disclosure-paper/submission-readiness.txt).\n\nLicensed market inputs and original third-party papers are not redistributed. All reported estimates, unsupported fits and analysis choices are retained.\n',encoding='utf8')
print(json.dumps({'public_report':str(S/'index.html'),'paper_pages':snap['pages'],'tables':len(T),'estimated_regression_tables':12,'validation_passed':validation['passed'],'bundle_bytes':(S/'downloads/disclosure-paper-results.zip').stat().st_size}))
