from pathlib import Path
import subprocess,json
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');S=R/'10-public-report';O=R/'27-literature-and-regression-paper/2026-10-21';H=Path('work/jar-paper').resolve()
modified=subprocess.check_output(['git','ls-files','-m','-z'],cwd=S).decode('utf8').split('\0');same=[];changed=[]
for name in filter(None,modified):
 p=S/name;assert str(p.resolve()).startswith(str(S.resolve()))
 old=subprocess.check_output(['git','show','HEAD:'+name],cwd=S);new=p.read_bytes()
 if old.replace(b'\r\n',b'\n')==new.replace(b'\r\n',b'\n'):same.append(name)
 else:
  if p.suffix in ['.csv','.json','.html','.md','.txt','.svg','.css','.js']:p.write_bytes(new.replace(b'\r\n',b'\n'))
  changed.append(name)
if same:
 p=H/'restore-noop-paths.nul';p.write_bytes(('\0'.join(same)+'\0').encode('utf8'));subprocess.run(['git','restore','--worktree','--pathspec-from-file='+str(p),'--pathspec-file-nul'],cwd=S,check=True)
newfiles=list(filter(None,subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=S).decode('utf8').split('\0')))
paths=changed+newfiles
for name in newfiles:
 p=S/name;assert str(p.resolve()).startswith(str(S.resolve()))
 if p.suffix in ['.csv','.json','.html','.md','.txt','.svg','.css','.js']:p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
p=H/'stage-paths.nul';p.write_bytes(('\0'.join(paths)+'\0').encode('utf8'));subprocess.run(['git','add','--pathspec-from-file='+str(p),'--pathspec-file-nul'],cwd=S,check=True)
report={'semantic_changes':changed,'new_files':newfiles,'newline_or_stat_only_restored':same,'staged_files':len(paths)};(O/'audit/git-semantic-change-manifest.json').write_text(json.dumps(report,indent=2),encoding='utf8');print(json.dumps({'semantic_changes':len(changed),'new_files':len(newfiles),'noops_restored':len(same),'staged':len(paths)}))
check=subprocess.run(['git','-c','core.whitespace=cr-at-eol','diff','--cached','--check'],cwd=S,capture_output=True,text=True);(O/'audit/git-diff-check.txt').write_text(check.stdout+check.stderr,encoding='utf8');assert check.returncode==0
print(subprocess.check_output(['git','diff','--cached','--stat'],cwd=S,text=True))
