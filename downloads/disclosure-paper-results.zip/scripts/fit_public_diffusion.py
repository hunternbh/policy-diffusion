"""JIBS-aligned adoption-status models and fully labelled design sensitivities."""
import os
for name in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:os.environ[name]='1'
from pathlib import Path
import sys,json,warnings,hashlib,datetime
sys.path.insert(0,'work/empirical-deps')
import pandas as pd,numpy as np,statsmodels.api as sm
from scipy.special import expit
from scipy.stats import t
from statsmodels.stats.multitest import multipletests
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'27-literature-and-regression-paper/2026-10-21';F=pd.read_parquet(O/'data/lagged-mechanism-panel.parquet');F['row_id']=np.arange(len(F));dom=pd.read_csv(O/'data/JIBS-domestic-controls.csv');dom['year']+=1;fields=['gdp_growth_pct','eu_export_share','fdi_gdp','imports_gdp','reg_quality','stock_market_cap_gdp_pct'];dom=dom.rename(columns={c:'dom_'+c for c in fields});F=F.merge(dom[['iso3','year']+['dom_'+c for c in fields]],on=['iso3','year'],how='left',validate='many_to_one')
weights=pd.read_csv(O/'tables/liquidity-grid-family-contributions.csv');weights=weights[weights.calendar.eq('reviewed_following_year_outcome')&weights.outcome.eq('log_spread')&weights.country_weight.eq('gdp_country')&weights.post_window.eq('first_year')&weights.policy_scope.eq('all_recorded_families')&weights.focal_cases.eq('all_documented')&weights.controls.eq('none')&weights.family_weight.eq('baseline_market_cap_family')];cap=weights.set_index('family').pre_cap_mass.to_dict();F=F[F.family.isin(cap)].copy();terms=['trade_fixed2000','gdp_learning_known_universe','language','financial_dependence'];scales={'trade_fixed2000':.1,'trade_fixed2000_strict':.1,'trade_annual':.1,'language':.1,'legal':.1,'igo':.1,'gdp_learning':1.,'gdp_learning_known_universe':1.,'gdp_learning_80pct':1.,'financial_dependence':1.};rows=[];diags=[];members=[];masses=[]
# Main: jointly estimated four mechanisms, independent choices, status, year FE.
specs=[('primary_joint',terms,False,False,False,'status_event',False)]
specs += [('separate_maximal_'+term,[term],False,False,False,'status_event',False) for term in terms]
specs += [('separate_common_'+term,[term],True,False,False,'status_event',False) for term in terms]
specs += [('joint_domestic_controls',terms,True,True,False,'status_event',False),('joint_all_waves',terms,True,False,True,'status_event',False),('joint_first_adoption_timing',terms,True,False,False,'first_event',False),('joint_family_year_effects',terms,True,False,False,'status_event',True),('joint_learning_80pct_history',['trade_fixed2000','gdp_learning_80pct','language','financial_dependence'],False,False,False,'status_event',False),('joint_strict_five_trade_peers',['trade_fixed2000_strict','gdp_learning','language','financial_dependence'],False,False,False,'status_event',False),('joint_annual_trade_available_window',['trade_annual','gdp_learning','language','financial_dependence'],False,False,False,'status_event',False),('joint_legal_emulation_proxy',['trade_fixed2000','gdp_learning','legal','financial_dependence'],False,False,False,'status_event',False)]
specs = [(label, ["gdp_learning_known_universe" if term=="gdp_learning" else term for term in focal] if label in {"joint_strict_five_trade_peers","joint_annual_trade_available_window","joint_legal_emulation_proxy"} else focal, common, controlled, allwaves, outcome, familyyear) for label,focal,common,controlled,allwaves,outcome,familyyear in specs]
specs += [('joint_strict_world_neighbours',['trade_fixed2000','gdp_learning','language','financial_dependence'],False,False,False,'status_event',False),('joint_reference_window_2002_2012',['trade_annual','gdp_learning_known_universe','language','financial_dependence'],False,False,False,'status_event',False)]
for fit_id,(label,focal,common,controlled,allwaves,outcome,familyyear) in enumerate(specs,1):
 q=F if allwaves else F[~F.known_collective_focal]
 if label=='joint_reference_window_2002_2012':q=q[q.year.between(2002,2012)]
 if outcome=='first_event':q=q[q.in_first_event_risk]
 required=list(dict.fromkeys(focal+(terms if common else [])+(['dom_'+c for c in fields] if controlled else [])));d=q.dropna(subset=required+[outcome]).copy()
 # Remove fixed-effect groups with no outcome variation, including separation
 # induced by fully adopted terminal years. This is support, not sign selection.
 dropped=[]
 for iteration in range(10):
  before=len(d)
  groupcols=['family','year'] if not familyyear else ['family_year']
  d['family_year']=d.family+'_'+d.year.astype(str)
  for group in groupcols:
   v=d.groupby(group)[outcome].nunique();remove=set(v[v.lt(2)].index);dropped.extend((group,str(v)) for v in remove);d=d[~d[group].isin(remove)].copy()
  if len(d)==before:break
 n=len(d);nc=d.iso3.nunique();events=int(d[outcome].sum());X={};scaling={}
 for term in focal:
  X[term]=d[term]/scales[term];scaling[term]={'unit':scales[term]}
 for term in (['dom_'+c for c in fields] if controlled else []):
  x=d[term].astype(float);sd=x.std(ddof=0)
  if sd>1e-12:X[term]=(x-x.mean())/sd;scaling[term]={'mean':float(x.mean()),'sd':float(sd)}
 X=pd.DataFrame(X,index=d.index);X.insert(0,'intercept',1.)
 if familyyear:X=pd.concat([X,pd.get_dummies(d.family_year,prefix='FY',drop_first=True,dtype=float)],axis=1)
 else:X=pd.concat([X,pd.get_dummies(d.family,prefix='F',drop_first=True,dtype=float),pd.get_dummies(d.year,prefix='Y',drop_first=True,dtype=float)],axis=1)
 xx=X.to_numpy(float);y=d[outcome].to_numpy(float);k=xx.shape[1];rank=np.linalg.matrix_rank(xx) if len(xx) else 0;support=n>=50 and nc>=15 and events>=10 and n-events>=10 and rank==k and n>k
 base={'specification':label,'outcome_design':outcome,'rows':n,'countries':nc,'families':d.family.nunique(),'events_or_status_ones':events,'sample_sha256':hashlib.sha256(','.join(map(str,sorted(d.row_id))).encode()).hexdigest(),'fixed_effects':'family-year' if familyyear else 'family + year','focal_cases':'all_documented' if allwaves else 'independent_choices','status':'estimated' if support else 'not_estimated_insufficient_support'}
 for scheme in ['equal_family','baseline_market_cap_family']:
  b={**base,'family_weight':scheme,'fit_id':f'J{fit_id:03}_{scheme}'};diagnostic={**b,'focal_terms':focal,'design_columns':k,'rank':int(rank),'dropped_constant_FE_groups':dropped,'scaling':scaling}
  if not support:
   rows.extend({**b,'term':term} for term in focal);diags.append(diagnostic);continue
  mass={f:1. if scheme=='equal_family' else cap[f] for f in d.family.unique()};total=sum(mass.values());count=d.groupby('family').size().to_dict();w=np.array([n*mass[f]/total/count[f] for f in d.family])
  for f in sorted(mass):masses.append({'fit_id':b['fit_id'],'specification':label,'family_weight':scheme,'family':f,'weight':mass[f]/total,'usable_rows':count[f]})
  members.extend({'fit_id':b['fit_id'],'row_id':int(r),'likelihood_weight':float(v)} for r,v in zip(d.row_id,w))
  try:
   with warnings.catch_warnings(record=True) as warns:
    warnings.simplefilter('always');fit=sm.GLM(y,X,family=sm.families.Binomial(),freq_weights=w).fit(maxiter=300,tol=1e-10)
   beta=np.asarray(fit.params);p=expit(xx@beta);score=xx*(w*(y-p))[:,None];bread=np.linalg.inv(xx.T@((w*p*(1-p))[:,None]*xx));s=np.stack([score[d.iso3.eq(iso).to_numpy()].sum(axis=0) for iso in sorted(d.iso3.unique())]);cov=bread@(s.T@s)@bread*nc/(nc-1)*(n-1)/(n-k);se=np.sqrt(np.diag(cov));stable=fit.converged and not warns and np.isfinite(beta).all() and np.isfinite(se).all() and (se>0).all() and max(abs(beta))<30 and np.max(abs(score.sum(axis=0)))<1e-5
   diagnostic.update(converged=bool(fit.converged),warnings=[str(v.message) for v in warns],max_abs_score=float(np.max(abs(score.sum(axis=0)))),max_abs_coefficient=float(max(abs(beta))));b['status']='estimated' if stable else 'unstable_withheld'
   for term in focal:
    rr={**b,'term':term,'unit':'10_percentage_point_peer_share' if scales[term]==.1 else 'binary_learning' if 'learning' in term else 'one_percentage_point_GDP'}
    if stable:
     j=list(X.columns).index(term);value=float(beta[j]);sd=float(se[j]);crit=t.ppf(.975,nc-1);rr.update(coefficient=value,standard_error=sd,p_value=float(2*t.sf(abs(value/sd),nc-1)),odds_ratio=float(np.exp(value)),odds_low=float(np.exp(value-crit*sd)),odds_high=float(np.exp(value+crit*sd)))
    rows.append(rr)
  except Exception as e:
   rows.extend({**b,'term':term,'status':'fit_failed_withheld'} for term in focal);diagnostic['error']=str(e)
  diags.append(diagnostic)
T=pd.DataFrame(rows);ok=T.status.eq('estimated');primary=T.specification.eq('primary_joint');T['holm_primary_8_p']=np.nan;T['holm_all_JIBS_models_p']=np.nan
if (primary&ok).any():
 values=T.loc[primary&ok,'p_value'].to_numpy();T.loc[primary&ok,'holm_primary_8_p']=multipletests(np.r_[values,np.ones(8-len(values))],method='holm')[1][:len(values)]
if ok.any():T.loc[ok,'holm_all_JIBS_models_p']=multipletests(T.loc[ok,'p_value'],method='holm')[1]
T.to_csv(O/'tables/JIBS-aligned-diffusion-models.csv',index=False);T[primary].to_csv(O/'tables/diffusion-primary.csv',index=False);pd.DataFrame(masses).to_csv(O/'tables/JIBS-family-weights.csv',index=False);pd.DataFrame(members).to_parquet(O/'audit/JIBS-exact-memberships-local.parquet',index=False);(O/'audit/JIBS-model-diagnostics.json').write_text(json.dumps(diags,indent=2),encoding='utf8')
summary={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'attempted_coefficient_cells':len(T),'stable_coefficients':int(ok.sum()),'primary_attempted':int(primary.sum()),'primary_stable':int((primary&ok).sum()),'primary_Holm_below_05':int(T.holm_primary_8_p.lt(.05).sum()),'all_model_Holm_below_05':int(T.holm_all_JIBS_models_p.lt(.05).sum()),'status_counts':T.status.value_counts().to_dict(),'main_definition':'Joint four-mechanism adoption-status logit, year + family effects, independent national choices; paired family weights.','not_exact_replication':'Country rather than original country coverage; documented histories only, fixed-2000 trade peers and language proxy; no comparable ordinal scale. Contemporary revised macro vintages, not real-time information.'};(O/'audit/diffusion-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary));print(T[primary].to_string(index=False))
