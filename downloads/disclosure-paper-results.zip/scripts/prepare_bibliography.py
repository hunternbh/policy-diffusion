from pathlib import Path
import json,re
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'27-literature-and-regression-paper/2026-10-21';p=O/'literature/literature-evidence-matrix.json';refs=json.loads(p.read_text(encoding='utf8'))
for r in refs:
 if r['citation']=='Welker (1995)':r.update(research_relevance='Higher disclosure rankings are associated with lower relative bid-ask spreads; endogenous disclosure and informed trading remain relevant.',publication='Contemporary Accounting Research 11: 801-827')
 if r['citation']=='Healy, Hutton and Palepu (1999)':r.update(research_relevance='Sustained disclosure-rating increases accompany changes in liquidity, analyst following and institutional ownership, with selection limiting causal interpretation.',publication='Contemporary Accounting Research 16: 485-520')
 if r['citation']=='Healy and Palepu (2001)':r.update(research_relevance='Review of disclosure incentives, regulated reporting, voluntary communication and information intermediaries.',publication='Journal of Accounting and Economics 31: 405-440')
 r['title']=r['title'].rstrip('*')
p.write_text(json.dumps(refs,indent=2,ensure_ascii=False),encoding='utf8')
plan=O/'analysis-plan.json';j=json.loads(plan.read_text(encoding='utf8'));j['numerical_support_clarification']={'rule':'Withhold FE models with effectively zero residualised outcome variance, rank deficiency at numerical tolerance, nonfinite or zero clustered standard errors. Calculate absorbed df from actual FE graph connected components.','reason':'An absorbed outcome or zero numerical variance is not an estimated null effect; all failed cells remain listed.'};j['table_presentation']={'total':15,'estimated_regression_tables':12,'regression_support_diagnostic':1,'sample_and_institutional_tables':2,'note':'The reference-style public-sample logit table is a support diagnostic because none of the attempted models is stable; it is not counted as one of the twelve tables containing estimated regression coefficients.'};plan.write_text(json.dumps(j,indent=2),encoding='utf8')
print('Bibliography summaries shortened; actual table and numerical-support status documented.')
