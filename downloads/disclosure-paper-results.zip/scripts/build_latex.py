"""One editable manuscript, one BibTeX database, one figure/table asset folder."""
from pathlib import Path
import json,re,shutil,unicodedata,hashlib,zipfile
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'27-literature-and-regression-paper/2026-10-21';P=O/'paper/latex';P.mkdir(exist_ok=True);A=P/'figure_tables';A.mkdir(exist_ok=True);doc=json.loads((O/'paper/manuscript-prose.json').read_text(encoding='utf8'));tables=json.loads((O/'paper/tables.json').read_text(encoding='utf8'));metadata={r['citation']:r for r in json.loads((O/'literature/latex-bibliography-metadata.json').read_text(encoding='utf8'))};refs=doc['references'];cached=[]
for p in (O/'sources').glob('Crossref-*.json'):cached.extend(json.loads(p.read_text(encoding='utf8')).get('message',{}).get('items',[]))
def norm(s):return re.sub('[^a-z0-9]','',unicodedata.normalize('NFKD',s).encode('ascii','ignore').decode().lower())
def tex(s):
 s=str(s).replace('’',"'").replace('‘',"'").replace('“','``').replace('”',"''").replace('–','--').replace('—','---').replace('−','-').replace('\u00a0',' ')
 special={'\\':r'\textbackslash{}','&':r'\&','%':r'\%','$':r'\$','#':r'\#','_':r'\_','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}'}
 return ''.join(special.get(c,c) for c in s)
def author_list(r):
 m=metadata.get(r['citation'],{}).get('metadata',{});first=re.split(r',| and | et al\.',r['citation'].rsplit(' (',1)[0])[0];aa=m.get('author',[])
 for item in cached:
  if item.get('title') and norm(item['title'][0].rstrip('*'))==norm(r['title'].rstrip('*')) and item.get('author') and norm(item['author'][0].get('family',''))==norm(first):aa=item['author'];break
 # A same-title digest is not the cited research article. Validate authors too.
 if aa and norm(aa[0].get('family',''))==norm(first):
  return ' and '.join(tex(a.get('family','').title() if a.get('family','').isupper() else a.get('family',''))+(', '+tex(a['given'].title() if a['given'].isupper() else a['given']) if a.get('given') else '') for a in aa)
 if r['citation']=='Beyer et al. (2010)':return 'Beyer, Anne and Cohen, Daniel and Lys, Thomas and Walther, Beverly'
 if r['citation']=='Roth et al. (2023)':return "Roth, Jonathan and Sant'Anna, Pedro H. C. and Bilinski, Alyssa and Poe, John"
 authors=r['citation'].rsplit(' (',1)[0];assert 'et al.' not in authors,r['citation'];return ' and '.join('{'+tex(a.strip())+'}' for a in re.split(r',\s*| and ',authors) if a.strip())
keys={};bib=[];bib_audit=[]
for r in refs:
 year=re.search(r'\((\d{4})\)',r['citation']).group(1);first=re.split(r',| and | et al\.',r['citation'].rsplit(' (',1)[0])[0];key=norm(first)+year;assert key not in keys.values();keys[r['citation']]=key;pub=r['publication'];mm=re.match(r'(.+?)\s+(\d+):\s*(.+)$',pub)
 fields={'author':author_list(r),'title':'{'+tex(r['title'])+'}','journal':tex(mm.group(1) if mm else pub),'year':year}
 if mm:fields.update(volume=mm.group(2),pages=mm.group(3).replace('-','--'))
 if 'doi.org/' in r['primary_url']:fields['doi']=r['primary_url'].split('doi.org/')[-1]
 else:fields['url']=r['primary_url']
 bib.append('@article{'+key+',\n'+',\n'.join('  '+k+' = {'+v+'}' for k,v in fields.items())+'\n}')
 bib_audit.append({'key':key,'citation':r['citation'],'authors':fields['author'],'source_url':r['primary_url']})
(P/'ref.bib').write_text('\n\n'.join(bib)+'\n',encoding='utf8')
def prose(s):
 s=s.replace('’',"'");matching={c.replace('’',"'"):k for c,k in keys.items()};chunks=[];cursor=0;pattern='|'.join(re.escape(c) for c in sorted(matching,key=len,reverse=True))
 for m in re.finditer(pattern,s):chunks.extend([tex(s[cursor:m.start()]),'\\citet{'+matching[m.group()]+'}']);cursor=m.end()
 chunks.append(tex(s[cursor:]));return ''.join(chunks).replace('Delta L\\_cfg',r'\(\Delta L_{cfg}\)')
abstract='We examine whether disclosure regulation is associated with a general improvement in stock-market liquidity and how these requirements spread internationally. We combine a source-linked policy register with Datastream observations for 90 jurisdictions during 2000–2025. Ten public-disclosure families define the primary universe; eight support following-year comparisons and six support a longer window. Country-cohort comparisons hold companies fixed and exclude already-treated countries and unknown histories from the control group. Following-year log-spread estimates are −0.022 with equal family weights and −0.047 with market-cap family weights. Both longer-window spread estimates are also negative, but uncertainty, other liquidity outcomes and pre-policy patterns limit a general causal conclusion. Confidential reporting is examined separately. Diffusion associations depend on the sample and controls for common adoption waves. The findings highlight the importance of information audience, implementation timing and the definition of the pooled effect.'
assert len(abstract.split())<=150,len(abstract.split())
parts=[r'''\documentclass[12pt,letterpaper]{article}
% Single-file manuscript. Standard packages only; no custom class or style.
% Compile paper.tex with BibTeX support (e.g., latexmk -pdf paper.tex).
\usepackage[T1]{fontenc}
\usepackage[utf8]{inputenc}
\usepackage{mathptmx}
\usepackage[margin=1in]{geometry}
\usepackage{setspace,graphicx,booktabs,array,longtable}
\usepackage[authoryear,round,longnamesfirst]{natbib}
\usepackage[hidelinks,breaklinks]{hyperref}
\bibpunct{(}{)}{;}{a}{}{,}
\setlength{\parindent}{0.5in}
\setlength{\parskip}{0pt}
\setlength{\emergencystretch}{3em}
\setlength{\tabcolsep}{4pt}
\renewcommand{\arraystretch}{1.12}
\setcounter{secnumdepth}{1}
\renewcommand{\thesection}{\Roman{section}}
\makeatletter
\renewcommand{\section}{\@startsection{section}{1}{\z@}{-3.5ex plus -1ex minus -.2ex}{2.3ex plus .2ex}{\centering\normalfont\normalsize\bfseries}}
\renewcommand{\subsection}{\@startsection{subsection}{2}{\z@}{-3.25ex plus -1ex minus -.2ex}{1.5ex plus .2ex}{\normalfont\normalsize\bfseries}}
\makeatother
\title{'''+tex(doc['title'])+r'''}
\author{'''+tex(doc['author'])+r'''}
\date{'''+tex(doc['date'])+r'''}
\begin{document}
\pagenumbering{roman}
\doublespacing
\begin{titlepage}
\maketitle
\thispagestyle{empty}
\begin{abstract}
\noindent '''+tex(abstract)+r'''
\end{abstract}
\noindent\textit{Keywords:} disclosure regulation; stock liquidity; international reporting; policy diffusion.
\begin{center}Research working paper\end{center}
\end{titlepage}
\pagenumbering{arabic}
''']
for section in doc['sections']:
 if section['heading'].startswith('6.'):parts.append('\\clearpage\n')
 heading=re.sub(r'^\d+\.\s*','',section['heading']);parts.append('\\section{'+tex(heading.upper())+'}\n')
 for paragraph in section['paragraphs']:
  if paragraph.startswith('The disclosure literature consequently'):paragraph+=' Leuz and Wysocki (2016) place these reporting choices within the wider economics of disclosure regulation.'
  if re.match(r'^\d+\.\d+\.\s',paragraph):parts.append('\\subsection{'+tex(re.sub(r'^\d+\.\d+\.\s*','',paragraph))+'}\n')
  elif 'Delta L_cfg = alpha_fg + beta_fg Treat_cg + error_cfg.' in paragraph:
   paragraph=paragraph.replace('Delta L_cfg = alpha_fg + beta_fg Treat_cg + error_cfg.','EQUATIONPLACEHOLDER')
   parts.append(prose(paragraph).replace('EQUATIONPLACEHOLDER',r'\begin{equation}\Delta L_{cfg}=\alpha_{fg}+\beta_{fg}\,\mathrm{Treat}_{cg}+\varepsilon_{cfg}.\end{equation}')+'\n\n')
  else:parts.append(prose(paragraph)+'\n\n')
parts.append(r'''\clearpage
\renewcommand{\refname}{REFERENCES}
\setlength{\bibsep}{0pt}
\bibliographystyle{apalike}
\bibliography{ref}
\clearpage
\singlespacing
''')
def tabular(t,title=None):
 n=len(t['columns']);fractions=([.24,.12,.128,.128,.128,.128,.128] if n==7 else [.33,.13,.17,.18,.19] if t.get('number')==2 else [.35,.10,.1833,.1833,.1834] if t.get('number')==5 else [.30,.17,.265,.265] if n==4 else [.29,.1775,.1775,.1775,.1775] if n==5 else [1/n]*n)
 widths=[f'>{{\\raggedright\\arraybackslash}}p{{\\dimexpr {v:.5f}\\linewidth-8pt\\relax}}' for v in fractions]
 def cell(s):return r'\newline '.join(tex(z) for z in str(s).strip('\n').split('\n'))
 header=' & '.join('\\textbf{'+cell(c)+'}' for c in t['columns'])+r' \\'
 rows='\n'.join(' & '.join(cell(c) for c in row)+r' \\[3pt]' for row in t['rows'])
 if title:
  start='\\begin{longtable}{'+''.join(widths)+'}\n\\caption{'+tex(title)+'}\\label{tab:'+str(t['number'])+r'}\\'+'\n'
 else:return '\\begin{tabular}{'+''.join(widths)+'}\n'+r'\toprule'+'\n'+header+r'\midrule'+'\n'+rows+'\n'+r'\bottomrule'+'\n\\end{tabular}\n'
 return start+r'\toprule'+'\n'+header+r'\midrule'+'\n\\endfirsthead\n'+r'\toprule'+'\n'+header+r'\midrule'+'\n\\endhead\n'+r'\midrule\multicolumn{'+str(n)+r'}{r}{\textit{Continued on next page}}\\\endfoot'+'\n\\bottomrule\\endlastfoot\n'+rows+'\n\\end{longtable}\n'
for t in tables:
 parts.append('\\clearpage\n{\\fontsize{9}{11}\\selectfont\n'+tabular(t,t['title'])+'\n\\noindent '+tex(t['note'])+'\n')
 for panel in t.get('panels',[]):parts.append('\n\\par\\medskip\n\\noindent\\textit{'+tex(panel['title'])+'}\\par\\smallskip\\noindent\n'+tabular(panel)+'\\par\n')
 parts.append('}\n')
 # Plain CSV assets for editing the table values without extra .tex inputs.
 import csv
 with (A/f'table-{t["number"]:02d}.csv').open('w',encoding='utf8',newline='') as f:writer=csv.writer(f);writer.writerow(t['columns']);writer.writerows(t['rows'])
snap=json.loads((O/'paper/paper-data-snapshot.json').read_text(encoding='utf8'))
for figure in snap['figure_notes']:
 filename=figure['name']+'.png';shutil.copy2(O/'figures'/filename,A/filename);caption=re.sub(r'^Figure \d+\.\s*','',figure['title']);parts.append(r'\clearpage\begin{figure}[p]\centering'+'\n'+r'\includegraphics[width=\linewidth,height=0.72\textheight,keepaspectratio]{figure_tables/'+filename+'}\n\\caption{'+tex(caption)+'}\n{\\footnotesize\\raggedright '+tex(figure['note'])+'\\par}\n\\end{figure}\n')
parts.append('\\clearpage\n\\end{document}\n');source='\n'.join(parts)
if (P/'main.tex').exists() and not (P/'paper.tex').exists():(P/'main.tex').rename(P/'paper.tex')
(P/'paper.tex').write_text(source,encoding='utf8')
assert sorted(p.name for p in P.iterdir())==['figure_tables','paper.tex','ref.bib'],list(P.iterdir())
audit={'abstract_words':len(abstract.split()),'main_source':'paper.tex','bibliography':'ref.bib','asset_folder':'figure_tables','extra_tex_inputs':False,'custom_class_or_style':False,'body_font_points':12,'body_spacing':'double','margin_inches':1,'tables':len(tables),'figures':3,'references':len(refs),'citation_keys':len(keys),'all_references_cited_in_body':all('\\citet{'+k+'}' in source for k in keys.values()),'authors_metadata':bib_audit,'style_reference':'https://aaahq.org/Research/Journals/Manuscript-Preparation-Guide','source_sha256':hashlib.sha256(source.encode()).hexdigest()};(O/'audit/latex-source-audit.json').write_text(json.dumps(audit,indent=2),encoding='utf8');print(json.dumps({k:v for k,v in audit.items() if k!='authors_metadata'}))
