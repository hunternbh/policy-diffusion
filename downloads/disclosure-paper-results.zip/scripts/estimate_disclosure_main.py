from pathlib import Path
import sys,json,itertools,shutil
sys.path.insert(0,'work/empirical-deps')
import pandas as pd,numpy as np
from statsmodels.stats.multitest import multipletests
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'27-literature-and-regression-paper/2026-10-21';P=R/'26-adoption-weighting-and-design-audit/2026-10-19';plan=json.loads((O/'analysis-plan.json').read_text(encoding='utf8'));script=Path('work/design-audit/liquidity_grid.py');code=script.read_text(encoding='utf8');ns={'__file__':str(script)};exec(compile(code[:code.index('rows=[];familyrows=')],str(script),'exec'),ns);C=ns['c'];rows=[];famrows=[];weightrows=[];infs=[];cache={};scopes={'public_disclosure':set(plan['headline_families']),'public_and_confidential':set(plan['all_disclosure_families']),'broader_17_families':set(C.regulation_family)}
for out,window in itertools.product(ns['outcomes'],['first_year','mean_0_2']):
 for fam,ev in C.groupby('regulation_family'):
  fit=ns['estimate_family'](ev,'reviewed_G',window,'gdp_country',False,out,1)
  if fit:
   cache[fam]=fit;famrows.append({'family':fam,'outcome':out,'post_window':window,'estimate':fit['estimate'],'country_se':float(np.linalg.norm(fit['influence'])),'treated_countries':fit['treated_countries'],'comparison_countries':fit['comparison_countries'],'cohorts':fit['cohorts'],'cohort_years':fit['cohort_years'],'cap_mass':fit['cap']})
 for scope,include in scopes.items():
  supported=[(f,cache[f]) for f in sorted(include) if f in cache]
  for scheme in ['equal_family','baseline_market_cap_family']:
   mass=np.ones(len(supported)) if scheme=='equal_family' else np.array([v['cap'] for _,v in supported]);mass/=mass.sum();b=sum(w*r['estimate'] for w,(f,r) in zip(mass,supported));inf=sum(w*r['influence'] for w,(f,r) in zip(mass,supported));sid=f'M{len(rows)+1:03}';rows.append({'scope':scope,'outcome':out,'post_window':window,'family_weight':scheme,'families':len(supported),'specification_id':sid,**ns['diagnostics'](b,inf)})
   weightrows.extend({'scope':scope,'outcome':out,'post_window':window,'family_weight':scheme,'specification_id':sid,'family':f,'weight':float(w),'family_estimate':r['estimate'],'pre_cap_mass':r['cap'],'cohorts':r['cohorts'],'cohort_years':r['cohort_years'],'treated_countries':r['treated_countries']} for w,(f,r) in zip(mass,supported));infs.extend({'specification_id':sid,'iso3':iso,'influence':float(v)} for iso,v in zip(ns['isos'],inf))
 cache={}
T=pd.DataFrame(rows);T['holm_36_scope_comparisons_p']=multipletests(T.p_value,method='holm')[1];T['holm_primary_12_p']=np.nan;main=T.scope.eq('public_disclosure');T.loc[main,'holm_primary_12_p']=multipletests(T.loc[main,'p_value'],method='holm')[1];T.to_csv(O/'tables/main-liquidity.csv',index=False);pd.DataFrame(famrows).to_csv(O/'tables/main-family-estimates.csv',index=False);pd.DataFrame(weightrows).to_csv(O/'tables/main-family-weights.csv',index=False);pd.DataFrame(infs).to_csv(O/'audit/main-country-influences.csv',index=False)
# Preserve the previously estimated matrix, but restrict eligibility of diffusion
# to the same public-disclosure family set before every re-estimation.
oldW=pd.read_csv(P/'tables/liquidity-grid-family-contributions.csv');oldW=oldW[oldW.family.isin(plan['headline_families'])];oldW.to_csv(O/'tables/liquidity-grid-family-contributions.csv',index=False)
summary={'public_following_year_families':int(T[main&T.post_window.eq('first_year')].families.iloc[0]),'public_years_1_3_families':int(T[main&T.post_window.eq('mean_0_2')].families.iloc[0]),'combined_following_year_families':int(T[T.scope.eq('public_and_confidential')&T.post_window.eq('first_year')].families.iloc[0]),'primary_Holm_below_05':int(T.holm_primary_12_p.lt(.05).sum()),'all_scope_cells':len(T),'inference':ns['plan']['inference']};(O/'audit/disclosure-main-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary));print(T[main].to_string(index=False))
