import os
for k in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys,json,hashlib,itertools,datetime
sys.path.insert(0,'work/empirical-deps')
import pandas as pd,numpy as np
from scipy.stats import t
from statsmodels.stats.multitest import multipletests
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'27-literature-and-regression-paper/2026-10-21';P=R/'26-adoption-weighting-and-design-audit/2026-10-19';F=pd.read_parquet(P/'data/lagged-mechanism-panel.parquet');F['row_id']=np.arange(len(F));F=F[~F.known_collective_focal].copy();weights=pd.read_csv(P/'tables/liquidity-grid-family-contributions.csv');q=pd.read_csv(P/'tables/liquidity-primary.csv');sid=q[q.outcome.eq('log_spread')&q.post_window.eq('first_year')&q.family_weight.eq('baseline_market_cap_family')].specification_id.iloc[0];cap=weights[weights.specification_id.eq(sid)].set_index('family').pre_cap_mass.to_dict();F=F[F.family.isin(cap)];terms=['trade_fixed2000','gdp_learning_known_universe','language','financial_dependence'];scales=[.1,1.,.1,1.];rows=[];members=[];diags=[]
def demean(Z,w,codes):
 sums=np.bincount(codes,weights=w);means=np.zeros((len(sums),Z.shape[1]))
 for j in range(Z.shape[1]):means[:,j]=np.bincount(codes,weights=w*Z[:,j],minlength=len(sums))/sums
 return Z-means[codes]
plan=json.loads((O/'analysis-plan.json').read_text(encoding='utf8'));cap={f:v for f,v in cap.items() if f in plan['headline_families']};F=F[F.family.isin(cap)].copy()
plan['family_wave_sensitivity_addendum']={'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'prior_extension_results_seen':True,'reason':'Country-family plus year effects may leave common family-specific adoption waves in language and learning associations. Add country-family plus family-year effects for every outcome, predictor set and weight, without selecting by result. Retain both designs and adjust across all 64 attempts.'}
(O/'analysis-plan.json').write_text(json.dumps(plan,indent=2),encoding='utf8')
for outcome,joint,scheme,fe in itertools.product(['status_event','first_event'],[False,True],['equal_family','baseline_market_cap_family'],['country_family_and_year','country_family_and_family_year']):
 for focal in ([terms] if joint else [[x] for x in terms]):
  a=F if outcome=='status_event' else F[F.in_first_event_risk];a=a.dropna(subset=focal+[outcome]).copy();a['country_family']=a.iso3+'_'+a.family;g=pd.factorize(a.country_family)[0];yrlab=a.year if fe=='country_family_and_year' else a.family+'_'+a.year.astype(str);yr=pd.factorize(yrlab)[0];n=len(a);nc=a.iso3.nunique();mass={f:1. if scheme=='equal_family' else cap[f] for f in a.family.unique()};counts=a.groupby('family').size();w=np.array([n*mass[f]/sum(mass.values())/counts[f] for f in a.family]);xx=np.column_stack([a[c]/scales[terms.index(c)] for c in focal]);y=a[outcome].to_numpy(float);Z=np.column_stack([y,xx]);iterations=0
  for iteration in range(10000):
   old=Z.copy();Z=demean(demean(Z,w,g),w,yr);iterations=iteration+1
   if np.max(abs(Z-old))<1e-10:break
  xx=Z[:,1:];y=Z[:,0];k=len(focal);ng=len(set(g));nh=len(set(yr));parent=list(range(ng+nh))
  def find(i):
   while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
   return i
  for gi,hi in zip(g,yr):parent[find(int(gi))]=find(ng+int(hi))
  components=len({find(j) for j in range(ng+nh)});kfe=ng+nh-components;sv=np.linalg.svd(xx,compute_uv=False);rank=int(np.sum(sv>max(1e-9,sv.max()*1e-8))) if len(sv) else 0;support=n>=50 and nc>=15 and n>k+kfe+3 and rank==k and np.std(y)>1e-9;label=('joint' if joint else 'separate')+'_'+outcome;base={'model':label,'fixed_effects':fe,'outcome':outcome,'family_weight':scheme,'rows':n,'countries':nc,'families':a.family.nunique(),'country_family_FE':a.country_family.nunique(),'year_or_family_year_FE':len(set(yr)),'absorbed_df':kfe,'FE_graph_components':components,'within_outcome_sd':float(np.std(y)),'sample_sha256':hashlib.sha256(','.join(map(str,sorted(a.row_id))).encode()).hexdigest(),'status':'estimated' if support else 'insufficient_support_rank_or_within_variation','within_iterations':iterations}
  if not support:rows.extend({**base,'term':c} for c in focal);continue
  inv=np.linalg.inv(xx.T@(w[:,None]*xx));b=inv@(xx.T@(w*y));res=y-xx@b;score=xx*(w*res)[:,None];s=pd.DataFrame(score).assign(iso=a.iso3.to_numpy()).groupby('iso').sum().to_numpy();cov=inv@(s.T@s)@inv*nc/(nc-1)*(n-1)/(n-k-kfe);se=np.sqrt(np.diag(cov));crit=t.ppf(.975,nc-1)
  if not np.isfinite(se).all() or min(se)<1e-12:
   rows.extend({**base,'term':c,'status':'unstable_variance_withheld'} for c in focal);continue
  for j,c in enumerate(focal):rows.append({**base,'term':c,'estimate':float(b[j]),'country_se':float(se[j]),'ci_low':float(b[j]-crit*se[j]),'ci_high':float(b[j]+crit*se[j]),'p_value':float(2*t.sf(abs(b[j]/se[j]),nc-1)),'unit':'per_10pp_peer_share' if c in ['trade_fixed2000','language'] else 'binary_learning' if c=='gdp_learning_known_universe' else 'per_1pp_GDP'})
  members.extend({'model':label,'fixed_effects':fe,'terms':';'.join(focal),'family_weight':scheme,'row_id':int(i),'weight':float(v)} for i,v in zip(a.row_id,w));diags.append({**base,'terms':focal,'max_weighted_residual_CF_mean':float(max(abs(np.bincount(g,weights=w*res)/np.bincount(g,weights=w))))})
T=pd.DataFrame(rows);T['holm_within_matrix_p']=multipletests(T.p_value.fillna(1),method='holm')[1];T.to_csv(O/'tables/diffusion-country-family-FE.csv',index=False);pd.DataFrame(members).to_parquet(O/'audit/diffusion-within-memberships-local.parquet',index=False);(O/'audit/diffusion-within-diagnostics.json').write_text(json.dumps(diags,indent=2),encoding='utf8');summary={'attempted_coefficients':len(T),'estimated_coefficients':int(T.status.eq('estimated').sum()),'Holm_below_05':int(T.holm_within_matrix_p.lt(.05).sum()),'fixed_effects':'country-family and year','inference':'Weighted linear probability associations with country clustered errors; not causal peer effects.'};(O/'audit/diffusion-within-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary))
