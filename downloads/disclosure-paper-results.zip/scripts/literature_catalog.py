"""Primary publication metadata and a bounded, documented literature search."""
from pathlib import Path
import json,urllib.request,urllib.parse,concurrent.futures,re,datetime,difflib
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'27-literature-and-regression-paper/2026-10-21'
queries=[
('Diamond and Verrecchia (1991)','Disclosure, Liquidity, and the Cost of Capital','information theory'),
('Leuz and Verrecchia (2000)','The Economic Consequences of Increased Disclosure','disclosure and liquidity'),
('Welker (1995)','Disclosure Policy, Information Asymmetry, and Liquidity in Equity Markets','disclosure and liquidity'),
('Healy, Hutton and Palepu (1999)','Stock Performance and Intermediation Changes Surrounding Sustained Increases in Disclosure','disclosure and liquidity'),
('Healy and Palepu (2001)','Information asymmetry, corporate disclosure, and the capital markets: A review of the empirical disclosure literature','review'),
('Beyer et al. (2010)','The financial reporting environment: Review of the recent literature','review'),
('Leuz and Wysocki (2016)','The Economics of Disclosure and Financial Reporting Regulation: Evidence and Suggestions for Future Research','review'),
('Christensen, Hail and Leuz (2021)','Mandatory CSR and sustainability reporting: economic analysis and literature review','review'),
('Daske et al. (2008)','Mandatory IFRS Reporting around the World: Early Evidence on the Economic Consequences','regulatory liquidity'),
('Christensen, Hail and Leuz (2013)','Mandatory IFRS reporting and changes in enforcement','regulatory liquidity'),
('Christensen, Hail and Leuz (2016)','Capital-Market Effects of Securities Regulation: Prior Conditions, Implementation, and Enforcement','regulatory liquidity'),
('Krueger et al. (2024)','The Effects of Mandatory ESG Disclosure Around the World','regulatory liquidity'),
('Dube and Zhu (2021)','The Disciplinary Effect of Social Media: Evidence from Firms’ Responses to Glassdoor Reviews','information audiences'),
('Blankespoor, deHaan and Marinovic (2020)','Disclosure processing costs, investors’ information choice, and equity market outcomes: A review','information processing'),
('Hail and Leuz (2006)','International Differences in the Cost of Equity Capital: Do Legal Institutions and Securities Regulation Matter?','institutions'),
('La Porta et al. (2006)','What Works in Securities Laws?','institutions'),
('La Porta et al. (1998)','Law and Finance','institutions'),
('Bhattacharya and Daouk (2002)','The World Price of Insider Trading','institutions'),
('De Simone and Olbert (2022)','Real Effects of Private Country-by-Country Disclosure','tax disclosure'),
('Johannesen and Larsen (2016)','The power of financial transparency: An event study of country-by-country reporting standards','tax disclosure'),
('Lennox, Schmidt and Thompson (2023)','Why are expanded audit reports not informative to investors? Evidence from the United Kingdom','audit disclosure'),
('Blankespoor, Miller and White (2014)','Initial Evidence on the Market Impact of the XBRL Mandate','electronic disclosure'),
('Koning, Mertens and Roosenboom (2018)','Drivers of institutional change around the world: The case of IFRS','diffusion'),
('Simmons and Elkins (2004)','The Globalization of Liberalization: Policy Diffusion in the International Political Economy','diffusion'),
('Simmons, Dobbin and Garrett (2006)','Introduction: The International Diffusion of Liberalism','diffusion'),
('Callaway and Sant’Anna (2021)','Difference-in-Differences with multiple time periods','identification'),
('Sun and Abraham (2021)','Estimating dynamic treatment effects in event studies with heterogeneous treatment effects','identification'),
('Goodman-Bacon (2021)','Difference-in-differences with variation in treatment timing','identification'),
('Baker, Larcker and Wang (2022)','How much should we trust staggered difference-in-differences estimates?','identification'),
('Rambachan and Roth (2023)','A More Credible Approach to Parallel Trends','identification'),
('Roth et al. (2023)','What’s trending in difference-in-differences? A synthesis of the recent econometrics literature','identification'),
('Amihud (2002)','Illiquidity and stock returns: cross-section and time-series effects','measurement'),
('Lesmond, Ogden and Trzcinka (1999)','A New Estimate of Transaction Costs','measurement'),
('Holm (1979)','A Simple Sequentially Rejective Multiple Test Procedure','inference')]
def clean(s):return re.sub(r'[^a-z0-9]+',' ',s.lower()).strip()
def fetch(q):
 label,title,theme=q;url='https://api.crossref.org/works?'+urllib.parse.urlencode({'query.bibliographic':title,'rows':3});req=urllib.request.Request(url,headers={'User-Agent':'Academic-policy-literature-review/1.0'})
 try:
  with urllib.request.urlopen(req,timeout=35) as f:raw=f.read()
  items=json.loads(raw)['message']['items'];item=max(items,key=lambda x:difflib.SequenceMatcher(None,clean(title),clean(' '.join(x.get('title',[])))).ratio());similarity=difflib.SequenceMatcher(None,clean(title),clean(' '.join(item.get('title',[])))).ratio();year=item.get('published',item.get('issued',{})).get('date-parts',[[None]])[0][0];abstract=re.sub('<[^>]+>',' ',item.get('abstract',''));slug=clean(label).replace(' ','-');(O/'sources'/('Crossref-'+slug+'.json')).write_bytes(raw)
  return {'citation':label,'query_title':title,'theme':theme,'metadata_title':' '.join(item.get('title',[])),'title_match_score':similarity,'DOI':item.get('DOI'),'primary_url':'https://doi.org/'+item['DOI'],'year':year,'journal':' '.join(item.get('container-title',[])),'volume':item.get('volume'),'issue':item.get('issue'),'pages':item.get('page',item.get('article-number')),'authors':item.get('author',[]),'author_abstract':abstract.strip(),'verification':'matched_primary_publication_metadata' if similarity>.9 else 'manual_review_needed','review_depth':'Publisher-deposited abstract/metadata; selected works also read locally or on official author/publisher pages. Not all full papers read.'}
 except Exception as e:return {'citation':label,'query_title':title,'theme':theme,'error':str(e),'verification':'unavailable'}
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as ex:records=list(ex.map(fetch,queries))
(O/'literature/literature-evidence-matrix.json').write_text(json.dumps(records,indent=2,ensure_ascii=False),encoding='utf8');search={'searched_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'queries':queries,'works':len(records),'scope':'Targeted accounting/finance/institutional diffusion and DiD literature, supplemented by live primary-source web searches and local literature corpus; not an exhaustive systematic review.','novelty':'No universal absence or first-study claim is established. Prior studies already examine IFRS, ESG and securities-law liquidity. Proposed contribution is common country-level comparisons across the documented wider policy set and a linked diffusion analysis.','manual_review_required':[r for r in records if r['verification']!='matched_primary_publication_metadata']};(O/'literature/search-protocol-and-novelty.json').write_text(json.dumps(search,indent=2,ensure_ascii=False),encoding='utf8');print(json.dumps({'works':len(records),'metadata_verified':sum(r['verification']=='matched_primary_publication_metadata' for r in records),'manual_review':search['manual_review_required']},ensure_ascii=False))
