from pathlib import Path
import subprocess,os,json,shutil
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'27-literature-and-regression-paper/2026-10-21';P=O/'paper/latex';B=Path('tmp/latex-paper').resolve();B.mkdir(parents=True,exist_ok=True);binary=Path(r'C:\Users\hia_n\AppData\Local\Programs\MiKTeX\miktex\bin\x64');env=os.environ.copy();env['BIBINPUTS']=str(P)+os.pathsep+env.get('BIBINPUTS','');runs=[]
commands=[[str(binary/'pdflatex.exe'),'--disable-installer','-interaction=nonstopmode','-halt-on-error','-output-directory='+str(B),'paper.tex'],[str(binary/'bibtex.exe'),str(B/'paper')],[str(binary/'pdflatex.exe'),'--disable-installer','-interaction=nonstopmode','-halt-on-error','-output-directory='+str(B),'paper.tex'],[str(binary/'pdflatex.exe'),'--disable-installer','-interaction=nonstopmode','-halt-on-error','-output-directory='+str(B),'paper.tex']]
for i,cmd in enumerate(commands):
 r=subprocess.run(cmd,cwd=P,env=env,capture_output=True,text=True,errors='replace',timeout=90);(B/f'pass-{i+1}.txt').write_text(r.stdout+r.stderr,encoding='utf8');runs.append({'pass':i+1,'binary':Path(cmd[0]).name,'exit_code':r.returncode})
 if r.returncode:print((r.stdout+r.stderr)[-5000:]);raise SystemExit(r.returncode)
log=(B/'paper.log').read_text(encoding='utf8',errors='replace');summary={'runs':runs,'undefined_citations':'Citation' in log and 'undefined' in log,'overfull_lines':[line for line in log.splitlines() if 'Overfull' in line],'PDF':str(B/'paper.pdf')};(O/'audit/latex-compilation.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary))
