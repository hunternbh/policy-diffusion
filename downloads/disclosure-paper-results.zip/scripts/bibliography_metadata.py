from pathlib import Path
import json,urllib.request,urllib.parse,re,concurrent.futures,unicodedata
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'27-literature-and-regression-paper/2026-10-21';refs=json.loads((O/'literature/literature-evidence-matrix.json').read_text(encoding='utf8'))
def norm(x):return re.sub('[^a-z0-9]','',unicodedata.normalize('NFKD',x).encode('ascii','ignore').decode().lower())
def fetch(r):
 doi=r['primary_url'].split('doi.org/')[-1] if 'doi.org/' in r['primary_url'] else None
 url='https://api.crossref.org/works/'+urllib.parse.quote(doi,safe='') if doi else 'https://api.crossref.org/works?'+urllib.parse.urlencode({'query.title':r['title'],'rows':1})
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'PolicyDiffusion-BibliographicVerification/1.0'}),timeout=25) as f:d=json.load(f)['message']
  if not doi:
   d=d['items'][0];assert norm(d['title'][0])==norm(r['title']),(r['title'],d['title'])
  assert norm(d['title'][0])==norm(r['title']),(r['title'],d['title'])
  return {'citation':r['citation'],'status':'verified_exact_title','metadata_url':url,'metadata':{k:d[k] for k in ['DOI','title','author','container-title','volume','issue','page','article-number','published','published-print','published-online'] if k in d}}
 except Exception as e:return {'citation':r['citation'],'status':'retained_existing_record','metadata_url':url,'error':str(e)}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:rows=list(ex.map(fetch,refs))
(O/'literature/latex-bibliography-metadata.json').write_text(json.dumps(rows,indent=2,ensure_ascii=False),encoding='utf8');print(json.dumps({'records':len(rows),'verified':sum(r['status']=='verified_exact_title' for r in rows),'unresolved':[r['citation'] for r in rows if r['status']!='verified_exact_title']}))
