from pathlib import Path
import sys,json
sys.path.insert(0,'work/empirical-deps')
import pandas as pd,numpy as np
from scipy.stats import t
from statsmodels.stats.multitest import multipletests
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'27-literature-and-regression-paper/2026-10-21';P=R/'26-adoption-weighting-and-design-audit/2026-10-19';A=pd.read_csv(O/'data/country-cohort-regression-inputs.csv');F=pd.read_csv(P/'tables/primary-family-estimates.csv');plan=json.loads((O/'analysis-plan.json').read_text(encoding='utf8'));isos=sorted(A.iso3.unique());idx={i:j for j,i in enumerate(isos)};K=len(isos);groups={'Public disclosure':set(plan['public_disclosure_scope']),'Confidential tax':{'CBCR_CONFIDENTIAL'}};groups['Other rules']=set(A.family)-set.union(*groups.values());out=[];infl=[];families={}
def infer(value,inf):
 nc=np.count_nonzero(abs(inf)>1e-13);se=float(np.linalg.norm(inf));crit=t.ppf(.975,max(1,nc-1));return {'estimate':float(value),'country_se':se,'ci_low':float(value-crit*se),'ci_high':float(value+crit*se),'p_value':float(2*t.sf(abs(value/se),max(1,nc-1))) if se>1e-14 else 1.}
for outcome in ['log_spread','log_impact','zero_fraction']:
 results={}
 for fam,aa in A.groupby('family'):
  rr=[]
  for g,z in aa.groupby('cohort'):
   tr=z.Treat.eq(1);co=~tr;tm=np.average(z.loc[tr,outcome],weights=z.loc[tr,'gdp_constant_usd']);cm=np.average(z.loc[co,outcome],weights=z.loc[co,'gdp_constant_usd']);inf=np.zeros(K)
   for mask,mean,sign in [(tr,tm,1),(co,cm,-1)]:
    n=int(mask.sum());w=z.loc[mask,'gdp_constant_usd'].to_numpy();values=z.loc[mask,outcome].to_numpy();jj=[idx[i] for i in z.loc[mask,'iso3']];inf[jj]=sign*w/w.sum()*(values-mean)*np.sqrt(n/(n-1) if n>1 else 1)
   rr.append((tm-cm,inf,z.loc[tr,'gdp_constant_usd'].sum(),z.loc[tr,'cap'].sum(),len(z)))
  weights=np.array([r[2] for r in rr]);weights/=weights.sum();b=sum(w*r[0] for w,r in zip(weights,rr));inf=sum(w*r[1] for w,r in zip(weights,rr));ref=F[F.family.eq(fam)&F.outcome.eq(outcome)&F.post_window.eq('first_year')].iloc[0];assert abs(b-ref.estimate)<1e-10;results[fam]=(b,inf,sum(r[3] for r in rr),sum(r[4] for r in rr))
 for scheme in ['equal_family','baseline_market_cap_family']:
  fits={}
  for group,fams in groups.items():
   names=sorted(fams&set(results));mass=np.ones(len(names)) if scheme=='equal_family' else np.array([results[f][2] for f in names]);mass/=mass.sum();b=sum(w*results[f][0] for w,f in zip(mass,names));inf=sum(w*results[f][1] for w,f in zip(mass,names));fits[group]=(b,inf);out.append({'model':'audience_'+group,'outcome':outcome,'term':'treated','family_weight':scheme,'status':'estimated','families':len(names),'country_cohort_rows':sum(results[f][3] for f in names),**infer(b,inf)})
  b=fits['Public disclosure'][0]-fits['Confidential tax'][0];inf=fits['Public disclosure'][1]-fits['Confidential tax'][1];out.append({'model':'audience_Public minus confidential','outcome':outcome,'term':'difference','family_weight':scheme,'status':'estimated','families':len(groups['Public disclosure']&set(results))+1,**infer(b,inf)})
  for group,(b,inf) in fits.items():infl.extend({'model':group,'outcome':outcome,'family_weight':scheme,'iso3':i,'influence':float(v)} for i,v in zip(isos,inf))
T=pd.DataFrame(out);N=pd.read_csv(O/'tables/new-liquidity-regressions.csv');both=pd.concat([N,T],ignore_index=True);both['holm_new_family_p']=multipletests(both.p_value.fillna(1),method='holm')[1];both.to_csv(O/'tables/new-liquidity-regressions.csv',index=False);both[both.model.str.startswith('audience_')].to_csv(O/'tables/audience-contrasts.csv',index=False);pd.DataFrame(infl).to_csv(O/'audit/audience-country-influences.csv',index=False);print(json.dumps({'audience_cells':len(T),'new_combined_focal_cells':len(both),'new_combined_Holm_below_05':int(both.holm_new_family_p.lt(.05).sum())}))
