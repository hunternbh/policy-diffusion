from pathlib import Path
import sys
sys.path.insert(0,'work/empirical-deps')
from PIL import Image,ImageOps,ImageDraw
import json
count=json.loads(Path(r'C:\Users\hia_n\Desktop\policy-diffusion\27-literature-and-regression-paper\2026-10-21\paper\paper-data-snapshot.json').read_text(encoding='utf8'))['pages']
files=[Path('outputs')/f'disclosure-paper-page-{i:02d}.png' for i in range(1,count+1)]
for start in range(0,len(files),4):
 sheet=Image.new('RGB',(1640,2190),'#d8d8d8');draw=ImageDraw.Draw(sheet)
 for j,p in enumerate(files[start:start+4]):
  im=Image.open(p).convert('RGB');im.thumbnail((800,1050));x=20+(j%2)*820;y=30+(j//2)*1090;sheet.paste(im,(x,y));draw.text((x,y-18),p.stem,fill='black')
 sheet.save(Path('outputs')/f'disclosure-contact-{start//4+1}.png')
