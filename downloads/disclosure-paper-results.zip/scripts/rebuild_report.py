"""Rebuild presentation from frozen estimates; no treatment or fit selection."""
from pathlib import Path
import runpy
H=Path(__file__).resolve().parent
for name in ['assemble_tables.py','write_manuscript.py','build_pdf.py','validate_results.py','submission_readiness.py','build_public_report.py']:
 runpy.run_path(str(H/name),run_name='__main__')
