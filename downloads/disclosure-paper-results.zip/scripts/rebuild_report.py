"""Rebuild presentation from frozen estimates; no treatment or fit selection."""
from pathlib import Path
import runpy
H=Path(__file__).resolve().parent
for name in ['compile_latex_pdf.py','render_latex.py','inspect_latex.py','finalize_latex_release.py','submission_readiness.py','build_public_report.py']:
 runpy.run_path(str(H/name),run_name='__main__')
