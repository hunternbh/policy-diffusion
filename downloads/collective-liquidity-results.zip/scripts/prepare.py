from pathlib import Path
import json, hashlib, datetime, itertools, sys
sys.path.insert(0,'work/empirical-deps')
from pypdf import PdfReader
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion')
O=R/'data/collective_grid_2026-10-26'
for d in ['scripts','tables','audit','data']:(O/d).mkdir(parents=True,exist_ok=True)
source=R/'data/literature/01-esg-and-sustainability/2023-krueger-et-al-effects-of-esg-reporting-around-the-world.pdf'
reader=PdfReader(source)
pages=[{'pdf_page':i+1,'text':p.extract_text()} for i,p in enumerate(reader.pages)]
(O/'data/krueger-reference-pages.json').write_text(json.dumps(pages,ensure_ascii=False),encoding='utf8')
notes={
 'source':str(source),'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'physical_pages':len(pages),
 'review': 'Methods, variable appendix, baseline and alternative-estimator tables inspected; not a claim to have replicated the original dataset.',
 'baseline':{'equation':'Liquidity_i,c,t+1 = beta MandatoryDisclosure_c,t + X_i,c,t-1 theta + firm FE + industry-by-year FE',
 'outcomes':['log annual median bid-ask spread','log annual median Amihud price impact','fraction zero-return days','single-factor illiquidity score'],
 'timing':'12 months following fiscal year end; policy status in t, outcome t+1, controls t-1',
 'inference':'Firm clustering in baseline; alternative clustering in robustness',
 'screening':'Annual spread outside [0,1] missing; price impact requires >=120 observations and price variation; annual spread/impact winsorized at 1/99.',
 'esg_definition':'Complete mandatory E, S and G; staggered topic introduction requires all three. Comply-or-explain is mandatory in baseline.'},
 'table8':{'physical_page':58,'estimators':['Callaway-SantAnna without/with controls','stacked without/with controls'],
 'stack_definition':'Clean never/not-yet-treated controls, firm-by-stack and year-by-stack effects; uses pre/post observations.',
 'reported_coefficients':[-.050,-.105,-.137,-.129]},
 'other_tests':['event dynamics/parallel trends','government versus exchange mandate','full compliance versus comply-or-explain','formal/informal institutions','voluntary disclosure environment','alternative FE and clustering','alternative staggered estimators'],
 'adaptation':{'unit':'Country means of fixed companies; no claim to reproduce firm financial controls, fiscal-year timing or industry-by-year effects.',
 'outcomes':'Three original individual proxies plus baseline-2000 standardized equal-sign illiquidity index; index is not the reference latent factor.',
 'stack_FE':'Country-by-family-cohort and year-by-family-cohort. Controls must remain documented not-yet treated through entire window; unknown histories excluded.',
 'all_disclosures':'Ten public families, combined eleven including confidential tax, and all recorded seventeen as broader sensitivity.',
 'pooling':'Direct stacked slopes and explicit family averages target different exposure distributions. GLS is a conditional common-effect minimum-distance diagnostic, not a cure for confounding or a direct SUR replication.'}}
(O/'reference-methods.json').write_text(json.dumps(notes,indent=2),encoding='utf8')
plan={
 'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'client_date':'2026-10-26',
 'status':'Retrospective grid frozen before these new fits. Existing results and earlier grids already known; not preregistration.',
 'winsorization':['screened_untrimmed','year_p01_p99','year_p025_p975'],
 'policy_outcome_lag':[0,1],'pre_and_post_years':[2,3],
 'country_weights':['equal_country','baseline_gdp','baseline_cap'],
 'controls':['none','lagged_country_macro'],
 'scopes':['public_disclosure','public_and_confidential','broader_recorded'],
 'outcomes':['log_spread','log_impact','zero_fraction','illiquidity_index'],
 'pooling':['stack_equal_family','stack_cap_family','average_equal_family','average_cap_family','gls_common_effect','minimum_variance_positive'],
 'expected_cells':5184,
 'calendar':'reviewed_G documented phases. Pre years g-L,...,g-1; post years g+lag,...,g+lag+L-1. Omit g as transition for lag=1.',
 'company_selection':'Largest positive-cap security per vendor company at g-1, fixed line/country/company through all window years; complete all three outcomes; >=30 companies per country-stack.',
 'never_treated':'No unsupported never-treated coding. Documented later adoption G>end is required for controls; >=3 comparison countries per cohort.',
 'censor':'USA beneficial ownership and Germany supply-chain if window ends >=2025.',
 'controls_timing':'Prior-calendar-year log real GDP per capita, GDP growth and trade/GDP. Complete all window years; no filling missing controls.',
 'index':'Equal mean of three proxies standardized using complete, deduplicated 2000 companies, with direction higher=less liquid; no optimized outcome weights.',
 'stack_weight':'Constant within country-stack. Within-stack country weights normalized to unit total; cohorts weighted by adopting-country baseline mass. Normalize family total mass to requested equal/cap family mass. Direct stack slope additionally reflects residualized treatment information.',
 'inference':'Country-cluster sandwich, shared-country covariance retained across families/stacks, t with G-1 df; HC1 includes absorbed stack-country and stack-year df. Conditional on sample, phase calendar and GLS estimated weights.',
 'gls':'Inverse cross-family country-score covariance only if full rank and condition<1e8. Positive variant minimizes same variance subject to nonnegative weights sum=1. Estimated weights conditional; not population policy averages.',
 'diagnostics':['Every family/cohort support or failure retained','Event-study pre-lead Wald test on identical sample','Country and family weights','Joint outcome Wald tests','Leave-one-family-out ranges','Independent dense-FE numerical reconstruction'],
 'multiplicity':'Holm across all 5184 attempted focal cells, including failures assigned p=1; BH also descriptive. Within-public following-year spread priority set includes all winsor/window/within/controls/pooling choices, not chosen by sign.',
 'stopping':'Complete declared grid and diagnostics regardless of significance; report candidates with qualifications and full matrix. Do not continue until a favourable p-value is found.',
 'limitations':['Calendar rather than fiscal-year outcomes','National phase exposure rather than verified issuer eligibility','Simultaneous other reforms not ruled out','Balanced-company selection uses future survival','Country clustering does not prove independence across supranational legal waves','GLS common-effect restriction may fail across heterogeneous families']}
assert len(list(itertools.product(*(plan[k] for k in ['winsorization','policy_outcome_lag','pre_and_post_years','country_weights','controls','scopes','outcomes','pooling']))))==plan['expected_cells']
target=O/'analysis-plan.json'
if target.exists():
 existing=json.loads(target.read_text());assert {k:v for k,v in existing.items() if k!='recorded_at'}=={k:v for k,v in plan.items() if k!='recorded_at'},'Do not overwrite a frozen plan.'
else:target.write_text(json.dumps(plan,indent=2),encoding='utf8')
print(json.dumps({'output':str(O),'planned_cells':plan['expected_cells'],'source_pages':len(pages)}))
