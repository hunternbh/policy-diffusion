"""Concentration diagnostic specified after the focal grid; all its cells retained."""
from pathlib import Path
import sys,json,datetime,itertools,shutil
sys.path.insert(0,'work/empirical-deps')
import numpy as np,pandas as pd
from scipy.stats import t,chi2
from scipy.optimize import minimize
from statsmodels.stats.multitest import multipletests
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'data/collective_grid_2026-10-26'
plan={'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'prior_grid_results_seen':True,'reason':'The benchmark GLS assigns 59.6% to a climate family with one adopting country. Check adoption support systematically; no choice made from coefficient signs.',
 'fixed_design':{'lag':1,'window':3,'country_weight':'baseline_gdp'},'vary':['all three winsorization rules','both controls','all three scopes','minimum 2 and minimum 5 adopting countries per family','all four outcomes','equal family, cap family, GLS, nonnegative minimum variance'],
 'planned_cells':576,'multiplicity':'Holm across all 576 diagnostic cells; original 5184-cell results retained unchanged.','inference':'Conditional country-score covariance. The support restriction changes the family target, and passing a lead test is not proof of parallel trends.'}
target=O/'audit/support-sensitivity-plan.json'
if not target.exists():target.write_text(json.dumps(plan,indent=2),encoding='utf8')
if not (O/'data/family-fit-metadata.csv').exists():print('Plan recorded; waiting for family score export.');raise SystemExit(0)
M=pd.read_csv(O/'data/family-fit-metadata.csv');F=np.load(O/'data/family-fit-influences.npz');original=pd.read_csv(O/'tables/collective-grid.csv');prior=json.loads((R/'data/current/analysis-plan.json').read_text());scopes={'public_disclosure':prior['headline_families'],'public_and_confidential':prior['all_disclosure_families'],'broader_recorded':list(M.family.unique())};rows=[];ww=[]
for win,ctrl,scope,min_adopt,out,method in itertools.product(['screened_untrimmed','year_p01_p99','year_p025_p975'],['none','lagged_country_macro'],scopes,[2,5],range(4),['average_equal_family','average_cap_family','gls_common_effect','minimum_variance_positive']):
 a=M[M.winsor.eq(win)&M.lag.eq(1)&M.window.eq(3)&M.country_weight.eq('baseline_gdp')&M.controls.eq(ctrl)&M.family.isin(scopes[scope])&M.treated_countries.ge(min_adopt)];ids=a.index.to_numpy();n=len(ids);base={'winsor':win,'controls':ctrl,'scope':scope,'minimum_adopters':min_adopt,'outcome':['log_spread','log_impact','zero_fraction','illiquidity_index'][out],'pooling':method,'families':n,'family_names':';'.join(a.family),'status':'insufficient_supported_families','p_value':1.}
 if n<2:rows.append(base);continue
 B=F['beta'][ids,out];I=F['influences'][ids,:,out].T;V=I.T@I
 if method=='average_equal_family':w=np.ones(n)/n
 elif method=='average_cap_family':w=a.cap.to_numpy()/a.cap.sum()
 else:
  if np.linalg.matrix_rank(V)<n or np.linalg.cond(V)>1e8:rows.append({**base,'status':'unstable_covariance'});continue
  w=np.linalg.solve(V,np.ones(n));w/=w.sum()
  if method=='minimum_variance_positive':
   scale=np.trace(V)/n;opt=minimize(lambda x:float(x@V@x/scale),np.ones(n)/n,jac=lambda x:2*V@x/scale,bounds=[(0,1)]*n,constraints=[{'type':'eq','fun':lambda x:x.sum()-1,'jac':lambda x:np.ones(n)}],method='SLSQP',options={'ftol':1e-12,'maxiter':1000})
   if not opt.success:rows.append({**base,'status':'optimizer_failure'});continue
   w=opt.x
 b=float(w@B);inf=I@w;se=float(np.linalg.norm(inf));G=int(np.sum(abs(inf)>1e-14));pv=float(2*t.sf(abs(b/se),G-1));eb=w@F['event_beta'][ids,:,out];ei=np.einsum('fcl,f->cl',F['event_influences'][ids,:,:,out],w);EV=ei.T@ei;lead=float(chi2.sf(eb@np.linalg.pinv(EV)@eb,np.linalg.matrix_rank(EV)))
 sid=f'S{len(rows)+1:04}';rows.append({**base,'id':sid,'status':'estimated','estimate':b,'country_se':se,'p_value':pv,'pretrend_p':lead,'largest_weight':float(w.max()),'negative_weights':int((w<0).sum())})
 for fam,mass in zip(a.family,w):ww.append({'id':sid,'family':fam,'weight':float(mass)})
T=pd.DataFrame(rows);assert len(T)==576;T['holm_576_p']=multipletests(T.p_value.fillna(1),method='holm')[1];T.to_csv(O/'tables/adopter-support-sensitivity.csv',index=False);pd.DataFrame(ww).to_csv(O/'tables/adopter-support-weights.csv',index=False)
old=pd.read_csv(O/'audit/first-run-grid.csv');pd.testing.assert_frame_equal(old,original,check_exact=True)
summary={'cells':len(T),'estimated':int(T.status.eq('estimated').sum()),'holm_below_05':int(T.holm_576_p.lt(.05).sum()),'negative_holm_pretrend_above_05':int((T.estimate.lt(0)&T.holm_576_p.lt(.05)&T.pretrend_p.ge(.05)).sum()),'focal_grid_bitwise_numeric_reproducibility':True}
(O/'audit/support-sensitivity-summary.json').write_text(json.dumps(summary,indent=2));shutil.copy2(__file__,O/'scripts/support_sensitivity.py');print(json.dumps(summary));print(T[T.winsor.eq('year_p01_p99')&T.scope.eq('public_disclosure')&T.outcome.eq('log_spread')].to_string(index=False))
