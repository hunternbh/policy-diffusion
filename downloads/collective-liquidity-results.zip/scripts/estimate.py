"""Retrospective country stacked-DiD grid. No specification selected by its sign."""
import os
for key in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:os.environ[key]='1'
from pathlib import Path
import sys,json,time,itertools,hashlib,shutil
sys.path.insert(0,'work/empirical-deps')
import numpy as np,pandas as pd
from scipy.stats import t,chi2
from scipy.optimize import minimize
from statsmodels.stats.multitest import multipletests
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'data/collective_grid_2026-10-26';A=R/'data/research_archive'
P=json.loads((O/'analysis-plan.json').read_text());prior=json.loads((R/'data/current/analysis-plan.json').read_text())
start=time.time();rows=[];ledger=[];weights=[];joint=[];diagnostic=[];loo=[];tests=[];validation_saved=False;family_meta=[];family_beta=[];family_if=[];family_eb=[];family_eif=[]
cal=pd.read_csv(R/'data/current/reviewed-policy-calendar.csv');assert not cal.duplicated(['iso3','regulation_family']).any()
macro=pd.read_csv(R/'data/current/macro-country-year.csv').set_index(['iso3','year'])
d=pd.read_parquet(A/'09-expanded-policy-paper/2026-10-18/data/security-year-liquidity.parquet')
q=pd.read_parquet(A/'17-issuer-regulation-expansion/2026-10-19/data/all-annual-company-mapping.parquet',columns=['security_id','year','dscompcode']).dropna()
assert not q.duplicated(['security_id','year']).any();d=d.merge(q,on=['security_id','year'],validate='one_to_one')
assert not d.duplicated(['security_id','year']).any()
isos=sorted(d.iso3.unique());ci={v:i for i,v in enumerate(isos)};K=len(isos)
familyall=sorted(cal.regulation_family.unique());scopes={'public_disclosure':prior['headline_families'],'public_and_confidential':prior['all_disclosure_families'],'broader_recorded':familyall}
manifest={}
for f in [R/'data/current/reviewed-policy-calendar.csv',R/'data/current/macro-country-year.csv',A/'09-expanded-policy-paper/2026-10-18/data/security-year-liquidity.parquet',A/'17-issuer-regulation-expansion/2026-10-19/data/all-annual-company-mapping.parquet',O/'analysis-plan.json']:
 manifest[str(f)]={'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
(O/'audit/input-manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
def scalar(iso,y,f):
 try:return float(macro.loc[(iso,y),f])
 except KeyError:return np.nan
def transform(winsor):
 x=d.copy();s=x.median_spread.where(x.spread_days.ge(120)&x.median_spread.between(0,1));a=(x.amihud_per_usd*1e8).where(x.impact_days.ge(120)&x.distinct_prices.gt(1));z=x.zero_fraction_observed.where(x.return_days.ge(120)&x.distinct_prices.gt(1))
 # Keep originally nonpositive values missing before trimming; never create positive spreads from zeros.
 s=s.where(s.gt(0));a=a.where(a.gt(0));tail={'screened_untrimmed':0,'year_p01_p99':.01,'year_p025_p975':.025}[winsor]
 thresholds=[]
 if tail:
  for y,ids in x.groupby('year').groups.items():
   for name,v in [('spread',s),('impact',a)]:
    lo,hi=v.loc[ids].quantile([tail,1-tail]);v.loc[ids]=v.loc[ids].clip(lo,hi);thresholds.append({'winsor':winsor,'year':int(y),'outcome':name,'lower':lo,'upper':hi})
 x['log_spread']=np.log(s);x['log_impact']=np.log(a);x['zero_fraction']=z
 base=x[x.year.eq(2000)&x.market_cap_usd.gt(0)].sort_values(['dscompcode','market_cap_usd','security_id'],ascending=[True,False,True]).drop_duplicates('dscompcode').dropna(subset=P['outcomes'][:3])
 mu=base[P['outcomes'][:3]].mean();sd=base[P['outcomes'][:3]].std();assert (sd>0).all()
 x['illiquidity_index']=((x[P['outcomes'][:3]]-mu)/sd).mean(axis=1,skipna=False)
 (O/f'audit/index-calibration-{winsor}.json').write_text(json.dumps({'year':2000,'companies':len(base),'mean':mu.to_dict(),'sd':sd.to_dict(),'weights':[1/3]*3,'not_latent_factor':True},indent=2))
 pd.DataFrame(thresholds).to_csv(O/f'audit/winsor-thresholds-{winsor}.csv',index=False)
 return {int(y):v.set_index('security_id') for y,v in x.groupby('year')}
def panel(annual,g,lag,L):
 years=list(range(g-L,g))+list(range(g+lag,g+lag+L));end=max(years)
 if min(years)<2000 or end>2025 or g-1 not in annual:return None
 pre=annual[g-1];chosen=pre[pre.market_cap_usd.gt(0)].reset_index().sort_values(['dscompcode','market_cap_usd','security_id'],ascending=[True,False,True]).drop_duplicates('dscompcode').set_index('security_id')
 valid=np.ones(len(chosen),bool);vals=[]
 for y in years:
  a=annual[y].reindex(chosen.index);valid&=a.dscompcode.eq(chosen.dscompcode).to_numpy()&a.iso3.eq(chosen.iso3).to_numpy()&np.isfinite(a[P['outcomes']]).all(axis=1).to_numpy();vals.append(a[P['outcomes']].to_numpy(float))
 x=chosen.iloc[np.flatnonzero(valid)];v=np.stack(vals,axis=1)[valid];entries=[]
 for iso,ids in x.groupby('iso3').indices.items():
  if len(ids)<30:continue
  entries.append({'iso3':iso,'country_index':ci[iso],'companies':len(ids),'cap':float(x.iloc[ids].market_cap_usd.sum()),'gdp':scalar(iso,g-1,'gdp_constant_usd'),'Y':v[ids].mean(axis=0),
   'Z':np.array([[np.log(pc) if (pc:=scalar(iso,y-1,'gdp_pc_constant'))>0 else np.nan,scalar(iso,y-1,'gdp_growth_pct'),scalar(iso,y-1,'trade_gdp_pct')] for y in years])})
 return entries,years
def within(X,w):
 # Balanced country x time rectangle; weights constant within country.
 return X-X.mean(axis=1,keepdims=True)-np.average(X,axis=0,weights=w)[None,:,:]+np.average(X.mean(axis=1),axis=0,weights=w)[None,None,:]
def family_data(fam,lag,L,within_weight,controlled,panels):
 ev=cal[cal.regulation_family.eq(fam)];dates=ev.set_index('iso3').reviewed_G.to_dict();stacks=[]
 for g in sorted(ev.reviewed_G.dropna().astype(int).unique()):
  context={'family':fam,'cohort':int(g),'lag':lag,'window':L,'country_weight':within_weight,'controls':controlled}
  pp=panels.get((g,lag,L))
  if pp is None:ledger.append({**context,'status':'outside_annual_data_window'});continue
  entries,years=pp;end=max(years);a=[dict(v,T=float(dates.get(v['iso3'])==g)) for v in entries if dates.get(v['iso3'])==g or dates.get(v['iso3'],float('-inf'))>end]
  if end>=2025:
   a=[v for v in a if not ((fam=='BENEFICIAL_OWNERSHIP' and v['iso3']=='USA') or (fam=='SUPPLY_CHAIN' and v['iso3']=='DEU'))]
  for v in a:v['w']=1. if within_weight=='equal_country' else v['gdp'] if within_weight=='baseline_gdp' else v['cap']
  a=[v for v in a if np.isfinite(v['w']) and v['w']>0 and (not controlled or np.isfinite(v['Z']).all())];nt=sum(v['T'] for v in a);nc=len(a)-nt
  if nt<1 or nc<3:ledger.append({**context,'status':'insufficient_clean_comparison_countries','treated':nt,'comparison':nc});continue
  w=np.array([v['w'] for v in a]);tr=np.array([v['T'] for v in a]);Y=np.stack([v['Y'] for v in a]);Z=np.stack([v['Z'] for v in a]);D=tr[:,None]*np.r_[np.zeros(L),np.ones(L)][None,:]
  X=D[:,:,None] if not controlled else np.concatenate([D[:,:,None],Z],axis=2)
  event=np.stack([tr[:,None]*(np.arange(2*L)==j)[None,:] for j in list(range(L-1))+list(range(L,2*L))],axis=2)
  XE=event if not controlled else np.concatenate([event,Z],axis=2)
  stacks.append({'X':within(X,w).reshape(-1,X.shape[2]),'E':within(XE,w).reshape(-1,XE.shape[2]),'Y':within(Y,w).reshape(-1,4),'w':np.repeat(w/w.sum()/(2*L),2*L),'c':np.repeat([v['country_index'] for v in a],2*L),
   'mass':float(w[tr.astype(bool)].sum()),'cap':sum(v['cap'] for v in a if v['T']), 'fe_df':len(a)+2*L-1,'treated':{v['iso3'] for v in a if v['T']},'comparison':{v['iso3'] for v in a if not v['T']},'g':int(g),
   'raw_X':X,'raw_E':XE,'raw_Y':Y,'raw_w':w,'years':years})
  ledger.append({**context,'status':'included','treated':nt,'comparison':nc,'companies':sum(v['companies'] for v in a),'end_year':end})
 if not stacks:return None
 mass=sum(s['mass'] for s in stacks)
 for s in stacks:s['w']*=s['mass']/mass
 return {'family':fam,'stacks':stacks,'cap':sum(s['cap'] for s in stacks),'treated':set.union(*(s['treated'] for s in stacks)),'comparison':set.union(*(s['comparison'] for s in stacks))}
def fit(families,masses,event=False):
 global validation_saved
 ss=[(s,float(w)) for f,w in zip(families,masses) for s in f['stacks']];key='E' if event else 'X';X=np.concatenate([s[key] for s,w in ss]);Y=np.concatenate([s['Y'] for s,w in ss]);W=np.concatenate([s['w']*w for s,w in ss]);C=np.concatenate([s['c'] for s,w in ss]);n,k=X.shape
 S=X.T@(W[:,None]*X)
 if np.linalg.matrix_rank(S)<k:return None
 inv=np.linalg.inv(S);b=inv@(X.T@(W[:,None]*Y));res=Y-X@b;active=np.unique(C);G=len(active);fe=sum(s['fe_df'] for s,w in ss);df=n-fe-k
 if G<3 or df<1:return None
 scores=np.zeros((K,k,4))
 for j in range(k):
  for z in range(4):scores[:,j,z]=np.bincount(C,weights=W*X[:,j]*res[:,z],minlength=K)
 IF=np.einsum('ij,cjo->cio',inv,scores)*np.sqrt(G/(G-1)*(n-1)/df)
 if not validation_saved and not event:
  s=ss[0][0]
  np.savez_compressed(O/'audit/dense-validation-input.npz',X=s['raw_X'],Y=s['raw_Y'],E=s['raw_E'],w=s['raw_w'],residual_X=s['X'],residual_Y=s['Y'],residual_E=s['E'])
  validation_saved=True
 return {'beta':b,'IF':IF,'countries':G,'rows':n,'df':df,'rank':k,'families':len(families),'S':S}
def summary(beta,IF):
 G=int(np.sum(np.any(abs(IF)>1e-14,axis=1))) if IF.ndim==2 else int(np.sum(abs(IF)>1e-14));se=float(np.linalg.norm(IF));crit=t.ppf(.975,max(1,G-1));p=float(2*t.sf(abs(beta/se),max(1,G-1))) if se>1e-14 else 1.
 return {'estimate':float(beta),'country_se':se,'ci_low':float(beta-crit*se),'ci_high':float(beta+crit*se),'p_value':p}
def lead_test(beta,IF):
 V=IF.T@IF;r=np.linalg.matrix_rank(V)
 if r!=len(beta):return {'pretrend_p':np.nan,'pretrend_status':'rank_deficient_lead_covariance'}
 stat=float(beta@np.linalg.solve(V,beta));return {'pretrend_p':float(chi2.sf(stat,r)),'pretrend_status':'estimated_asymptotic_country_cluster_Wald','pretrend_stat':stat}
counter=0
for winsor in P['winsorization']:
 annual=transform(winsor);panels={}
 for lag,L in itertools.product(P['policy_outcome_lag'],P['pre_and_post_years']):
  for g in sorted(cal.reviewed_G.dropna().astype(int).unique()):panels[g,lag,L]=panel(annual,g,lag,L)
 print(json.dumps({'stage':'balanced_panels','winsor':winsor,'seconds':round(time.time()-start)}),flush=True)
 for lag,L,cw,ctrl in itertools.product(P['policy_outcome_lag'],P['pre_and_post_years'],P['country_weights'],P['controls']):
  context={'winsor':winsor,'lag':lag,'window':L,'country_weight':cw,'controls':ctrl};family=[];fits={};events={}
  ledger_start=len(ledger)
  for fam in familyall:
   f=family_data(fam,lag,L,cw,ctrl!='none',panels)
   if f is None:continue
   ffit=fit([f],[1.]);efit=fit([f],[1.],True)
   if ffit is None or efit is None:continue
   family.append(f);fits[fam]=ffit;events[fam]=efit
   family_meta.append({**context,'family':fam,'cap':f['cap'],'treated_countries':len(f['treated']),'comparison_countries':len(f['comparison']),'rows':ffit['rows'],'countries':ffit['countries'],'leads':L-1})
   family_beta.append(ffit['beta'][0]);family_if.append(ffit['IF'][:,0,:]);family_eb.append(np.pad(efit['beta'][:L-1],((0,3-L),(0,0)),constant_values=np.nan));family_eif.append(np.pad(efit['IF'][:,:L-1,:],((0,0),(0,3-L),(0,0)),constant_values=np.nan))
  for l in ledger[ledger_start:]:l['winsor']=winsor
  for scope in P['scopes']:
   fs=[f for f in family if f['family'] in scopes[scope]];names=[f['family'] for f in fs];nF=len(fs)
   for method in P['pooling']:
    mass=np.ones(nF) if method in ['stack_equal_family','average_equal_family'] else np.array([f['cap'] for f in fs]);mass=mass/mass.sum() if nF else mass
    direct=fit(fs,mass) if nF and method.startswith('stack_') else None
    direct_event=fit(fs,mass,True) if direct is not None else None
    for o,out in enumerate(P['outcomes']):
     counter+=1;sid=f'C{counter:05}';base={**context,'scope':scope,'pooling':method,'outcome':out,'specification_id':sid,'families':nF,'family_names':';'.join(names),'status':'no_supported_families','p_value':1.}
     if not nF:rows.append(base);continue
     B=np.array([fits[n]['beta'][0,o] for n in names]);I=np.stack([fits[n]['IF'][:,0,o] for n in names],axis=1);EB=np.stack([events[n]['beta'][:L-1,o] for n in names]);EI=np.stack([events[n]['IF'][:,:L-1,o] for n in names],axis=1)
     if method in ['gls_common_effect','minimum_variance_positive']:
      V=I.T@I;condition=np.linalg.cond(V)
      if nF<2 or np.linalg.matrix_rank(V)!=nF or condition>1e8:rows.append({**base,'status':'unstable_cross_family_covariance','covariance_condition':condition});continue
      one=np.ones(nF);un=np.linalg.solve(V,one);un/=one@un
      if method=='gls_common_effect':mass=un
      else:
       scale=np.trace(V)/nF
       opt=minimize(lambda x:float(x@V@x/scale),np.ones(nF)/nF,jac=lambda x:2*V@x/scale,bounds=[(0,1)]*nF,constraints=[{'type':'eq','fun':lambda x:x.sum()-1,'jac':lambda x:np.ones(nF)}],method='SLSQP',options={'ftol':1e-12,'maxiter':1000})
       if not opt.success:rows.append({**base,'status':'positive_covariance_optimizer_failed'});continue
       mass=opt.x
     if method.startswith('stack_'):
      if direct is None or direct_event is None:rows.append({**base,'status':'rank_deficient_direct_stack'});continue
      beta=direct['beta'][0,o];influence=direct['IF'][:,0,o];eb=direct_event['beta'][:L-1,o];ei=direct_event['IF'][:,:L-1,o];N=direct['rows'];G=direct['countries']
     else:
      beta=float(mass@B);influence=I@mass;eb=mass@EB;ei=np.einsum('cfl,f->cl',EI,mass);N=sum(fits[n]['rows'] for n in names);G=len(set.union(*(f['treated']|f['comparison'] for f in fs)))
     result={**base,'status':'estimated_country_exposure',**summary(beta,influence),**lead_test(eb,ei),'country_stack_year_rows':N,'countries':G,'negative_family_weights':int((mass<0).sum()),'largest_family_weight':float(mass.max()),'effective_families':float(1/(mass@mass)), 'families_with_one_treated_country':sum(len(f['treated'])==1 for f in fs)}
     rows.append(result)
     for fam,w,b in zip(names,mass,B):weights.append({'specification_id':sid,'family':fam,'weight':float(w),'family_estimate':float(b),'weight_meaning':'input_family_objective_mass' if method.startswith('stack_') else 'coefficient_average_weight'})
     if not method.startswith('stack_'):
      leave=[float(np.delete(mass,j)@np.delete(B,j)/(1-mass[j])) for j in range(nF) if abs(1-mass[j])>1e-8];loo.append({'specification_id':sid,'min_leave_one_out':min(leave) if leave else np.nan,'max_leave_one_out':max(leave) if leave else np.nan})
     # Retain country influences for reproducible shared-country covariance and joint outcome tests.
     tests.append({'specification_id':sid,'influence':influence,'estimate':beta,'outcome':out,'group':tuple(context.values())+(scope,method)})
  print(json.dumps({'stage':'grid','winsor':winsor,'lag':lag,'window':L,'weight':cw,'controls':ctrl,'cells':counter,'seconds':round(time.time()-start)}),flush=True)
 T=pd.DataFrame(rows);T.to_csv(O/'tables/grid-progress.csv',index=False)
T=pd.DataFrame(rows);assert len(T)==P['expected_cells'];T['holm_all_attempted_p']=multipletests(T.p_value.fillna(1),method='holm')[1];T['bh_all_attempted_q']=multipletests(T.p_value.fillna(1),method='fdr_bh')[1]
priority=T.scope.eq('public_disclosure')&T.lag.eq(1)&T.outcome.eq('log_spread');T['holm_priority_spread_p']=np.nan;T.loc[priority,'holm_priority_spread_p']=multipletests(T.loc[priority,'p_value'].fillna(1),method='holm')[1]
T.to_csv(O/'tables/collective-grid.csv',index=False);pd.DataFrame(ledger).to_csv(O/'tables/cohort-support-ledger.csv',index=False);pd.DataFrame(weights).to_csv(O/'tables/family-pooling-weights.csv',index=False);pd.DataFrame(loo).to_csv(O/'tables/leave-one-family-out.csv',index=False)
np.savez_compressed(O/'data/country-influences.npz',ids=np.array([x['specification_id'] for x in tests]),influences=np.stack([x['influence'] for x in tests]),isos=np.array(isos))
pd.DataFrame(family_meta).to_csv(O/'data/family-fit-metadata.csv',index=False)
np.savez_compressed(O/'data/family-fit-influences.npz',beta=np.stack(family_beta),influences=np.stack(family_if),event_beta=np.stack(family_eb),event_influences=np.stack(family_eif),isos=np.array(isos))
groups={}
for z in tests:groups.setdefault(z['group'],[]).append(z)
for key,v in groups.items():
 if len(v)!=4:continue
 B=np.array([z['estimate'] for z in v]);I=np.stack([z['influence'] for z in v],axis=1);V=I.T@I;r=np.linalg.matrix_rank(V)
 joint.append({'specification_ids':';'.join(z['specification_id'] for z in v),'rank':r,'wald':float(B@np.linalg.pinv(V)@B),'p_value':float(chi2.sf(B@np.linalg.pinv(V)@B,r)),'all_individual_proxies_negative':all(z['estimate']<0 for z in v if z['outcome']!='illiquidity_index')})
pd.DataFrame(joint).to_csv(O/'tables/joint-outcome-tests.csv',index=False)
summary_result={'planned':P['expected_cells'],'recorded':len(T),'estimated':int(T.status.eq('estimated_country_exposure').sum()),'status_counts':T.status.value_counts().to_dict(),'negative_estimates':int(T.estimate.lt(0).sum()),'holm_all_below_05':int(T.holm_all_attempted_p.lt(.05).sum()),'priority_cells':int(priority.sum()),'priority_holm_below_05':int(T.loc[priority,'holm_priority_spread_p'].lt(.05).sum()),'elapsed_seconds':time.time()-start,'not_a_significance_stopping_rule':True}
(O/'audit/run-summary.json').write_text(json.dumps(summary_result,indent=2),encoding='utf8');shutil.copy2(__file__,O/'scripts/estimate.py');shutil.copy2(Path(__file__).with_name('prepare.py'),O/'scripts/prepare.py')
print(json.dumps(summary_result),flush=True)
