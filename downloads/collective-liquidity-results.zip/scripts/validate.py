from pathlib import Path
import sys,json,itertools,hashlib
sys.path.insert(0,'work/empirical-deps')
import numpy as np,pandas as pd
from scipy.stats import t
from statsmodels.stats.multitest import multipletests
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'data/collective_grid_2026-10-26'
P=json.loads((O/'analysis-plan.json').read_text());T=pd.read_csv(O/'tables/collective-grid.csv');W=pd.read_csv(O/'tables/family-pooling-weights.csv');checks=[]
def check(name,value,detail=None):
 checks.append({'test':name,'passed':bool(value),'detail':detail})
 if not value:raise AssertionError((name,detail))
check('all_declared_cells_recorded',len(T)==P['expected_cells'])
cols=['winsor','lag','window','country_weight','controls','scope','outcome','pooling'];check('unique_specification_dimensions',not T.duplicated(cols).any())
expected=set(itertools.product(*(P[k] for k in ['winsorization','policy_outcome_lag','pre_and_post_years','country_weights','controls','scopes','outcomes','pooling'])))
check('full_cartesian_grid',set(T[cols].itertuples(index=False,name=None))==expected)
check('Holm_all_attempts',np.allclose(multipletests(T.p_value.fillna(1),method='holm')[1],T.holm_all_attempted_p))
manifest=json.loads((O/'audit/input-manifest.json').read_text())
for f,meta in manifest.items():check('input_unchanged:'+Path(f).name,hashlib.sha256(Path(f).read_bytes()).hexdigest()==meta['sha256'])
z=np.load(O/'audit/dense-validation-input.npz');X=z['X'];Y=z['Y'];E=z['E'];w=z['w'];C,H,k=X.shape;n=C*H;ww=np.repeat(w,H);D=np.column_stack([np.repeat(np.eye(C),H,axis=0),np.tile(np.eye(H)[:,1:],(C,1))]);sw=np.sqrt(ww)
for label,raw,resid in [('static',X,z['residual_X']),('event',E,z['residual_E'])]:
 XX=raw.reshape(n,-1);YY=Y.reshape(n,4);full=np.column_stack([XX,D]);b=np.linalg.lstsq(full*sw[:,None],YY*sw[:,None],rcond=None)[0][:XX.shape[1]]
 demean_b=np.linalg.lstsq(resid*sw[:,None],z['residual_Y']*sw[:,None],rcond=None)[0]
 check('independent_dense_dummy_beta_'+label,np.allclose(b,demean_b,atol=1e-9),float(abs(b-demean_b).max()))
 for name,rawv,resv in [('X',XX,resid),('Y',YY,z['residual_Y'])]:
  residual=rawv-D@np.linalg.lstsq(D*sw[:,None],rawv*sw[:,None],rcond=None)[0]
  check('independent_dense_projection_'+label+'_'+name,np.allclose(residual,resv,atol=1e-9),float(abs(residual-resv).max()))
I=np.load(O/'data/country-influences.npz');lookup={v:i for i,v in enumerate(I['ids'])};est=T[T.status.eq('estimated_country_exposure')]
check('country_influence_ids',set(est.specification_id)==set(I['ids']))
for r in est.itertuples():
 a=I['influences'][lookup[r.specification_id]];se=np.linalg.norm(a);G=np.sum(abs(a)>1e-14);p=2*t.sf(abs(r.estimate/se),max(1,G-1)) if se>1e-14 else 1
 check('recomputed_inference_'+r.specification_id,np.isclose(se,r.country_se,atol=1e-12) and np.isclose(p,r.p_value,atol=1e-10))
 ww=W[W.specification_id.eq(r.specification_id)];check('unit_family_mass_'+r.specification_id,abs(ww.weight.sum()-1)<1e-8)
 if not r.pooling.startswith('stack_'):check('family_average_reconstruction_'+r.specification_id,np.isclose(ww.weight@ww.family_estimate,r.estimate,atol=1e-10))
 if r.pooling in ['average_equal_family','average_cap_family','minimum_variance_positive','stack_equal_family','stack_cap_family']:check('nonnegative_family_mass_'+r.specification_id,ww.weight.min()>-1e-8)
support=pd.read_csv(O/'tables/cohort-support-ledger.csv');inc=support[support.status.eq('included')];check('minimum_control_support',(inc.comparison>=3).all());check('all_17_families_attempted',support.family.nunique()==17)
result={'passed':True,'checks':len(checks),'grid_cells':len(T),'estimated_cells':len(est),'independent_numeric_method':'Full weighted dummy-variable OLS and projections versus balanced within transformation for static and event models; all-cell inference and coefficient aggregation reconstructed.','scope_limit':'Numerical validation does not establish parallel trends, issuer eligibility or causal effects.','checks_detail':checks}
(O/'audit/validation-results.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps({k:v for k,v in result.items() if k!='checks_detail'}))
