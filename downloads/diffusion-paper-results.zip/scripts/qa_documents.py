from pathlib import Path
import sys,json,subprocess,re,hashlib
sys.path.insert(0,'work/empirical-deps')
from pypdf import PdfReader
import pdfplumber
from PIL import Image,ImageDraw
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'data/diffusion_submission_2026-10-26';D=Path('outputs/diffusion-submission');D.mkdir(parents=True,exist_ok=True);results={}
for name,prefix,count in [('paper','',6),('appendix','A',11),('appendix_excess','E',4)]:
 p=R/'compilations/current'/(name+'.pdf');reader=PdfReader(p);texts=[s.extract_text() for s in reader.pages];joined='\n'.join(texts);bad=[]
 with pdfplumber.open(p) as pdf:
  for i,page in enumerate(pdf.pages):
   outside=[c for c in page.chars if c['x0']<64 or c['x1']>550 or c['top']<43 or c['bottom']>766]
   if outside:bad.append({'page':i+1,'text':''.join(c['text'] for c in outside)[:160]})
 assert not bad,(name,bad)
 for n in range(1,count+1):assert sum(bool(re.search(r'Table\s+'+prefix+str(n)+r':',v)) for v in texts)==1,(name,n)
 assert not reader.metadata.author;assert not re.search(r'\b(exploratory|inconclusive|preliminary)\b',joined,re.I);assert 'Dube' not in joined
 if name=='paper':
  assert all(v in joined for v in ['-0.223','-0.206','-0.199','-0.238','46','30','2.140','2.351'])
  compact=re.sub(r'\s+','',joined);assert compact.index('LIQUIDITYFINDINGS')<compact.index('INTERNATIONALPOLICYDIFFUSION')
 subprocess.run([r'C:\poppler-24.02.0\Library\bin\pdftoppm.exe','-scale-to','1050','-png',str(p),str(D/name)],capture_output=True,check=True)
 digits=len(str(len(texts)));pictures=[D/(name+'-'+str(i).zfill(digits)+'.png') for i in range(1,len(texts)+1)];assert all(f.exists() for f in pictures)
 contacts=[]
 for start in range(0,len(pictures),4):
  canvas=Image.new('RGB',(1660,2200),'#dedede');draw=ImageDraw.Draw(canvas)
  for j,f in enumerate(pictures[start:start+4]):
   im=Image.open(f).convert('RGB');im.thumbnail((800,1050));x=20+j%2*830;y=30+j//2*1100;canvas.paste(im,(x,y));draw.text((x,y-20),f.stem,fill='black')
  output=D/f'{name}-contact-{start//4+1}.jpg';canvas.save(output,quality=86);contacts.append(str(output.resolve()))
 results[name]={'pages':len(texts),'tables':count,'author_blank':True,'out_of_bounds':bad,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'contacts':contacts}
manifest=json.loads((O/'audit/exhibit-manifest.json').read_text());assert sum(z['regression'] for z in manifest)>=10;assert all(z['note'].startswith('This table reports') for z in manifest);assert {x.name for x in R.iterdir()}=={'compilations','data','figures_tables','submissions','paper.tex','appendix.tex','appendix_excess.tex','reference.bib'}
(O/'audit/document-validation.json').write_text(json.dumps(results,indent=2));print(json.dumps(results))
