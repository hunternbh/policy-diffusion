"""Source-supported country-family adoption signals; no unknown history is a nonadopter."""
from pathlib import Path
import sys,json,hashlib,datetime,shutil
sys.path.insert(0,'work/empirical-deps')
import pandas as pd,numpy as np
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');A=R/'data/research_archive';O=R/'data/diffusion_submission_2026-10-26';B=A/'26-adoption-weighting-and-design-audit/2026-10-19';OLD=A/'07-environmental-disclosure-mechanisms'
plan={'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'existing_results_known':True,
 'liquidity_lock':['C03169','C03173','C03177','C03181','C03185'],
 'primary_diffusion_sample':'Country-family first documented adoption risk, 2002-2025, ten public disclosure families. Documented later adopters supply pre-adoption years; unknown histories stay missing. Independent national choices primary; all documented coordinated implementations secondary.',
 'secondary_scope':'Public plus confidential country reports, eleven families.',
 'time':'All adoption/exposure signals use t-1 or earlier. PIP annual assets at t-1, alternative t-2 and fixed-2001 weights. Observed spread improvement uses same pre-selected companies from t-2 to t-1. Peer must adopt by t-2 for an observed post-adoption success signal.',
 'portfolio':'Reconstructed annual IMF Assets, Total economy and counterpart Total economy, total investment, USD; positive observed bilateral positions, excluding self positions; no zero filling unreported country pairs. Share of observed positive portfolio mass with documented policy history reported. Primary coverage >=50%; >=80% sensitivity.',
 'success':'Positive improvement is a fall in mean log spread for fixed same-company pairs with >=30 companies; magnitude is negative Delta log spread. Prior adopters with observed post-adoption outcomes must cover >=80% of eligible-adopter portfolio mass. No eligible prior adopters yields zero signal, not a fabricated successful outcome.',
 'copying':'Nearest larger economy among the ten geographic peers, using 2000 GDP to fix economic size; documented prior adoption, split into adoption last year and adoption at least two years ago. If no larger peer has valid baseline size/history, missing rather than a smaller-country substitute.',
 'other_mechanisms':'Koning export-similarity adoption share, GDP-growth learning, language and legal-origin shares, aid+IMF/GDP; retain exact underlying definitions. Crosslisting share is familiarity/substitution, not proof of copying. Aggregate GHG reductions are a separate observed-outcome signal, not emissions attributable to a disclosure rule.',
 'models':['portfolio_exposure','liquidity_success_exposure','liquidity_learning_double','liquidity_learning_triple','liquidity_learning_magnitude','liquidity_learning_threshold','ghg_learning_double','ghg_learning_triple','nearest_larger_copying','copying_recent_vs_old','trade_competition','language_copying','external_finance','crosslisting_substitution','joint_available_channels','gdp_learning_reference'],
 'model_matrix':'Each model: both family weights; ten-public and combined-eleven scopes; independent choices and all documented choices; logit family+year FE and LPM Country FE x family plus family-year FE. Portfolio models additionally rerun fixed-2001, t-2 and >=80% coverage in an explicit sensitivity matrix.',
 'controls':'Lagged log GDP per capita, GDP growth and trade/GDP; learning triple adds prior domestic liquidity (minus mean log spread) and every lower-order product. Crosslisting/IVS/LSEG controls added only where raw-source construction is verified, not invented.',
 'weights':'Equal family likelihood mass, and pre-adoption market-cap family mass from country-year g-1 company-cap totals for documented adopting cases. All supported public families eligible; do not restrict diffusion to the five liquidity families.',
 'support':'At least 15 countries, 10 events and 10 nonevents, >=50 rows; full rank and positive residual outcome/cluster variance; retain all failures. Logit fixed-effect groups without outcome variation iteratively removed to handle separation, with original support logged.',
 'inference':'Country-cluster sandwich; LPM absorbed FE rank from graph components; t critical values G-1. Report odds/log-odds separately from probability-point associations; no causal mechanism label from coefficient alone.',
 'multiplicity':'Holm across every prespecified focal coefficient attempt within the diffusion model matrix; unestimated tests p=1. All lower-order coefficients, standardizations and sample memberships saved.',
 'writing':'Keep the five main liquidity models and the user-introduction/institutional reasoning. No claims from pasted numerical results without independent reconstruction. Design and conclusion explain actual assumptions; results state estimates and substantive meanings directly.'}
f=O/'analysis-plan.json'
if not f.exists():f.write_text(json.dumps(plan,indent=2),encoding='utf8')
calendar=pd.read_csv(R/'data/current/reviewed-policy-calendar.csv');dates={fam:z.set_index('iso3').reviewed_G.to_dict() for fam,z in calendar.groupby('regulation_family')}
F=pd.read_parquet(B/'data/lagged-mechanism-panel.parquet');F=F[F.family.isin(dates)].copy();assert not F.duplicated(['iso3','family','year']).any()
outside_risk=F.G.ge(9000)
excluded_risk=F.loc[outside_risk,['iso3','family','G']].drop_duplicates()
excluded_risk['reason']='Outside the direct Article89 home regime is not an at-risk national adoption history.'
excluded_risk.to_csv(O/'audit/excluded-geographic-control-risk-sets.csv',index=False)
F=F[~outside_risk&F.year.between(2002,2025)&F.in_first_event_risk].copy();F['row_id']=np.arange(len(F))
macro=pd.read_csv(B/'data/macro-country-year.csv');m=macro.set_index(['iso3','year']).to_dict('index');N=pd.read_csv(B/'data/network-memberships.csv');geo={i:g.sort_values('rank').partner.tolist() for i,g in N[N.network.eq('geographic10')].groupby('origin')}
pip=pd.read_parquet(A/'08-empirical-tests/2026-10-18/reconstructed-annual-portfolio-positions.parquet');assert not pip.duplicated(['origin','partner','year']).any();pip=pip[pip.origin.ne(pip.partner)&pip.value_usd.gt(0)].copy();port={(i,int(y)):z[['partner','value_usd']] for (i,y),z in pip.groupby(['origin','year'])}
d=pd.read_parquet(A/'09-expanded-policy-paper/2026-10-18/data/security-year-liquidity.parquet');q=pd.read_parquet(A/'17-issuer-regulation-expansion/2026-10-19/data/all-annual-company-mapping.parquet',columns=['security_id','year','dscompcode']).dropna();assert not q.duplicated(['security_id','year']).any();d=d.merge(q,on=['security_id','year'],validate='one_to_one');annual={int(y):z.set_index('security_id') for y,z in d.groupby('year')}
pair_rows=[]
for year in range(2001,2026):
 pre=annual[year-1];x=pre[pre.market_cap_usd.gt(0)&pre.log_spread.notna()].reset_index().sort_values(['dscompcode','market_cap_usd','security_id'],ascending=[True,False,True]).drop_duplicates('dscompcode').set_index('security_id');post=annual[year].reindex(x.index);ok=post.dscompcode.eq(x.dscompcode)&post.iso3.eq(x.iso3)&post.log_spread.notna();x=x[ok];post=post[ok]
 for iso,idx in x.groupby('iso3').indices.items():
  if len(idx)<30:continue
  delta=float((post.iloc[idx].log_spread-x.iloc[idx].log_spread).mean());pair_rows.append({'iso3':iso,'year':year,'paired_companies':len(idx),'spread_improvement':-delta,'domestic_liquidity':-float(post.iloc[idx].log_spread.mean()),'lag_start_year':year-1,'outcome_end_year':year})
pairs=pd.DataFrame(pair_rows);pairs.to_parquet(O/'data/same-company-liquidity-signals.parquet',index=False);success=pairs.set_index(['iso3','year']).to_dict('index')
legacy=pd.read_excel(OLD/'mechanism_tables_replication/data/merged-final2.xlsx');legacy=legacy.rename(columns={'country-code':'iso3'});assert not legacy.duplicated(['iso3','year']).any();legacy=legacy.sort_values(['iso3','year']);legacy['ghg_change']=legacy.groupby('iso3')['ghg-emission'].pct_change(fill_method=None);legacy['ghg_reduction']=-legacy.ghg_change;legacy.loc[legacy.groupby('iso3').year.diff().ne(1),'ghg_reduction']=np.nan
legacy_fields=['crosslisted_firms_share','ghg-emission','ghg_reduction','return_volatility_mean_firm','market_cap_usd','liquidity_value_traded_usd','percentage_reported'];L=legacy.set_index(['iso3','year'])[legacy_fields].to_dict('index')
def larger(i):
 size=m.get((i,2000),{}).get('gdp_current_usd',np.nan)
 if not np.isfinite(size):return None
 return next((p for p in geo.get(i,[]) if m.get((p,2000),{}).get('gdp_current_usd',np.nan)>size),None)
big={i:larger(i) for i in F.iso3.unique()}
def exposure(i,t,fam,clock):
 when=t-1;position_year=t-1 if clock=='lag1' else t-2 if clock=='lag2' else 2001
 if clock=='fixed2001' and t<2003:return {}
 p=port.get((i,position_year))
 if p is None:return {}
 known=p[p.partner.isin(dates[fam])].copy();den=float(p.value_usd.sum());mass=float(known.value_usd.sum())
 if not mass:return {'known_policy_portfolio_share':0.}
 known['G']=known.partner.map(dates[fam]);known['weight']=known.value_usd/mass;ad=known[known.G.le(when)];eligible=known[known.G.le(t-2)]
 z={'pip_exposure':float(ad.weight.sum()),'known_policy_portfolio_share':mass/den,'position_year':position_year,'known_partners':len(known),'prior_adopters':len(ad)}
 eligible=eligible.copy();eligible['spread_improvement']=[success.get((p,when),{}).get('spread_improvement',np.nan) for p in eligible.partner];eligible['ghg_reduction']=[L.get((p,when),{}).get('ghg_reduction',np.nan) for p in eligible.partner]
 for var,prefix in [('spread_improvement','liquidity'),('ghg_reduction','ghg')]:
  obs=eligible[eligible[var].notna()];needed=float(eligible.weight.sum());coverage=float(obs.weight.sum()/needed) if needed>0 else 1.;z[prefix+'_success_coverage']=coverage
  if needed==0:z.update({prefix+'_success_share':0.,prefix+'_success_exposure':0.,prefix+'_magnitude_exposure':0.,prefix+'_threshold_exposure':0.});continue
  if coverage<.8:continue
  ww=obs.weight.to_numpy();vals=obs[var].to_numpy();z[prefix+'_success_share']=float(np.mean(vals>0));z[prefix+'_success_exposure']=float(ww@(vals>0));z[prefix+'_magnitude_exposure']=float(ww@vals)
  # Salient success threshold uses the same year's observed, already-adopted donor universe, excluding the focal country.
  donors=[p for p,g in dates[fam].items() if p!=i and g<=t-2];values=[success.get((p,when),{}).get(var,np.nan) if var=='spread_improvement' else L.get((p,when),{}).get(var,np.nan) for p in donors];values=np.array(values,float);values=values[np.isfinite(values)]
  z[prefix+'_threshold_exposure']=float(ww@(vals>np.median(values))) if len(values)>=3 else np.nan
 return z
records=[]
for row in F.to_dict('records'):
 i=row['iso3'];t=int(row['year']);fam=row['family'];when=t-1
 for clock in ['lag1','lag2','fixed2001']:
  z=exposure(i,t,fam,clock);row.update({clock+'_'+k:v for k,v in z.items()})
 p=big.get(i);G=dates[fam].get(p,np.nan);row.update(nearest_larger_peer=p,nearest_larger_adoption=float(G<=when) if np.isfinite(G) else np.nan,nearest_larger_recent=float(G==when) if np.isfinite(G) else np.nan,nearest_larger_older=float(G<when) if np.isfinite(G) else np.nan)
 row['domestic_liquidity']=success.get((i,when),{}).get('domestic_liquidity',np.nan)
 row.update({'l1_'+k:v for k,v in L.get((i,when),{}).items()});records.append(row)
F=pd.DataFrame(records)
# Pre-adoption family market-cap masses retain every supported disclosure family.
CY=pd.read_parquet(B/'data/country-year-liquidity.parquet').set_index(['iso3','year']);masses=[]
for fam,ev in calendar.groupby('regulation_family'):
 vals=[]
 for r in ev.itertuples():
  key=(r.iso3,int(r.reviewed_G)-1)
  if key in CY.index:
   v=CY.loc[key];cap=v.sample_market_cap_usd
   if np.isfinite(cap) and cap>0 and v.sample_company_records>=30:vals.append(float(cap))
 masses.append({'family':fam,'pre_adoption_market_cap_mass':sum(vals),'supported_cases':len(vals)})
pd.DataFrame(masses).to_csv(O/'tables/diffusion-family-weight-masses.csv',index=False);F.to_parquet(O/'data/diffusion-mechanism-panel.parquet',index=False)
coverage=[]
for fam,a in F.groupby('family'):
 coverage.append({'family':fam,'risk_rows':len(a),'countries':a.iso3.nunique(),'events':int(a.first_event.sum()),'portfolio_50pct_rows':int(a.lag1_known_policy_portfolio_share.ge(.5).sum()),'portfolio_80pct_rows':int(a.lag1_known_policy_portfolio_share.ge(.8).sum()),'liquidity_learning_rows':int((a.lag1_known_policy_portfolio_share.ge(.5)&a.lag1_liquidity_success_share.notna()).sum()),'copying_rows':int(a.nearest_larger_adoption.notna().sum())})
pd.DataFrame(coverage).to_csv(O/'tables/mechanism-data-coverage.csv',index=False)
manifest={str(f):{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in [R/'data/current/reviewed-policy-calendar.csv',A/'08-empirical-tests/2026-10-18/reconstructed-annual-portfolio-positions.parquet',OLD/'mechanism_tables_replication/data/merged-final2.xlsx',B/'data/network-memberships.csv',B/'data/macro-country-year.csv',O/'tables/retained-five-liquidity-models.csv']};(O/'audit/input-manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf8')
summary={'rows':len(F),'countries':F.iso3.nunique(),'families':F.family.nunique(),'same_company_pair_rows':len(pairs),'no_imputed_success_used':True,'maximum_signal_year_rule':'All signal years <= outcome adoption year-1; eligible prior donor adopters G<=t-2. Fixed 2001 portfolio starts t>=2003.','original_pasted_results':'Archived source inspected; historic code uses imputed success and fills unknown adoption indicators. Those supplied coefficients are not substituted for this reconstruction.'};(O/'audit/feature-construction.json').write_text(json.dumps(summary,indent=2),encoding='utf8');shutil.copy2(__file__,O/'scripts/build_features.py');print(json.dumps(summary));print(pd.DataFrame(coverage).to_string(index=False))
