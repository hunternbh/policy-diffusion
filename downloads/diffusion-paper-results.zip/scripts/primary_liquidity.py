"""Rebuild exact retained sample/exhibits without changing the five chosen estimates."""
import os
for key in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:os.environ[key]='1'
from pathlib import Path
import sys,json,ast,shutil
sys.path.insert(0,'work/empirical-deps')
import pandas as pd,numpy as np
from scipy.stats import t,chi2
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');A=R/'data/research_archive';O=R/'data/diffusion_submission_2026-10-26';P={'outcomes':['log_spread','log_impact','zero_fraction','illiquidity_index']}
d=pd.read_parquet(A/'09-expanded-policy-paper/2026-10-18/data/security-year-liquidity.parquet');q=pd.read_parquet(A/'17-issuer-regulation-expansion/2026-10-19/data/all-annual-company-mapping.parquet',columns=['security_id','year','dscompcode']).dropna();d=d.merge(q,on=['security_id','year'],validate='one_to_one');cal=pd.read_csv(R/'data/current/reviewed-policy-calendar.csv');macro=pd.read_csv(R/'data/current/macro-country-year.csv').set_index(['iso3','year']);isos=sorted(d.iso3.unique());ci={v:i for i,v in enumerate(isos)};K=len(isos);ledger=[];validation_saved=True
source=Path('work/collective-grid/estimate.py').read_text(encoding='utf8');tree=ast.parse(source)
for node in tree.body:
 if isinstance(node,ast.FunctionDef):exec(compile(ast.Module(body=[node],type_ignores=[]),'<verified-collective-functions>','exec'),globals())
annual=transform('year_p01_p99');panels={(g,1,3):panel(annual,g,1,3) for g in sorted(cal.reviewed_G.dropna().astype(int).unique())};names=['AUDIT_REPORTING','CBCR_BANK_PUBLIC','CLIMATE_DISCLOSURE','ESG_MANDATORY_REVIEWED','SUPPLY_CHAIN'];fs=[family_data(f,1,3,'baseline_gdp',False,panels) for f in names];fits={f['family']:fit([f],[1.]) for f in fs};eventfits={f['family']:fit([f],[1.],True) for f in fs};lock=pd.read_csv(O/'tables/retained-five-liquidity-models.csv');family_cap=np.array([f['cap'] for f in fs]);capmass=family_cap/family_cap.sum();eq=np.ones(5)/5;models={};events=[];weights=[];coeff=[]
for method,mass in [('stack_equal_family',eq),('stack_cap_family',capmass)]:
 m=fit(fs,mass);models[method]=float(m['beta'][0,0]);e=fit(fs,mass,True)
 for j,time in enumerate([-3,-2,1,2,3]):
  for o,out in enumerate(P['outcomes']):
   b=float(e['beta'][j,o]);se=float(np.linalg.norm(e['IF'][:,j,o]));events.append({'model':method,'event_time':time,'outcome':out,'estimate':b,'country_se':se,'countries':e['countries'],'ci_low':b-t.ppf(.975,e['countries']-1)*se,'ci_high':b+t.ppf(.975,e['countries']-1)*se})
 info=np.array([fits[n]['S'][0,0] for n in names]);effective=mass*info/(mass@info)
 for n,w,ew in zip(names,mass,effective):weights.append({'model':method,'family':n,'objective_mass':float(w),'effective_coefficient_weight':float(ew)})
for method,mass in [('average_equal_family',eq),('average_cap_family',capmass)]:
 models[method]=float(sum(w*fits[n]['beta'][0,0] for n,w in zip(names,mass)))
bf=np.array([fits[n]['beta'][0,0] for n in names]);influence=np.stack([fits[n]['IF'][:,0,0] for n in names],axis=1);V=influence.T@influence;gls=np.linalg.solve(V,np.ones(5));gls/=gls.sum();models['gls_common_effect']=float(gls@bf)
for r in lock.itertuples():
 if r.pooling in models:assert np.isclose(models[r.pooling],r.estimate,atol=1e-12),(r.pooling,models[r.pooling],r.estimate)
for f in fs:
 fitf=fits[f['family']]
 for o,out in enumerate(P['outcomes']):coeff.append({'family':f['family'],'outcome':out,'estimate':float(fitf['beta'][0,o]),'country_se':float(np.linalg.norm(fitf['IF'][:,0,o])),'treated_countries':len(f['treated']),'comparison_countries':len(f['comparison'])})
sample=[]
for f in fs:
 for s in f['stacks']:
  pp,years=panels[s['g'],1,3];included=set(s['treated'])|set(s['comparison']);lookup={v['iso3']:v for v in pp if v['iso3'] in included}
  for iso,v in lookup.items():
   for j,y in enumerate(years):sample.append({'family':f['family'],'cohort':s['g'],'iso3':iso,'year':y,'treated':int(iso in s['treated']),'companies':v['companies'],'baseline_cap':v['cap'],'baseline_gdp':v['gdp'],**{out:float(v['Y'][j,o]) for o,out in enumerate(P['outcomes'])}})
sample=pd.DataFrame(sample);assert len(sample)==1002 and sample.iso3.nunique()==46;sample.to_parquet(O/'data/primary-liquidity-country-stack-year.parquet',index=False);pd.DataFrame(events).to_csv(O/'tables/primary-liquidity-event-coefficients.csv',index=False);pd.DataFrame(weights).to_csv(O/'tables/primary-liquidity-effective-family-weights.csv',index=False);pd.DataFrame(coeff).to_csv(O/'tables/primary-liquidity-family-coefficients.csv',index=False);sample[P['outcomes']].describe(percentiles=[.25,.5,.75]).T.to_csv(O/'tables/primary-liquidity-summary-statistics.csv')
controlled=[]
for name in names:
 f=family_data(name,1,3,'baseline_gdp',True,panels)
 if f is None:continue
 for s in f['stacks']:
  for code in np.unique(s['c']):
   iso=isos[int(code)]
   for year in s['years']:controlled.append({'family':name,'cohort':s['g'],'iso3':iso,'year':year,'treated':int(iso in s['treated'])})
pd.DataFrame(controlled).to_parquet(O/'data/primary-liquidity-controlled-memberships.parquet',index=False)
summary={'same_primary_models_reconstructed':models,'all_reconstructed_coefficients_match':True,'rows':len(sample),'countries':sample.iso3.nunique(),'country_family_adoptions':int(sample[sample.treated.eq(1)][['iso3','family']].drop_duplicates().shape[0]),'family_cohorts':int(sample[['family','cohort']].drop_duplicates().shape[0]),'families':sample.family.nunique(),'descriptive_statistics_unit':'Country-stack-year mean of fixed pre-selected companies; repeated countries across policy stacks are distinct estimation rows, not unique stock-years.'};(O/'audit/primary-liquidity-reconstruction.json').write_text(json.dumps(summary,indent=2),encoding='utf8');shutil.copy2(__file__,O/'scripts/primary_liquidity.py');print(json.dumps(summary))
