from pathlib import Path
import json,re,shutil
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'data/diffusion_submission_2026-10-26'
preamble=r'''\documentclass[12pt,letterpaper]{article}
\usepackage[T1]{fontenc}
\usepackage[utf8]{inputenc}
\usepackage{mathptmx}
\usepackage[margin=1in]{geometry}
\usepackage{setspace,graphicx,booktabs,array,longtable,amsmath}
\usepackage[authoryear,round,longnamesfirst]{natbib}
\usepackage[hidelinks,breaklinks]{hyperref}
\hypersetup{pdfauthor={}}
\bibpunct{(}{)}{;}{a}{}{,}
\setlength{\parindent}{0.5in}
\setlength{\parskip}{0pt}
\setlength{\emergencystretch}{3em}
\setlength{\tabcolsep}{4pt}
\renewcommand{\arraystretch}{1.12}
\setcounter{secnumdepth}{1}
\renewcommand{\thesection}{\Roman{section}}
\makeatletter
\renewcommand{\section}{\@startsection{section}{1}{\z@}{-3.5ex plus -1ex minus -.2ex}{2.3ex plus .2ex}{\centering\normalfont\normalsize\bfseries}}
\renewcommand{\subsection}{\@startsection{subsection}{2}{\z@}{-3.25ex plus -1ex minus -.2ex}{1.5ex plus .2ex}{\normalfont\normalsize\bfseries}}
\makeatother
\title{Disclosure Regulation, Stock Liquidity, and International Policy DiffusionTITLE_SUFFIX}
\author{}
\date{26 October 2026}
'''
body=r'''\begin{document}
\doublespacing
\begin{titlepage}
\maketitle\thispagestyle{empty}
\begin{abstract}
\noindent We study the capital-market consequences of public disclosure requirements and the forces associated with their international spread. We combine official policy records with global market data and cross-border portfolio holdings. Five public-disclosure families support a common stacked comparison covering 30 country--family implementations in 46 countries. Quoted spreads are approximately 20.0\% lower under equal family objective mass and 18.6\% lower under market-cap objective mass in the three years after implementation relative to the pre-reform comparison. Explicit family averages and covariance-weighted pooling also yield negative spread estimates. We then distinguish foreign policy exposure, observed outcomes among prior adopters, copying of larger economies and external financial dependence. The implementation-hazard models show a positive interaction between portfolio exposure and observed foreign emissions reductions. Institutional sources document the use of international reporting templates. Together, the analyses connect the market consequences of disclosure with the information and institutions through which reporting requirements travel.
\end{abstract}
\noindent\textit{Keywords:} disclosure regulation; stock liquidity; policy diffusion; learning; international reporting.
\end{titlepage}
\pagenumbering{arabic}

\section{INTRODUCTION}

Extensive literature documents how disclosure affects information asymmetry, investor participation and the cost of trading \citep{diamond1991,welker1995,healy1999,leuz2000}. International reporting studies connect these benefits to enforcement and reporting incentives \citep{daske2008,christensen2013,christensen2016}. Research on mandatory environmental, social and governance disclosure extends this evidence to nonfinancial information \citep{krueger2024,christensen2021}. These studies provide a foundation for understanding individual reporting reforms. There is a gap in our understanding of how liquidity changes across disclosure requirements and how these requirements spread internationally.

We find that quoted spreads are lower around public-disclosure implementation across five supported policy families. The stacked estimates imply approximately 20.0\% lower spreads with equal family objective mass and 18.6\% with market-cap objective mass. Explicit equal-family and market-cap averages are both about -0.199 in log units. Covariance-weighted pooling yields -0.238. We then examine whether countries respond to foreign adoption alone or to the outcomes observed among prior adopters. Portfolio exposure interacts positively with observed foreign emissions reductions in the implementation-hazard models.

If disclosure rules improve transparency, reduce information asymmetry and support efficient capital allocation, it would be reasonable to expect jurisdictions to adopt them promptly and uniformly. In practice, the global pattern looks different. Adoption occurs at different times and varies widely in scope. These differences raise an important question: what forces drive governments to adopt disclosure regulations? We study this question alongside the liquidity patterns that give governments and market participants a reason to consider the rules.

We use the setting of international public-disclosure requirements because it combines a common information channel with variation in the content, audience and timing of regulation. The corpus identifies ten public-disclosure families, including financial reporting, auditor reporting, ESG and climate reporting, public country reports and supply-chain disclosure. Five families support the same six-year liquidity window and documented later-adopter comparisons. This primary sample contains 30 country--family implementations, 14 family--cohorts and 46 countries including comparison countries. Confidential tax reporting forms a separate audience comparison.

We adjust for prior income, GDP growth and trade relative to GDP and continue to find negative spread coefficients in the control-eligible stacked sample. The coefficients are -0.187 under equal family mass and -0.183 under market-cap family mass. We also distinguish a directly stacked slope from an explicit average of policy-family coefficients. This distinction makes clear whether a result describes a common regression slope, the typical supported family or larger sampled market exposures.

To account for alternative explanations, we examine other liquidity measures, the timing of the outcome window and the treatment of extreme observations. We keep the same companies within each comparison window and use countries with documented implementation after the window as controls. We compare untrimmed annual measures with 1\% and 2.5\% trimming and estimate event-time coefficients. These tests show how the pattern depends on the trading measure, sample support and policy clock.

We also distinguish foreign exposure from the conditions under which diffusion mechanisms operate. Following \citet{shipan2008} and \citet{koning2018}, we examine learning, copying, competition and external pressure. Learning uses observed outcomes among prior adopters; copying uses prior implementation by a fixed larger economy and language peers. We compare independent national choices with documented coordinated implementations and include family-specific international waves in the within-country models. This structure connects the diffusion tests to the institutional source of adoption.

This paper contributes to several strands of literature. First, it contributes to research on disclosure and capital markets by comparing different public reporting requirements within one empirical framework. The financial-reporting literature establishes the importance of incentives and enforcement, while nonfinancial reporting research examines information about environmental and social activities \citep{daske2008,christensen2013,krueger2024}. Our contribution is the common comparison across these requirements, using consistent market measures, company-selection rules and clearly defined pooling targets.

Second, the paper contributes to research on the international spread of accounting and financial policies \citep{simmons2004,simmons2006,koning2018}. When policy change is shaped by the prior choices of other jurisdictions, the process is commonly described as policy diffusion. We distinguish broad financial exposure from observed foreign outcomes and institutional templates. This distinction brings the market consequences of reporting requirements into the study of their adoption, while preserving the separate meanings of an adoption association, a policy effect and a diffusion mechanism.

\section{INSTITUTIONAL SETTING AND PREDICTIONS}

\subsection{Public information and capital markets}

Disclosure regulations have meaningful implications for investment decisions and market functioning. Public reports can reduce the cost of obtaining information and make companies easier to compare. Better information can narrow the gap between investors with different information and support trading \citep{diamond1991,healy2001,beyer2010}. The channel is common to financial statements, expanded auditor reports, climate disclosures and public country reports, although the content differs across families.

The audience matters. Confidential country-by-country tax reports are filed with tax authorities and may be exchanged between them. Public bank and multinational country reports instead make specified jurisdictional information available to investors. Confidential reports can change behaviour through tax enforcement; public reports also change the information directly available to the market \citep{desimone2022,muller2024,nessa2025}. We therefore separate the public-disclosure pool from confidential reporting.

\subsection{National choices and international experience}

When a government adopts a new policy, the impetus can come from within the polity or from outside it. Governments may learn from the experiences of early adopters, copy prominent templates, respond to economic rivals or face pressure from an international institution. These mechanisms imply different reasons for responding to the same foreign policy \citep{shipan2008,koning2018}. Learning requires information about outcomes. Copying can follow the visibility or legitimacy of the adopter even when its outcomes are not yet observed.

Cross-border financial ties can expose investors and regulators to foreign reporting practices. Cross-listing may also make firms, auditors and exchanges familiar with those practices. This experience can lower implementation costs, but it can also reduce the additional need for a domestic requirement when firms already comply abroad. International standards and professional implementation networks provide another route through which reporting templates become available across countries. Coordinated legal obligations, including supranational mandates, differ from a national decision to copy a peer.

\subsection{The tension and predictions}

Useful public information should reduce trading frictions. The benefits depend on whether reports add information that investors can use, how much they cost to process and how reporting requirements are implemented \citep{blankespoor2020,blankespoor2014,lennox2023}. We therefore predict lower illiquidity around public-disclosure implementation and examine whether the pattern changes across market and institutional settings.

A market benefit alone need not produce immediate adoption. Governments weigh implementation costs, domestic priorities and the credibility of foreign experience. Learning predicts a stronger response to foreign exposure when prior adopters have visible improvements. Copying predicts a response to a larger or related adopter beyond the outcome signal. Competition and external finance provide parallel explanations for national choices. These predictions guide the measures and comparison models; the regressions describe observable associations through which the proposed mechanisms can be assessed.

\section{DATA AND EMPIRICAL DESIGN}

\subsection{Primary policy data}

Our primary policy data are a register of official laws, standards and implementation materials. These sources are public and verifiable. Each record identifies a country, disclosure family, audience, scope and the basis for its date. Treatment measures country-market exposure to a documented rule; issuer, sector, size and jurisdictional coverage are recorded separately. The wider register contains 482 documented country--family histories, including 60 records identifying countries outside the direct home-country geography of EU bank reporting. These geographic controls are excluded from the implementation-hazard risk sets. The ten-family public corpus is reported separately from confidential tax reporting and broader institutional regulation.

Announcement, legal application, the first covered financial period, the filing deadline and publication can occur in different years. We use the reviewed implementation or reporting-phase date stated in the source record. The resulting clock concerns the documented phase and does not assume an observed filing date for every issuer. Unknown histories remain missing. The implementation-hazard panel stops at the first recorded implementation, rather than carrying post-implementation years into the first-event risk set.

\subsection{Market and country data}

The secondary market data are licensed Datastream observations during 2000--2025. The inventory contains 1,055,142 stock-years, 99,100 vendor company records and 90 jurisdictions. For each liquidity cohort, we select the company's largest positive-market-value share line in year $g-1$ and hold the company, share line and country fixed over the full event window. At least 30 companies with all three outcomes must remain in each country--stack. The primary stacked sample contains 1,002 country--stack--years in 46 countries (Table~\ref{tab:sample}).

We measure annual illiquidity using log quoted spread, log price impact and the fraction of observed daily returns equal to zero. Spread is the annual median relative bid--ask spread. Price impact is the annual median absolute return divided by dollar trading volume, adapting \citet{amihud2002}. The annual screening requires 120 valid observations for the relevant measure. Positive spread and impact values are trimmed within year at the 1st and 99th percentiles before logging. We also report an equally weighted standardized index of the three measures. Lower values indicate greater liquidity. Online Appendix Table A1 gives the complete construction and denominators.

The IMF Portfolio Investment Positions dataset provides observed bilateral asset positions. We select annual total portfolio assets for the total economy and total-economy counterpart, convert reported scales to US dollars and exclude self positions. World Bank data provide income, GDP growth, trade and external finance. Geographic and official-language networks define peers. Reported UNFCCC emissions excluding land use, land-use change and forestry provide an observed environmental-outcome signal. The cross-listing measure is the preceding year's fraction of sampled firms listed abroad. We add no interpolation or forward/backward filling to the liquidity or emissions success measures.

\subsection{Liquidity design and pooling}

For country $c$, family--cohort stack $s$ and calendar year $t$, the stacked model is
\begin{equation}
L_{cst}=\alpha_{cs}+\lambda_{st}+\beta\,Treat_{cs}\times Post_{st}+X_{c,t-1}'\gamma+\varepsilon_{cst}.
\end{equation}
Country FE $\times$ stack and Year FE $\times$ stack absorb fixed country--stack differences and common movements within each event stack. The baseline window contains years $g-3$ through $g-1$ and $g+1$ through $g+3$; year $g$ is omitted. Comparison countries have documented implementation after $g+3$. The design follows the clean-comparison logic of stacked approaches in \citet{krueger2024,baker2022}; it avoids comparisons with already-treated countries \citep{goodmanbacon2021,callaway2021,sun2021}.

GDP in $g-1$ sets country weights, and adopting-country GDP sets cohort mass. We report five pooling models. The first two assign equal or pre-adoption sampled market-cap objective mass across families before estimating a stacked common slope. The next two explicitly average separate family slopes with equal or cap weights. Finally, GLS combines family estimates using their shared-country covariance. With family coefficient vector $b$ and covariance $V$, its weights are $w=V^{-1}1/(1'V^{-1}1)$. Table~\ref{tab:families} reports the family coverage and weights. These pooling targets differ, and companies can be exposed to more than one family.

Country scores are combined across repeated stacks and families before calculating uncertainty. Controls are lagged relative to each liquidity observation. Causal interpretation requires credible counterfactual trends and policy timing; event leads test pre-reform differences on the same fixed-company sample. We report the full event profile, alternative windows, outcome measures, trimming choices and family-support restrictions. GLS inference is conditional on estimated covariance weights. Multiple-comparison adjustments cover the complete 5,184-cell liquidity matrix and the separate 576-cell support matrix \citep{holm1979}.

\subsection{Diffusion design}

The second part estimates the probability of first documented implementation while a country--family remains at risk. In the discrete-time logit,
\begin{equation}
\Pr(First_{cf,t}=1\mid t\leq G_{cf})
=\Lambda\left(\delta_f+\delta_t+Z_{cf,t-1}'\theta+W_{c,t-1}'\eta\right).
\end{equation}
Family FE and Year FE account for policy-family differences and common annual adoption conditions. The main models focus on independent national choices. Complementary linear probability models include Country FE $\times$ family and Family FE $\times$ year. We also estimate the documented coordinated implementations and the combined public/confidential sample. Country-cluster errors account for repeated policies within each country. Both family weights use identical observations within each paired specification.

Portfolio exposure is the share of positive observed assets invested in known prior-adopting partners. We require documented histories covering at least half of observed positive portfolio mass and use 80\% as an alternative. The learning models separate exposure from the observed success share among donors that implemented by $t-2$. Liquidity success is a fall in fixed-company mean log spread from $t-2$ to $t-1$; environmental success is a fall in observed emissions. At least 80\% of eligible-adopter portfolio mass must have observed outcomes. The double interaction includes exposure, success and their product. The domestic-capacity models include every primitive and lower-order product in the triple interaction.

Copying uses the nearest larger economy among ten geographic peers, fixed by GDP in 2000, and separates implementation in the preceding year from older implementation. Other models use export-pattern competitors, language-peer adoption, geographic GDP-growth learning, external finance and cross-listing familiarity. The joint model and all unsupported fits remain in the coefficient matrix. Estimation requires 15 countries, ten events, ten nonevents, 50 observations and numerical identification. Holm adjustments cover all 1,024 focal coefficient attempts. These conditions and the exact variables are defined in Online Appendix Table A1.

\section{LIQUIDITY FINDINGS}

\subsection{The collective spread comparison}

The institutional analysis identifies a common information channel across otherwise different reporting requirements. We first ask whether this channel is reflected in trading costs around implementation. We regress country--stack--year log spread on the adopting-country post indicator using the fixed effects and weights described above. Table~\ref{tab:liquidity-main} presents the five pooling models on the same country and company support.

The stacked coefficient is -0.223 with equal family objective mass and -0.206 with market-cap objective mass. These values correspond to approximately 20.0\% and 18.6\% lower quoted spreads. The explicit equal-family and market-cap averages are -0.199 and -0.199, respectively. GLS gives -0.238. Each supported family's spread coefficient is also negative in this common window. Figure~\ref{fig:pooling} shows the pooled magnitudes and conditional intervals. The negative coefficients under all five pooling methods provide a consistent directional association between public disclosure and lower trading costs in the supported sample.

\subsection{Country conditions and alternative trading measures}

The common sample comparison leaves open whether changing economic conditions account for the spread pattern. We therefore add prior income, GDP growth and trade/GDP. The stacked coefficients remain negative at -0.187 and -0.183 on the control-complete sample (Online Appendix Table A2). The explicit family averages are -0.147 and -0.160. This shows that the negative spread pattern also appears after accounting for the included country conditions.

Spread measures the cost of immediately trading against quoted prices. Price impact and zero-return share address different aspects of trading. Online Appendix Table A3 reports all four outcomes on the same six-year sample, including the standardized index. The alternative measures add information about how trading changes across policy families and pooling targets. We retain each outcome so the spread result can be assessed alongside the wider trading evidence.

\subsection{Timing, outliers and sample support}

The negative spread estimates make timing and sample composition important next questions. We therefore vary annual trimming, the first post-policy year and the length of the comparison window. Online Appendix Tables A4--A5 report the event-time coefficients and every stated stacked alternative. Secondary country--cohort tests examine prior liquidity, regulatory quality, market development, income, trade and matched comparison countries (Tables A8--A9). These analyses separate the six-year primary comparison from tests that need different data support.

The two stacked coefficients remain negative under all three trimming rules in the benchmark years 1--3 window. Table~\ref{tab:families} shows how adopting-country coverage and effective weights differ across families. Extended Appendix Table E4 then imposes minimum adopting-country support. Taken together, these comparisons show which parts of the spread pattern recur across constructions and which depend on the policy sample.

\section{INTERNATIONAL POLICY DIFFUSION}

\subsection{Foreign exposure and the implementation decision}

The liquidity analysis identifies a market pattern that could make disclosure attractive. It leaves unanswered why countries implement requirements at different times. Foreign exposure provides a first way to examine this question: it measures contact with markets that already operate under the rules. We estimate the implementation-hazard model using prior portfolio exposure and the country controls. Columns (1)--(2) of Table~\ref{tab:learning} report the results.

The exposure coefficients are -0.422 under equal family weights and -0.676 under cap weights, with standard errors of 0.803 and 0.950. The estimates concern financial connectedness to documented adopters. They motivate distinguishing exposure itself from the information carried by that exposure. The next models ask whether observed foreign outcomes change the relationship between exposure and implementation.

\subsection{Learning from observed outcomes}

Exposure can bring governments into contact with a reporting regime without showing whether the regime works. Following the success-based distinction in \citet{koning2018}, we combine exposure with observed outcomes among prior adopters. Liquidity and emissions address parallel questions: whether adoption is associated with visible market improvements or with environmental improvements. The models include exposure, the corresponding success share and their interaction.

For liquidity success, the interaction coefficients are 1.835 and 2.616 under equal and cap family weights (Table~\ref{tab:learning}, columns (3)--(4)). The corresponding standard errors are 1.247 and 1.446. The positive interaction means that the portfolio-exposure slope becomes more positive as the observed foreign liquidity-success share rises. This connects the liquidity analysis to a conditional association in the implementation model.

The environmental interaction is 2.140 under equal weights and 2.351 under cap weights, with standard errors of 0.830 and 0.787 (columns (5)--(6)). Both interaction coefficients are positive and conventionally significant. Countries with greater exposure to prior adopters reporting emissions reductions have a more positive exposure--implementation relationship in these hazard specifications. This provides evidence of a conditional association between observed foreign outcomes and national implementation.

The conditional models leave a further question about domestic relevance. A foreign outcome may matter differently depending on the focal country's market or emissions position. Online Appendix Table A7 therefore includes domestic capacity, the two foreign-signal primitives and every lower-order interaction. Table A6 varies portfolio timing and history coverage. These tests make the content and availability of the foreign signal explicit.

\subsection{Copying, competition and international waves}

Observed success is one reason to follow another jurisdiction; the prominence of the adopter is another. We therefore examine the fixed nearest larger economy and separate its recent from older implementation. The available independent-choice sample contains 12 countries, below the stated support requirement. Online Appendix Table A10 reports that coverage and the all-documented comparison. Institutional sources provide a complementary way to observe the availability of templates: the XRB describes New Zealand Climate Standards as based on TCFD, while IAASB and IFAC materials document international auditor-reporting standards and their dissemination (Table~\ref{tab:templates}). These sources show concrete routes through which reporting practices become available across jurisdictions.

Copying, competition and external pressure address parallel explanations for adoption. Table~\ref{tab:within} reports within-country implementation models for GDP-growth learning, language-peer adoption, external finance and cross-listing familiarity. Each includes family-specific international waves. The equal-weight coefficients are -0.045, 0.058, -0.002 and 0.000, respectively; the full estimates, standard errors and paired cap weights are in the table. These comparisons place the foreign-outcome hazard estimates alongside persistent national conditions and common policy-family timing.

The all-documented trade-competition logit gives negative coefficients of -1.292 and -1.834 across the two weights, with the complete results in the accompanying matrix. This differs from a general prediction that countries follow their export competitors. The distinction between independent choices and coordinated obligations is therefore central to interpreting the observed adoption pattern.

\section{CONCLUSION}

We study public-disclosure requirements in two parts: their liquidity patterns and their international implementation. The five retained pooling models all produce negative quoted-spread coefficients on the same supported sample. The two directly stacked estimates imply spreads approximately 20.0\% and 18.6\% lower around implementation under the stated family objective masses. The diffusion analysis separates exposure to foreign rules from observed outcomes among prior adopters and the availability of reporting templates. It shows a positive exposure--emissions-reduction interaction in the implementation-hazard specifications.

The evidence also identifies the conditions that matter for interpretation. Spread differences are present before implementation in the event analysis. Two supported liquidity families have only one adopting country, and GLS assigns 59.6\% of its benchmark weight to climate disclosure. The hazard interaction does not survive the full diffusion-matrix adjustment, and complementary within-country specifications give different estimates. We address these issues by holding companies fixed, using documented comparison histories, reporting event leads, varying timing and weights, and retaining support restrictions and complete model matrices. Future work can sharpen causal interpretation with more complete earliest-law histories, observed issuer filing dates and direct evidence of policymakers' use of foreign outcomes. 

\clearpage
\renewcommand{\refname}{REFERENCES}
\setlength{\bibsep}{0pt}
\bibliographystyle{apalike}
\bibliography{reference}
\singlespacing
\input{figures_tables/submission-main-tables.txt}
\clearpage
\begin{figure}[p]\centering
\includegraphics[width=\linewidth]{figures_tables/submission-liquidity-pooling.png}
\caption{Quoted spreads across the five pooling models}\label{fig:pooling}
{\footnotesize This figure reports $100[\exp(\widehat\beta)-1]$ and transformed conditional 95\% intervals from main Table 3. All models use the same five-family, 46-country primary sample. Negative values indicate lower quoted spreads. Country-cluster uncertainty retains repeated countries across stacks; GLS inference conditions on its estimated covariance weights.\par}
\end{figure}
\clearpage
\begin{figure}[p]\centering
\includegraphics[width=\linewidth]{figures_tables/submission-adoption-timing.png}
\caption{Documented public-disclosure implementations}\label{fig:timing}
{\footnotesize This figure reports 198 recorded country--family implementations dated 2000--2025 in the ten-family public corpus. Panel A counts implementations by year; Panel B counts them by family. Later scheduled phases, outside-home-regime bank controls and other regulatory audiences are excluded. This is the policy corpus, whose coverage differs from the primary liquidity and diffusion estimation samples.\par}
\end{figure}
\clearpage
\end{document}
'''
appendix=r'''\renewcommand{\thetable}{A\arabic{table}}
\renewcommand{\thefigure}{A\arabic{figure}}
\begin{document}
\doublespacing\maketitle
This Online Appendix defines the variables and reports country controls, alternative trading measures, event dynamics, portfolio timing, conditional learning, cross sections and model support. The main paper's five liquidity pooling models form the primary comparison. Secondary country--cohort tests use their stated samples and change windows. Complete coefficient matrices retain every estimated, unestimated and unstable specification.
\singlespacing
\input{figures_tables/submission-online-tables.txt}
\clearpage
\begin{figure}[p]\centering
\includegraphics[width=\linewidth]{figures_tables/submission-liquidity-dynamics.png}
\caption{Spread dynamics on the primary stacked sample}
{\footnotesize This figure reports event-time coefficients and pointwise country-cluster 95\% intervals from Table A4. The sample holds companies fixed across years $-3,-2,-1,1,2,3$. Year $-1$ is the reference; year zero is omitted. The two series use equal and market-cap family objective mass on the same five-family, 46-country sample. Higher log spread indicates greater illiquidity.\par}
\end{figure}
\clearpage
\begin{figure}[p]\centering
\includegraphics[width=\linewidth]{figures_tables/submission-learning-interaction.png}
\caption{Foreign emissions reductions and the portfolio-exposure slope}
{\footnotesize This figure reports the slope $\widehat\theta_P+\widehat\theta_{P\times H}H$ from Table 4's environmental-learning logit models and conditional 95\% intervals using the full coefficient covariance. The horizontal axis is the observed success share between its 10th and 90th sample percentiles. The vertical axis is the adoption log-odds slope per standardized portfolio exposure, rather than a probability change. The two fits use 138 risk-year observations in 18 countries and five public families. Both primitive terms and their interaction, Family FE, Year FE and country controls are included. The plot conditions on the model and observed support.\par}
\end{figure}
\clearpage
\end{document}
'''
extended=r'''\renewcommand{\thetable}{E\arabic{table}}
\begin{document}
\doublespacing\maketitle
This Extended Appendix reports the alternative disclosure audiences and broader regulatory targets, the complete collective-liquidity specification matrix and minimum-adopter support comparisons. The main paper targets five supported public-disclosure families in a common six-year stacked sample. The country--cohort audience comparisons answer the stated secondary change questions on their own supported samples. All original numerical results, model memberships, failed fits and source records remain in the accompanying data.
\singlespacing
\input{figures_tables/submission-extended-tables.txt}
\clearpage
\end{document}
'''
(R/'paper.tex').write_text(preamble.replace('TITLE_SUFFIX','')+body,encoding='utf8');(R/'appendix.tex').write_text(preamble.replace('TITLE_SUFFIX',r'\\[1ex]Online Appendix')+appendix,encoding='utf8');(R/'appendix_excess.tex').write_text(preamble.replace('TITLE_SUFFIX',r'\\[1ex]Extended Appendix')+extended,encoding='utf8')
bib=R/'reference.bib';s=bib.read_text(encoding='utf8')
if '@article{shipan2008,' not in s:s+='''\n@article{shipan2008,
 author = {Shipan, Charles R. and Volden, Craig},
 title = {The Mechanisms of Policy Diffusion},
 journal = {American Journal of Political Science},
 year = {2008}, volume = {52}, number = {4}, pages = {840--857},
 doi = {10.1111/j.1540-5907.2008.00346.x}
}\n'''
bib.write_text(s,encoding='utf8');shutil.copy2(__file__,O/'scripts/write_paper.py');print(json.dumps({'main_body_words_approx':len(re.sub(r'\\[A-Za-z]+','',body.split('\\clearpage\n\\renewcommand')[0]).split()),'main_sources':['paper.tex','appendix.tex','appendix_excess.tex'],'retained_primary_models':5,'author_blank':True}))
