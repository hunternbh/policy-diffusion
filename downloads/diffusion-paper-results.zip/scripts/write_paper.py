from pathlib import Path
import json,re,shutil
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'data/diffusion_submission_2026-10-26'
preamble=r'''\documentclass[12pt,letterpaper]{article}
\usepackage[T1]{fontenc}
\usepackage[utf8]{inputenc}
\usepackage{mathptmx}
\usepackage[margin=1in]{geometry}
\usepackage{setspace,graphicx,booktabs,array,longtable,amsmath}
\usepackage{caption}
\captionsetup[figure]{justification=raggedright,singlelinecheck=false,font=small,labelfont=bf}
\usepackage[authoryear,round,longnamesfirst]{natbib}
\usepackage[hidelinks,breaklinks]{hyperref}
\hypersetup{pdfauthor={}}
\bibpunct{(}{)}{;}{a}{}{,}
\setlength{\parindent}{0.5in}
\setlength{\parskip}{0pt}
\setlength{\emergencystretch}{3em}
\setlength{\tabcolsep}{4pt}
\renewcommand{\arraystretch}{1.12}
\setcounter{secnumdepth}{1}
\renewcommand{\thesection}{\Roman{section}}
\makeatletter
\renewcommand{\section}{\@startsection{section}{1}{\z@}{-3.5ex plus -1ex minus -.2ex}{2.3ex plus .2ex}{\centering\normalfont\normalsize\bfseries}}
\renewcommand{\subsection}{\@startsection{subsection}{2}{\z@}{-3.25ex plus -1ex minus -.2ex}{1.5ex plus .2ex}{\normalfont\normalsize\bfseries}}
\makeatother
\title{Disclosure Regulation, Stock Liquidity, and International Policy DiffusionTITLE_SUFFIX}
\author{}
\date{26 October 2026}
'''
body=r'''\begin{document}
\doublespacing
\hypersetup{pageanchor=false}
\begin{titlepage}
\maketitle\thispagestyle{empty}
\begin{abstract}
\noindent We study the capital-market consequences of public disclosure requirements and the forces associated with their international spread. We combine official policy records with global market data and cross-border portfolio holdings. Five public-disclosure families support a common stacked comparison covering 30 country--family implementations in 46 countries. Stock liquidity improves around implementation: Bid-Ask Spread, our trading-cost proxy, is approximately 20.0\% lower under equal family objective mass and 18.6\% lower under market-cap objective mass in the three post-implementation years relative to the pre-reform comparison. Explicit family averages and covariance-weighted pooling also indicate lower trading costs. We then distinguish foreign policy exposure, observed outcomes among prior adopters, copying of larger economies and external financial dependence. The implementation-hazard models show a positive interaction between portfolio exposure and observed foreign emissions reductions. Institutional sources document the use of international reporting templates. Together, the analyses connect the market consequences of disclosure with the information and institutions through which reporting requirements travel.
\end{abstract}
\noindent\textit{Keywords:} disclosure regulation; stock liquidity; policy diffusion; learning; international reporting.
\end{titlepage}
\pagenumbering{arabic}
\hypersetup{pageanchor=true}

\section{INTRODUCTION}

We examine stock liquidity around the introduction of public disclosure requirements and the forces associated with their international spread. We find that stock liquidity improves around implementation across five supported policy families. The two stacked estimates correspond to reductions of 20.0\% and 18.6\% in Bid-Ask Spread, our measure of the cost of trading immediately. Explicit equal-family and market-cap averages yield coefficients of approximately -0.199, while covariance-weighted pooling yields -0.238. All five models use the same supported sample.

The diffusion results connect implementation to the outcomes observed abroad. The interaction between foreign portfolio exposure and the share of prior adopters reporting emissions reductions is positive under both family weights: the coefficients are 2.140 and 2.351. Exposure has a more positive association with implementation when more prior adopters report these improvements. The interactions with foreign liquidity improvements are also positive, although less precisely estimated. We also test copying, trade competition, external financial dependence and cross-listing familiarity. In the hazard model that includes coordinated implementations, trade-competitor adoption is negatively associated with implementation. Copying, external finance and cross-listing show no stable positive association with implementation. These findings distinguish the information carried by foreign experience from exposure to foreign rules alone.

Extensive literature documents how disclosure affects information asymmetry, investor participation and the cost of trading \citep{diamond1991,welker1995,healy1999,leuz2000}. International reporting studies connect these benefits to enforcement and reporting incentives \citep{daske2008,christensen2013,christensen2016}. Research on mandatory environmental, social and governance disclosure extends this evidence to nonfinancial information \citep{krueger2024,christensen2021}. These studies provide a foundation for understanding individual reporting reforms. There is a gap in our understanding of how liquidity changes across disclosure requirements and how these requirements spread internationally.

If disclosure rules improve transparency, reduce information asymmetry and support efficient capital allocation, it would be reasonable to expect jurisdictions to adopt them promptly and uniformly. In practice, the global pattern looks different. Adoption occurs at different times and varies widely in scope. These differences raise an important question: what forces drive governments to adopt disclosure regulations? We study this question alongside the liquidity patterns that give governments and market participants a reason to consider the rules.

We use the setting of international public-disclosure requirements because it combines a common information channel with variation in the content, audience and timing of regulation. The corpus identifies ten public-disclosure families, including financial reporting, auditor reporting, ESG and climate reporting, public country reports and supply-chain disclosure. Five families support the same six-year liquidity window and documented later-adopter comparisons. This primary sample contains 30 country--family implementations, 14 family--cohorts and 46 countries including comparison countries. Confidential tax reporting forms a separate audience comparison.

We adjust for prior income, GDP growth and trade relative to GDP and continue to find liquidity improvements in the control-eligible stacked sample. The Bid-Ask Spread coefficients are -0.187 under equal family mass and -0.183 under market-cap family mass. We also distinguish a directly stacked slope from an explicit average of policy-family coefficients. This distinction makes clear whether a result describes a common regression slope, the typical supported family or larger sampled market exposures.

To account for alternative explanations, we examine other liquidity measures, the timing of the outcome window and the treatment of extreme observations. We keep the same companies within each comparison window and use countries with documented implementation after the window as controls. We compare untrimmed annual measures with 1\% and 2.5\% trimming and estimate event-time coefficients. For diffusion, we distinguish independent national choices from coordinated implementations and include family-specific international waves in within-country models. Following \citet{shipan2008} and \citet{koning2018}, the tests separate learning, copying, competition and external pressure.

This paper contributes to several strands of literature. First, it contributes to research on disclosure and capital markets by comparing different public reporting requirements within one empirical framework. The financial-reporting literature establishes the importance of incentives and enforcement, while nonfinancial reporting research examines information about environmental and social activities \citep{daske2008,christensen2013,krueger2024}. Our contribution is the common comparison across these requirements, using consistent market measures, company-selection rules and clearly defined pooling targets.

Second, the paper contributes to research on the international spread of accounting and financial policies \citep{simmons2004,simmons2006,koning2018}. When policy change is shaped by the prior choices of other jurisdictions, the process is commonly described as policy diffusion. We distinguish broad financial exposure from observed foreign outcomes, prominent adopters, economic competitors and external financial ties. This distinction brings the market consequences of reporting requirements into the study of their adoption, while preserving the separate meanings of an adoption association, a policy effect and a diffusion mechanism.

\section{INSTITUTIONAL SETTING AND PREDICTIONS}

\subsection{Public information and capital markets}

Disclosure regulations have meaningful implications for investment decisions and market functioning. Public reports can reduce the cost of obtaining information and make companies easier to compare. Better information can narrow the gap between investors with different information and support trading \citep{diamond1991,healy2001,beyer2010}. The channel is common to financial statements, expanded auditor reports, climate disclosures and public country reports, although the content differs across families.

The audience matters. Confidential country-by-country tax reports are filed with tax authorities and may be exchanged between them. Public bank and multinational country reports instead make specified jurisdictional information available to investors. Confidential reports can change behaviour through tax enforcement; public reports also change the information directly available to the market \citep{desimone2022,muller2024,nessa2025}. We therefore separate the public-disclosure pool from confidential reporting.

\subsection{National choices and international experience}

When a government adopts a new policy, the impetus can come from within the polity or from outside it. Governments may learn from the experiences of early adopters, copy prominent templates, respond to economic rivals or face pressure from an international institution. These mechanisms imply different reasons for responding to the same foreign policy \citep{shipan2008,koning2018}. Learning requires information about outcomes. Copying can follow the visibility or legitimacy of the adopter even when its outcomes are not yet observed.

Cross-border financial ties can expose investors and regulators to foreign reporting practices. Cross-listing may also make firms, auditors and exchanges familiar with those practices. This experience can lower implementation costs, but it can also reduce the additional need for a domestic requirement when firms already comply abroad. International standards and professional implementation networks provide another route through which reporting templates become available across countries. Coordinated legal obligations, including supranational mandates, differ from a national decision to copy a peer.

\subsection{The tension and predictions}

Useful public information should reduce trading frictions. The benefits depend on whether reports add information that investors can use, how much they cost to process and how reporting requirements are implemented \citep{blankespoor2020,blankespoor2014,lennox2023}. We therefore predict lower illiquidity around public-disclosure implementation and examine whether the pattern changes across market and institutional settings.

A market benefit alone need not produce immediate adoption. Governments weigh implementation costs, domestic priorities and the credibility of foreign experience. Learning predicts a stronger response to foreign exposure when prior adopters have visible improvements. Copying predicts a response to a larger or related adopter beyond the outcome signal. Competition and external finance provide parallel explanations for national choices. These predictions guide the measures and comparison models; the regressions describe observable associations through which the proposed mechanisms can be assessed.

\section{DATA AND EMPIRICAL DESIGN}

\subsection{Primary policy data}

Our primary policy data are a register of official laws, standards and implementation materials. These sources are public and verifiable. Each record identifies a country, disclosure family, audience, scope and the basis for its date. Treatment measures country-market exposure to a documented rule; issuer, sector, size and jurisdictional coverage are recorded separately. The wider register contains 482 documented country--family histories, including 60 records identifying countries outside the direct home-country geography of EU bank reporting. These geographic controls are excluded from the implementation-hazard risk sets. The ten-family public corpus is reported separately from confidential tax reporting and broader institutional regulation. Figure~\ref{fig:policy-coverage} shows all dated regulatory families in the register and the country coverage of the ten public-disclosure families. Countries are grouped by similar policy profiles, using no liquidity outcomes.

Announcement, legal application, the first covered financial period, the filing deadline and publication can occur in different years. We use the reviewed implementation or reporting-phase date stated in the source record. The resulting clock concerns the documented phase and does not assume an observed filing date for every issuer. Unknown histories remain missing. The implementation-hazard panel stops at the first recorded implementation, rather than carrying post-implementation years into the first-event risk set.

\subsection{Market and country data}

The secondary market data are licensed Datastream observations during 2000--2025. The inventory contains 1,055,142 stock-years, 99,100 vendor company records and 90 jurisdictions. For each liquidity cohort, we select the company's largest positive-market-value share line in year $g-1$ and hold the company, share line and country fixed over the full event window. At least 30 companies with all three outcomes must remain in each country--stack. The primary stacked sample contains 1,002 country--stack--years in 46 countries (Table~\ref{tab:sample}).

Following the liquidity framework in \citet{krueger2024}, we use three proxies for stock liquidity: Bid-Ask Spread, Price Impact and Zero Return. Bid-Ask Spread is the annual median difference between the closing ask and bid prices, divided by their midpoint. Price Impact is the annual median absolute return divided by dollar trading volume, adapting \citet{amihud2002}. Zero Return is the fraction of observed valid daily returns equal to zero. The annual screening requires 120 valid observations for the relevant measure. Positive Bid-Ask Spread and Price Impact values are trimmed within year at the 1st and 99th percentiles before logging. We also report an equally weighted standardized illiquidity index of the three proxies. Lower values indicate greater stock liquidity. The index uses equal weights after fixed 2000 standardization; Zero Return uses observed valid returns as its denominator. Online Appendix Table A1 gives the complete construction and denominators.

The IMF Portfolio Investment Positions dataset provides observed bilateral asset positions. We select annual total portfolio assets for the total economy and total-economy counterpart, convert reported scales to US dollars and exclude self positions. World Bank data provide income, GDP growth, trade and external finance. Geographic and official-language networks define peers. Reported UNFCCC emissions excluding land use, land-use change and forestry provide an observed environmental-outcome signal. The cross-listing measure is the preceding year's fraction of sampled firms listed abroad. We add no interpolation or forward/backward filling to the liquidity or emissions success measures.

\subsection{Liquidity design and pooling}

For country $c$, family--cohort stack $s$ and calendar year $t$, the stacked model is
\begin{equation}
L_{cst}=\alpha_{cs}+\lambda_{st}+\beta\,Treat_{cs}\times Post_{st}+X_{c,t-1}'\gamma+\varepsilon_{cst}.
\end{equation}
Country FE $\times$ stack and Year FE $\times$ stack absorb fixed country--stack differences and common movements within each event stack. The baseline window contains years $g-3$ through $g-1$ and $g+1$ through $g+3$; year $g$ is omitted. Comparison countries have documented implementation after $g+3$. The design follows the clean-comparison logic of stacked approaches in \citet{krueger2024,baker2022}; it avoids comparisons with already-treated countries \citep{goodmanbacon2021,callaway2021,sun2021}.

GDP in $g-1$ sets country weights, and adopting-country GDP sets cohort mass. We report five pooling models. The first two assign equal or pre-adoption sampled market-cap objective mass across families before estimating a stacked common slope. The next two explicitly average separate family slopes with equal or cap weights. Finally, GLS combines family estimates using their shared-country covariance. With family coefficient vector $b$ and covariance $V$, its weights are $w=V^{-1}1/(1'V^{-1}1)$. Table~\ref{tab:families} reports the family coverage and weights. These pooling targets differ, and companies can be exposed to more than one family.

Country scores are combined across repeated stacks and families before calculating uncertainty. Controls are lagged relative to each liquidity observation. Causal interpretation requires credible counterfactual trends and policy timing; event leads test pre-reform differences on the same fixed-company sample. We report the full event profile, alternative windows, outcome measures, trimming choices and family-support restrictions. GLS inference is conditional on estimated covariance weights. Multiple-comparison adjustments cover the complete 5,184-cell liquidity matrix and the separate 576-cell support matrix \citep{holm1979}.

\subsection{Diffusion design}

The second part estimates the probability of first documented implementation while a country--family remains at risk. In the discrete-time logit,
\begin{equation}
\Pr(First_{cf,t}=1\mid t\leq G_{cf})
=\Lambda\left(\delta_f+\delta_t+Z_{cf,t-1}'\theta+W_{c,t-1}'\eta\right).
\end{equation}
Family FE and Year FE account for policy-family differences and common annual adoption conditions. The main models focus on independent national choices. Complementary linear probability models include Country FE $\times$ family and Family FE $\times$ year. We also estimate the documented coordinated implementations and the combined public/confidential sample. Country-cluster errors account for repeated policies within each country. Both family weights use identical observations within each paired specification.

Portfolio exposure is the share of positive observed assets invested in known prior-adopting partners. We require documented histories covering at least half of observed positive portfolio mass and use 80\% as an alternative. The learning models separate exposure from the observed success share among donors that implemented by $t-2$. Liquidity success is a fall in fixed-company mean log Bid-Ask Spread from $t-2$ to $t-1$; environmental success is a fall in observed emissions. At least 80\% of eligible-adopter portfolio mass must have observed outcomes. The double interaction includes exposure, success and their product. The domestic-capacity models include every primitive and lower-order product in the triple interaction.

Copying uses the nearest larger economy among ten geographic peers, fixed by GDP in 2000, and separates implementation in the preceding year from older implementation. Other models use export-pattern competitors, language-peer adoption, geographic GDP-growth learning, external finance and cross-listing familiarity. The joint model and all unsupported fits remain in the coefficient matrix. Estimation requires 15 countries, ten events, ten nonevents, 50 observations and numerical identification. Holm adjustments cover all 1,024 focal coefficient attempts. These conditions and the exact variables are defined in Online Appendix Table A1.

\section{LIQUIDITY FINDINGS}

\subsection{Stock liquidity around disclosure implementation}

The institutional analysis identifies a common information channel across otherwise different reporting requirements. We first ask whether this channel is reflected in trading costs around implementation. We regress country--stack--year log Bid-Ask Spread on the adopting-country post indicator using the fixed effects and weights described above. Table~\ref{tab:liquidity-main} presents the five pooling models on the same country and company support.

The stacked coefficient is -0.223 with equal family objective mass and -0.206 with market-cap objective mass. These values indicate higher stock liquidity, with Bid-Ask Spread approximately 20.0\% and 18.6\% lower around implementation. The explicit equal-family and market-cap averages are -0.199 and -0.199, respectively. GLS gives -0.238. Each supported family's Bid-Ask Spread coefficient is also negative in this common window. Figure~\ref{fig:pooling}, Panel B, shows the implied reductions in trading costs and conditional intervals. All five pooling methods associate public disclosure with higher stock liquidity in the supported sample.

\subsection{Country conditions and alternative trading measures}

The common sample comparison leaves open whether changing economic conditions account for the liquidity pattern. We therefore add prior income, GDP growth and trade/GDP. The Bid-Ask Spread coefficients remain negative at -0.187 and -0.183 on the control-complete sample (Online Appendix Table A2). The explicit family averages are -0.147 and -0.160. This shows that the liquidity improvement also appears after accounting for the included country conditions.

Bid-Ask Spread measures the cost of immediately trading against quoted prices. Price Impact and Zero Return address different aspects of trading. Online Appendix Table A3 reports all four outcomes on the same six-year sample, including the standardized index. The alternative measures add information about how trading changes across policy families and pooling targets.

\subsection{Timing, outliers and sample support}

The liquidity improvements make timing and sample composition important next questions. We therefore vary annual trimming, the first post-policy year and the length of the comparison window. Online Appendix Tables A4--A5 report the event-time coefficients and every stated stacked alternative. Secondary country--cohort tests examine prior liquidity, regulatory quality, market development, income, trade and matched comparison countries (Tables A8--A9). These analyses separate the six-year primary comparison from tests that need different data support.

The two stacked coefficients remain negative under all three trimming rules in the benchmark years 1--3 window. Table~\ref{tab:families} shows how adopting-country coverage and effective weights differ across families. Extended Appendix Table E4 then imposes minimum adopting-country support. Taken together, these comparisons show which parts of the liquidity pattern recur across constructions and which depend on the policy sample.

\section{INTERNATIONAL POLICY DIFFUSION}

The liquidity analysis identifies a market pattern that could make disclosure attractive. It leaves unanswered why countries implement requirements at different times. We study four diffusion mechanisms: learning from observed outcomes, copying prominent or related economies, competition with economic rivals, and external pressure. Cross-listing provides a complementary test of familiarity with foreign reporting. Each mechanism has its own measure and comparison; learning and copying are not the only channels tested.

We first distinguish contact with foreign rules from the information carried by that contact. Prior portfolio exposure measures the share of observed foreign assets invested in documented adopting jurisdictions. In the implementation-hazard models, the exposure coefficients are -0.422 under equal family weights and -0.676 under market-cap weights, with standard errors of 0.803 and 0.950 (Table~\ref{tab:learning}, columns (1)--(2)). The next tests ask whether outcomes observed among those adopters change the exposure--implementation relationship.

\subsection{Diffusion Mechanism 1 -- Learning from observed outcomes}

Learning means responding to evidence about how a policy works. Foreign adoption alone cannot distinguish this response from simply following another country. Following \citet{koning2018}, we therefore combine portfolio exposure with outcomes observed among countries that implemented the requirement earlier. We use three outcome signals: stock-liquidity improvements, emissions reductions and economic growth. The first two enter exposure-by-success interactions; the third compares growth among geographic peers that have and have not implemented the rule.

For the market-outcome signal, success means an improvement in stock liquidity, measured by a fall in Bid-Ask Spread for the same companies in adjacent years. We use only outcomes observed after the donor country's implementation and before the focal country's decision. Columns (3)--(4) of Table~\ref{tab:learning} include exposure, the observed success share and their interaction. The interaction coefficients are 1.835 and 2.616 under equal and market-cap family weights, with standard errors of 1.247 and 1.446. The positive coefficients mean that exposure has a more positive association with implementation when more prior adopters experience liquidity improvements.

For the environmental-outcome signal, success means a fall in reported greenhouse-gas emissions. Columns (5)--(6) yield interaction coefficients of 2.140 and 2.351, with standard errors of 0.830 and 0.787. Both are positive and conventionally significant. A country with greater exposure to prior adopters has a more positive exposure--implementation relationship when more of those adopters report emissions reductions. This provides evidence of a conditional association between observed foreign outcomes and national implementation.

The economic-growth test asks a parallel question: are countries more likely to implement a requirement when prior adopters among their geographic peers grow faster? The measure compares prior-year median growth among adopting and nonadopting peers with documented policy histories. In the within-country models, the coefficients are -0.045 and -0.157 (Table~\ref{tab:within}, column (1)). These estimates do not show the predicted positive relationship. The distinction matters because a visible policy-specific outcome and overall economic growth convey different information to a government considering a reporting rule.

We next consider whether foreign experience matters differently with domestic market conditions or emissions. Online Appendix Table A7 includes domestic capacity, both foreign-signal primitives and every lower-order interaction. Table A6 varies portfolio timing and the required coverage of policy histories. These comparisons make the content, timing and availability of the learning signal explicit. Online Appendix Figure A2 shows how the portfolio-exposure slope varies with observed emissions reductions.

\subsection{Diffusion Mechanism 2 -- Copying larger or related economies}

Countries may follow a prominent adopter because its policy is visible or considered legitimate. This mechanism need not depend on favourable outcomes. We test copying with two measures: prior implementation by a fixed larger geographic peer and the fraction of language peers that have already implemented the requirement. The larger peer is chosen using GDP in 2000; its identity does not change as policies are adopted. We separate implementation in the preceding year from older implementation, following the timing logic in \citet{shipan2008}.

The independent-choice larger-peer sample contains 12 countries, below the stated 15-country support requirement. Online Appendix Table A10 reports this coverage and the all-documented comparison. In the latter, recent-peer coefficients are 0.118 and -0.742; older-peer coefficients are -0.917 and -1.905. The language-peer coefficients in the within-country models are 0.058 and 0.043 (Table~\ref{tab:within}, column (2)). Together, the estimates do not show a stable positive response to implementation by a larger or linguistically related country.

Official sources nevertheless show that international templates are available to national standard setters. The XRB describes New Zealand Climate Standards as based on TCFD, while IAASB and IFAC materials document international auditor-reporting standards and their dissemination (Table~\ref{tab:templates}). These cases identify practical routes through which reporting practices travel. They complement the adoption comparisons by showing the institutional infrastructure through which a country can obtain a reporting template.

\subsection{Diffusion Mechanism 3 -- Competition with economic rivals}

Copying concerns the prominence or proximity of an adopter. Competition instead concerns the economic consequences of falling behind a rival. We identify five countries with the most similar export-destination patterns in 2000 and measure prior adoption among those with documented histories. Fixing the network before the adoption period prevents the choice of competitors from responding to subsequent implementation.

The independent-choice sample has nine countries and does not meet the support requirement. With all documented implementations, the logit coefficients are -1.292 under equal weights and -1.834 under market-cap weights, with standard errors of 0.229 and 0.314. Both remain significant after the diffusion-matrix adjustment. These estimates associate greater competitor adoption with lower implementation likelihood in that sample. The corresponding within-country coefficients are near zero after absorbing country--family differences and family-specific international waves. This pattern makes the distinction between independent national decisions and coordinated legal requirements central to the interpretation of competition.

\subsection{Diffusion Mechanism 4 -- External pressure and financial dependence}

Domestic reporting choices may also be shaped by external institutions. Following \citet{koning2018}, we examine a country's reliance on external finance. The measure adds net official development assistance to the World Bank series for IMF credit and SDR allocations, scales the total by GDP, and uses the preceding year's value. It measures financial dependence; the data do not identify a lender's policy conditions.

The within-country coefficients are -0.002 under equal family weights and -0.067 under market-cap weights (Table~\ref{tab:within}, column (3)). The standard errors are 0.015 and 0.050. These estimates provide no positive association between greater measured financial dependence and implementation. We also distinguish independent national choices from coordinated legal obligations in the policy register. That distinction records an institutional source of external pressure directly, rather than assigning it from the financing proxy.

\subsection{Additional channel -- Cross-listing and familiarity with foreign reporting}

Cross-listing offers a separate route through which firms, auditors and regulators become familiar with foreign reporting practices. Such familiarity may lower the cost of a domestic requirement. It may also reduce the additional need for a local rule when firms already report abroad. We measure the preceding year's share of sampled firms that are cross-listed and estimate the same within-country model.

The coefficients are 0.0002 and 0.0022 under equal and market-cap family weights, with standard errors of 0.0170 and 0.0175 (Table~\ref{tab:within}, column (4)). The sample contains 870 risk-year observations in 25 countries and nine public-disclosure families. These estimates show little association between general cross-listing prevalence and national implementation. Because the measure does not identify each issuer's host-country reporting rule, it captures familiarity with foreign reporting generally. The result separates this broad exposure channel from the outcome-based learning tests.

\section{CONCLUSION}

We study public-disclosure requirements in two parts: their liquidity patterns and their international implementation. The five retained pooling models all produce negative Bid-Ask Spread coefficients on the same supported sample. The two directly stacked estimates imply higher stock liquidity, with Bid-Ask Spread approximately 20.0\% and 18.6\% lower around implementation under the stated family objective masses. The diffusion analysis separates exposure to foreign rules from observed outcomes among prior adopters and the availability of reporting templates. It shows a positive exposure--emissions-reduction interaction in the implementation-hazard specifications.

The evidence also identifies the conditions that matter for interpretation. Differences in the trading-cost proxy are present before implementation in the event analysis. Two supported liquidity families have only one adopting country, and GLS assigns 59.6\% of its benchmark weight to climate disclosure. The hazard interaction does not survive the full diffusion-matrix adjustment, and complementary within-country specifications give different estimates. We address these issues by holding companies fixed, using documented comparison histories, reporting event leads, varying timing and weights, and retaining support restrictions and complete model matrices. Future work can sharpen causal interpretation with more complete earliest-law histories, observed issuer filing dates and direct evidence of policymakers' use of foreign outcomes. 

\clearpage
\renewcommand{\refname}{REFERENCES}
\setlength{\bibsep}{0pt}
\bibliographystyle{apalike}
\bibliography{reference}
\singlespacing
\clearpage
\begin{figure}[p]
\centering
\includegraphics[width=\linewidth,height=.77\textheight,keepaspectratio]{figures_tables/submission-policy-country-overview.png}
\caption{Regulatory families and international policy coverage}\label{fig:policy-coverage}
{\footnotesize\raggedright This figure shows the policy register and country coverage. Panel A counts countries with documented implementations dated 2000--2025 across all 17 regulatory families, distinguishing ten public-disclosure families, confidential tax reporting and broader regulation. Panels B and C show the ten public-disclosure families in 56 countries; colour identifies the documented year. Countries are grouped by similarity in their recorded policy profiles using average-linkage clustering of Jaccard distances, without market outcomes. Red dots mark the 30 country--family implementations in the primary liquidity sample. Grey cells indicate no implementation dated 2000--2025 documented in this register, not verified nonadoption. Sources are the official laws, standards and implementation documents in the policy register.\par}
\end{figure}
\clearpage
\begin{figure}[p]
\centering
\includegraphics[width=\linewidth,height=.72\textheight,keepaspectratio]{figures_tables/submission-implementation-liquidity.png}
\caption{Public-disclosure implementation and stock liquidity}\label{fig:pooling}\label{fig:timing}
{\footnotesize\raggedright This figure combines the implementation chronology and the primary liquidity estimates. Panel A counts 198 documented country--family implementations dated 2000--2025 across ten public-disclosure families. Panel B reports trading-cost reductions, $100[1-\exp(\widehat\beta)]$, from the five models in Table 3, with transformed conditional 95\% intervals. Positive values indicate lower Bid-Ask Spread and therefore greater stock liquidity; they are not proportionate increases in liquidity itself. All five models use the same 1,002 country--stack--years, 46 countries and five supported families. GDP sets country weights; the five pooling rules differ in family aggregation. Shared-country scores preserve dependence across stacks, and GLS inference conditions on estimated covariance weights. Sources are Datastream and the official policy register.\par}
\end{figure}
\clearpage
\input{figures_tables/submission-main-tables.txt}
\clearpage
\end{document}
'''
appendix=r'''\renewcommand{\thetable}{A\arabic{table}}
\renewcommand{\thefigure}{A\arabic{figure}}
\begin{document}
\doublespacing\maketitle
This Online Appendix defines the variables and reports country controls, alternative trading measures, event dynamics, portfolio timing, conditional learning, cross sections and model support. The main paper's five liquidity pooling models form the primary comparison. Secondary country--cohort tests use their stated samples and change windows. Complete coefficient matrices retain every estimated, unestimated and unstable specification.
\singlespacing
\clearpage
\begin{figure}[p]\centering
\includegraphics[width=\linewidth]{figures_tables/submission-liquidity-dynamics.png}
\caption{Stock-liquidity dynamics on the primary stacked sample}
{\footnotesize\raggedright This figure reports event-time coefficients and pointwise country-cluster 95\% intervals from Table A4. The sample holds companies fixed across years $-3,-2,-1,1,2,3$. Year $-1$ is the reference; year zero is omitted. The two series use equal and market-cap family objective mass on the same five-family, 46-country sample. Higher log Bid-Ask Spread indicates lower stock liquidity.\par}
\end{figure}
\clearpage
\begin{figure}[p]\centering
\includegraphics[width=\linewidth]{figures_tables/submission-learning-interaction.png}
\caption{Foreign emissions reductions and the portfolio-exposure slope}\label{fig:learning-slope}
{\footnotesize\raggedright This figure reports the slope $\widehat\theta_P+\widehat\theta_{P\times H}H$ from Table 4's environmental-learning logit models and conditional 95\% intervals using the full coefficient covariance. The horizontal axis is the observed success share between its 10th and 90th sample percentiles. The vertical axis is the adoption log-odds slope per standardized portfolio exposure, rather than a probability change. The two fits use 138 risk-year observations in 18 countries and five public families. Both primitive terms and their interaction, Family FE, Year FE and country controls are included. The plot conditions on the model and observed support.\par}
\end{figure}
\clearpage
\input{figures_tables/submission-online-tables.txt}
\clearpage
\end{document}
'''
extended=r'''\renewcommand{\thetable}{E\arabic{table}}
\begin{document}
\doublespacing\maketitle
This Extended Appendix reports the alternative disclosure audiences and broader regulatory targets, the complete collective-liquidity specification matrix and minimum-adopter support comparisons. The main paper targets five supported public-disclosure families in a common six-year stacked sample. The country--cohort audience comparisons answer the stated secondary change questions on their own supported samples. All original numerical results, model memberships, failed fits and source records remain in the accompanying data.
\singlespacing
\input{figures_tables/submission-extended-tables.txt}
\clearpage
\end{document}
'''
(R/'paper.tex').write_text(preamble.replace('TITLE_SUFFIX','')+body,encoding='utf8');(R/'appendix.tex').write_text(preamble.replace('TITLE_SUFFIX',r'\\[1ex]Online Appendix')+appendix,encoding='utf8');(R/'appendix_excess.tex').write_text(preamble.replace('TITLE_SUFFIX',r'\\[1ex]Extended Appendix')+extended,encoding='utf8')
bib=R/'reference.bib';s=bib.read_text(encoding='utf8')
if '@article{shipan2008,' not in s:s+='''\n@article{shipan2008,
 author = {Shipan, Charles R. and Volden, Craig},
 title = {The Mechanisms of Policy Diffusion},
 journal = {American Journal of Political Science},
 year = {2008}, volume = {52}, number = {4}, pages = {840--857},
 doi = {10.1111/j.1540-5907.2008.00346.x}
}\n'''
bib.write_text(s,encoding='utf8');shutil.copy2(__file__,O/'scripts/write_paper.py');print(json.dumps({'main_body_words_approx':len(re.sub(r'\\[A-Za-z]+','',body.split('\\clearpage\n\\renewcommand')[0]).split()),'main_sources':['paper.tex','appendix.tex','appendix_excess.tex'],'retained_primary_models':5,'author_blank':True}))
