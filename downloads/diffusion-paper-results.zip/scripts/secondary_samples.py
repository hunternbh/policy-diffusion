from pathlib import Path
import sys,ast,json,shutil
sys.path.insert(0,'work/empirical-deps')
import pandas as pd,numpy as np
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');A=R/'data/research_archive';O=R/'data/diffusion_submission_2026-10-26';outcomes=['log_spread','log_impact','zero_fraction'];d=pd.read_parquet(A/'09-expanded-policy-paper/2026-10-18/data/security-year-liquidity.parquet');q=pd.read_parquet(A/'17-issuer-regulation-expansion/2026-10-19/data/all-annual-company-mapping.parquet',columns=['security_id','year','dscompcode']).dropna();d=d.merge(q,on=['security_id','year'],validate='one_to_one');annual={int(y):z.set_index('security_id') for y,z in d.groupby('year')};macro=pd.read_csv(R/'data/current/macro-country-year.csv').set_index(['iso3','year']);cal=pd.read_csv(R/'data/current/reviewed-policy-calendar.csv');isos=sorted(d.iso3.unique());idx={v:i for i,v in enumerate(isos)};cache={}
tree=ast.parse(Path('work/design-audit/liquidity_grid.py').read_text())
for n in tree.body:
 if isinstance(n,ast.FunctionDef) and n.name in ['scalar','panel']:exec(compile(ast.Module(body=[n],type_ignores=[]),'<frozen-secondary-functions>','exec'),globals())
rows=[];est=[]
for window in ['first_year','mean_0_2']:
 for fam,ev in cal.groupby('regulation_family'):
  dates=ev.set_index('iso3').reviewed_G.to_dict();cohorts=[]
  for g in sorted(ev.loc[ev.reviewed_G.between(2001,2024),'reviewed_G'].astype(int).unique()):
   pp=panel(g,1,window)
   if pp is None:continue
   a,end=pp
   if a.empty or end>2025:continue
   a=a.copy();a['G']=a.iso3.map(dates);a=a[a.G.eq(g)|a.G.gt(end)]
   if end>=2025:a=a[~((a.iso3.eq('USA')&(fam=='BENEFICIAL_OWNERSHIP'))|(a.iso3.eq('DEU')&(fam=='SUPPLY_CHAIN')))]
   a=a[a.gdp.notna()&a.gdp.gt(0)].copy();a['T']=a.G.eq(g).astype(int);tr=a.T if False else a['T'].eq(1)
   if tr.sum()<1 or (~tr).sum()<3:continue
   beta=np.array([np.average(a.loc[tr,o],weights=a.loc[tr,'gdp'])-np.average(a.loc[~tr,o],weights=a.loc[~tr,'gdp']) for o in outcomes]);cohorts.append({'mass':a.loc[tr,'gdp'].sum(),'cap':a.loc[tr,'cap'].sum(),'beta':beta});rows.extend({'post_window':window,'family':fam,'cohort':int(g),'iso3':r.iso3,'treated':int(r.T),'companies':int(r.companies)} for r in a.itertuples())
  if cohorts:
   mass=np.array([r['mass'] for r in cohorts]);mass/=mass.sum();est.append({'post_window':window,'family':fam,'cap':sum(r['cap'] for r in cohorts),**{o:float(sum(w*r['beta'][j] for w,r in zip(mass,cohorts))) for j,o in enumerate(outcomes)}})
samples=pd.DataFrame(rows);E=pd.DataFrame(est);prior=json.loads((R/'data/current/analysis-plan.json').read_text());scopes={'public_disclosure':prior['headline_families'],'public_and_confidential':prior['all_disclosure_families'],'broader_17_families':list(cal.regulation_family.unique())};original=pd.read_csv(R/'data/current/tables/main-liquidity.csv');counts=[];maxerr=0.
for scope,names in scopes.items():
 for window in ['first_year','mean_0_2']:
  e=E[E.family.isin(names)&E.post_window.eq(window)];a=samples[samples.family.isin(e.family)&samples.post_window.eq(window)];counts.append({'scope':scope,'post_window':window,'families':len(e),'country_family_cohort_rows':len(a),'countries':a.iso3.nunique(),'family_cohorts':len(a[['family','cohort']].drop_duplicates()),'adopting_country_family_cases':len(a[a.treated.eq(1)][['iso3','family']].drop_duplicates())})
  for scheme in ['equal_family','baseline_market_cap_family']:
   w=np.ones(len(e))/len(e) if scheme=='equal_family' else e.cap.to_numpy()/e.cap.sum()
   for out in outcomes:
    b=float(w@e[out]);target=original[original.scope.eq(scope)&original.post_window.eq(window)&original.family_weight.eq(scheme)&original.outcome.eq(out)].estimate.iloc[0];err=abs(b-target);maxerr=max(maxerr,err);assert err<1e-9,(scope,window,scheme,out,b,target)
samples.to_parquet(O/'data/secondary-country-family-cohort-memberships.parquet',index=False);pd.DataFrame(counts).to_csv(O/'tables/secondary-sample-counts.csv',index=False);result={'all_36_secondary_coefficients_reproduced':True,'maximum_absolute_error':maxerr,'sample_counts':counts};(O/'audit/secondary-reconstruction.json').write_text(json.dumps(result,indent=2),encoding='utf8');shutil.copy2(__file__,O/'scripts/secondary_samples.py');print(json.dumps(result))
