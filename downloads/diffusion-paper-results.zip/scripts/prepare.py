from pathlib import Path
import sys,json,hashlib,shutil,datetime
sys.path.insert(0,'work/empirical-deps')
import pandas as pd
from pypdf import PdfReader
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');A=R/'data/research_archive';O=R/'data/diffusion_submission_2026-10-26'
for folder in ['input_snapshot','data','tables','scripts','literature','audit']:(O/folder).mkdir(parents=True,exist_ok=True)
for name in ['paper.tex','appendix.tex','appendix_excess.tex','reference.bib']:
 dst=O/'input_snapshot'/name
 if not dst.exists():shutil.copy2(R/name,dst)
attachments=Path(r'C:\Users\hia_n\.codex\attachments\d56a869f-68a8-4fc7-b0b8-11e1c3aa6389')
for name in ['goal-objective.md','pasted-text-1.txt']:
 dst=O/'input_snapshot'/name
 if not dst.exists():shutil.copy2(attachments/name,dst)
grid=pd.read_csv(R/'data/collective_grid_2026-10-26/tables/collective-grid.csv')
ids=['C03169','C03173','C03177','C03181','C03185'];lock=grid.set_index('specification_id').loc[ids].reset_index();assert len(lock)==5;lock.to_csv(O/'tables/retained-five-liquidity-models.csv',index=False)
sources={'koning2018':R/'data/literature/Koning 2018 JIBS IFRS Changes.pdf','shipan2008':A/'07-environmental-disclosure-mechanisms/literature/Shipan_2008_AJPS_The Mechanisms of Policy Diffusion.pdf'}
refs={}
for key,path in sources.items():
 reader=PdfReader(path);pages=[{'pdf_page':i+1,'text':p.extract_text()} for i,p in enumerate(reader.pages)];(O/'literature'/(key+'-pages.json')).write_text(json.dumps(pages,ensure_ascii=False),encoding='utf8');refs[key]={'source':str(path),'pages':len(pages),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
(O/'literature/reference-manifest.json').write_text(json.dumps(refs,indent=2),encoding='utf8')
check={'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'latest_user_priority':'Retain the five previously presented liquidity models in the main paper, with identical numerical results.',
 'locked_model_ids':ids,'main_liquidity':'Public disclosures; country exposure; three pre years versus years 1-3 after adoption; GDP within-country weighting; the five distinct pooling targets retain their names and definitions.',
 'preserve':['User-pasted introduction and institutional logic where compatible with the broader disclosure sample','Current source files edited in place','Three TeX sources, four folders and one bibliography at project root','Existing results and underlying source documents'],
 'diffusion_tasks':['Read Koning and Shipan-Volden methods and distinguish learning, copying, competition and external pressure','Reconstruct lagged portfolio exposure from dimensionally filtered IMF positions','Use first-adoption risk sets with documented histories','Separate exposure from observed liquidity success, with full lower-order interaction terms','Investigate temporal copying and larger-market leaders; distinguish coordinated mandates','Retain every prespecified comparison and source-defined unavailable term without invented results'],
 'writing':'Connected findings; primary liquidity then diffusion; preserve association/treatment/mechanism distinction. State verified results directly. Put substantive identification assumptions in design, support diagnostics in appendix and limitations in conclusion.',
 'exhibits':'Numbered columns, panels, stars, standard errors on separate lines, X for included controls, Country FE convention accurately labelled, self-contained This table reports paragraphs, Online Appendix variable definitions.',
 'data_access':'Official legal sources are public/verifiable. Licensed Datastream and issuer data are not described as public. Pasted coefficients require underlying numerical reproduction before use.',
 'evidence_integrity':'Do not claim unavailable controls, outcomes, first-law coverage, observed issuer filing dates or causal mechanisms. Preserve contrary and imprecise results in their correct main/appendix locations. No significance-based stopping.'}
(O/'editorial-and-analysis-requirements.json').write_text(json.dumps(check,indent=2),encoding='utf8');shutil.copy2(__file__,O/'scripts/prepare.py')
print(json.dumps({'output':str(O),'retained_models':lock[['specification_id','estimate','p_value']].to_dict('records'),'references':refs}))
