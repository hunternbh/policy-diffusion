"""Revise the saved manuscript in place, preserving all fitted results."""
from pathlib import Path
import json,re,shutil,datetime
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion')
O=R/'data/diffusion_submission_2026-10-26'
backup=O/'input_snapshot'/'presentation-revision-2026-10-26'
backup.mkdir(exist_ok=True)
for name in ['paper.tex','appendix.tex','appendix_excess.tex','reference.bib']:
 if not (backup/name).exists():shutil.copy2(R/name,backup/name)
main=(R/'paper.tex').read_text(encoding='utf8')
intro=r'''\section{INTRODUCTION}

We examine stock liquidity around the introduction of public disclosure requirements and the forces associated with their international spread. We find that stock liquidity improves around implementation across five supported policy families. The two stacked estimates correspond to reductions of 20.0\% and 18.6\% in Bid-Ask Spread, our measure of the cost of trading immediately. Explicit equal-family and market-cap averages yield coefficients of approximately -0.199, while covariance-weighted pooling yields -0.238. All five models use the same supported sample.

The diffusion results connect implementation to the outcomes observed abroad. The interaction between foreign portfolio exposure and the share of prior adopters reporting emissions reductions is positive under both family weights: the coefficients are 2.140 and 2.351. Exposure has a more positive association with implementation when more prior adopters report these improvements. The interactions with foreign liquidity improvements are also positive, although less precisely estimated. We also test copying, trade competition, external financial dependence and cross-listing familiarity. The trade-competition association is negative when coordinated implementations are included; the copying, finance and cross-listing estimates provide no stable positive pattern of countries following prior adopters. These findings distinguish the information carried by foreign experience from exposure to foreign rules alone.

Extensive literature documents how disclosure affects information asymmetry, investor participation and the cost of trading \citep{diamond1991,welker1995,healy1999,leuz2000}. International reporting studies connect these benefits to enforcement and reporting incentives \citep{daske2008,christensen2013,christensen2016}. Research on mandatory environmental, social and governance disclosure extends this evidence to nonfinancial information \citep{krueger2024,christensen2021}. These studies provide a foundation for understanding individual reporting reforms. There is a gap in our understanding of how liquidity changes across disclosure requirements and how these requirements spread internationally.

If disclosure rules improve transparency, reduce information asymmetry and support efficient capital allocation, it would be reasonable to expect jurisdictions to adopt them promptly and uniformly. In practice, the global pattern looks different. Adoption occurs at different times and varies widely in scope. These differences raise an important question: what forces drive governments to adopt disclosure regulations? We study this question alongside the liquidity patterns that give governments and market participants a reason to consider the rules.

We use the setting of international public-disclosure requirements because it combines a common information channel with variation in the content, audience and timing of regulation. The corpus identifies ten public-disclosure families, including financial reporting, auditor reporting, ESG and climate reporting, public country reports and supply-chain disclosure. Five families support the same six-year liquidity window and documented later-adopter comparisons. This primary sample contains 30 country--family implementations, 14 family--cohorts and 46 countries including comparison countries. Confidential tax reporting forms a separate audience comparison.

We adjust for prior income, GDP growth and trade relative to GDP and continue to find liquidity improvements in the control-eligible stacked sample. The Bid-Ask Spread coefficients are -0.187 under equal family mass and -0.183 under market-cap family mass. We also distinguish a directly stacked slope from an explicit average of policy-family coefficients. This distinction makes clear whether a result describes a common regression slope, the typical supported family or larger sampled market exposures.

To account for alternative explanations, we examine other liquidity measures, the timing of the outcome window and the treatment of extreme observations. We keep the same companies within each comparison window and use countries with documented implementation after the window as controls. We compare untrimmed annual measures with 1\% and 2.5\% trimming and estimate event-time coefficients. For diffusion, we distinguish independent national choices from coordinated implementations and include family-specific international waves in within-country models. Following \citet{shipan2008} and \citet{koning2018}, the tests separate learning, copying, competition and external pressure.

This paper contributes to several strands of literature. First, it contributes to research on disclosure and capital markets by comparing different public reporting requirements within one empirical framework. The financial-reporting literature establishes the importance of incentives and enforcement, while nonfinancial reporting research examines information about environmental and social activities \citep{daske2008,christensen2013,krueger2024}. Our contribution is the common comparison across these requirements, using consistent market measures, company-selection rules and clearly defined pooling targets.

Second, the paper contributes to research on the international spread of accounting and financial policies \citep{simmons2004,simmons2006,koning2018}. When policy change is shaped by the prior choices of other jurisdictions, the process is commonly described as policy diffusion. We distinguish broad financial exposure from observed foreign outcomes, prominent adopters, economic competitors and external financial ties. This distinction brings the market consequences of reporting requirements into the study of their adoption, while preserving the separate meanings of an adoption association, a policy effect and a diffusion mechanism.

'''
main=main[:main.index(r'\section{INTRODUCTION}')]+intro+main[main.index(r'\section{INSTITUTIONAL SETTING AND PREDICTIONS}'):]
diffusion=r'''\section{INTERNATIONAL POLICY DIFFUSION}

The liquidity analysis identifies a market pattern that could make disclosure attractive. It leaves unanswered why countries implement requirements at different times. We study four diffusion mechanisms: learning from observed outcomes, copying prominent or related economies, competition with economic rivals, and external pressure. Cross-listing provides a complementary test of familiarity with foreign reporting. Each mechanism has its own measure and comparison; learning and copying are not the only channels tested.

We first distinguish contact with foreign rules from the information carried by that contact. Prior portfolio exposure measures the share of observed foreign assets invested in documented adopting jurisdictions. In the implementation-hazard models, the exposure coefficients are -0.422 under equal family weights and -0.676 under market-cap weights, with standard errors of 0.803 and 0.950 (Table~\ref{tab:learning}, columns (1)--(2)). The next tests ask whether outcomes observed among those adopters change the exposure--implementation relationship.

\subsection{Diffusion Mechanism 1 -- Learning from observed outcomes}

Learning means responding to evidence about how a policy works. Foreign adoption alone cannot distinguish this response from simply following another country. Following \citet{koning2018}, we therefore combine portfolio exposure with outcomes observed among countries that implemented the requirement earlier. We use three outcome signals: stock-liquidity improvements, emissions reductions and economic growth. The first two enter exposure-by-success interactions; the third compares growth among geographic peers that have and have not implemented the rule.

For the market-outcome signal, success means an improvement in stock liquidity, measured by a fall in Bid-Ask Spread for the same companies in adjacent years. We use only outcomes observed after the donor country's implementation and before the focal country's decision. Columns (3)--(4) of Table~\ref{tab:learning} include exposure, the observed success share and their interaction. The interaction coefficients are 1.835 and 2.616 under equal and market-cap family weights, with standard errors of 1.247 and 1.446. The positive coefficients mean that exposure has a more positive association with implementation when more prior adopters experience liquidity improvements.

For the environmental-outcome signal, success means a fall in reported greenhouse-gas emissions. Columns (5)--(6) yield interaction coefficients of 2.140 and 2.351, with standard errors of 0.830 and 0.787. Both are positive and conventionally significant. A country with greater exposure to prior adopters has a more positive exposure--implementation relationship when more of those adopters report emissions reductions. This provides evidence of a conditional association between observed foreign outcomes and national implementation.

The economic-growth test asks a parallel question: are countries more likely to implement a requirement when prior adopters among their geographic peers grow faster? The measure compares prior-year median growth among adopting and nonadopting peers with documented policy histories. In the within-country models, the coefficients are -0.045 and -0.157 (Table~\ref{tab:within}, column (1)). These estimates do not show the predicted positive relationship. The distinction matters because a visible policy-specific outcome and overall economic growth convey different information to a government considering a reporting rule.

We next consider whether foreign experience matters differently with domestic market conditions or emissions. Online Appendix Table A7 includes domestic capacity, both foreign-signal primitives and every lower-order interaction. Table A6 varies portfolio timing and the required coverage of policy histories. These comparisons make the content, timing and availability of the learning signal explicit. Figure~\ref{fig:learning-slope} shows how the portfolio-exposure slope varies with observed emissions reductions.

\subsection{Diffusion Mechanism 2 -- Copying larger or related economies}

Countries may follow a prominent adopter because its policy is visible or considered legitimate. This mechanism need not depend on favourable outcomes. We test copying with two measures: prior implementation by a fixed larger geographic peer and the fraction of language peers that have already implemented the requirement. The larger peer is chosen using GDP in 2000; its identity does not change as policies are adopted. We separate implementation in the preceding year from older implementation, following the timing logic in \citet{shipan2008}.

The independent-choice larger-peer sample contains 12 countries, below the stated 15-country support requirement. Online Appendix Table A10 reports this coverage and the all-documented comparison. In the latter, recent-peer coefficients are 0.118 and -0.742; older-peer coefficients are -0.917 and -1.905. The language-peer coefficients in the within-country models are 0.058 and 0.043 (Table~\ref{tab:within}, column (2)). Together, the estimates do not show a stable positive response to implementation by a larger or linguistically related country.

Official sources nevertheless show that international templates are available to national standard setters. The XRB describes New Zealand Climate Standards as based on TCFD, while IAASB and IFAC materials document international auditor-reporting standards and their dissemination (Table~\ref{tab:templates}). These cases identify practical routes through which reporting practices travel. They complement the adoption comparisons by showing the institutional infrastructure through which a country can obtain a reporting template.

\subsection{Diffusion Mechanism 3 -- Competition with economic rivals}

Copying concerns the prominence or proximity of an adopter. Competition instead concerns the economic consequences of falling behind a rival. We identify five countries with the most similar export-destination patterns in 2000 and measure prior adoption among those with documented histories. Fixing the network before the adoption period prevents the choice of competitors from responding to subsequent implementation.

The independent-choice sample has nine countries and does not meet the support requirement. With all documented implementations, the logit coefficients are -1.292 under equal weights and -1.834 under market-cap weights, with standard errors of 0.229 and 0.314. Both remain significant after the diffusion-matrix adjustment. These estimates associate greater competitor adoption with lower implementation likelihood in that sample. The corresponding within-country coefficients are near zero after absorbing country--family differences and family-specific international waves. This pattern makes the distinction between independent national decisions and coordinated legal requirements central to the interpretation of competition.

\subsection{Diffusion Mechanism 4 -- External pressure and financial dependence}

Domestic reporting choices may also be shaped by external institutions. Following \citet{koning2018}, we examine a country's reliance on external finance. The measure adds net official development assistance to the World Bank series for IMF credit and SDR allocations, scales the total by GDP, and uses the preceding year's value. It measures financial dependence; the data do not identify a lender's policy conditions.

The within-country coefficients are -0.002 under equal family weights and -0.067 under market-cap weights (Table~\ref{tab:within}, column (3)). The standard errors are 0.015 and 0.050. These estimates provide no positive association between greater measured financial dependence and implementation. We also distinguish independent national choices from coordinated legal obligations in the policy register. That distinction records an institutional source of external pressure directly, rather than assigning it from the financing proxy.

\subsection{Additional channel -- Cross-listing and familiarity with foreign reporting}

Cross-listing offers a separate route through which firms, auditors and regulators become familiar with foreign reporting practices. Such familiarity may lower the cost of a domestic requirement. It may also reduce the additional need for a local rule when firms already report abroad. We measure the preceding year's share of sampled firms that are cross-listed and estimate the same within-country model.

The coefficients are 0.0002 and 0.0022 under equal and market-cap family weights, with standard errors of 0.0170 and 0.0175 (Table~\ref{tab:within}, column (4)). The sample contains 870 risk-year observations in 25 countries and nine public-disclosure families. These estimates show little association between general cross-listing prevalence and national implementation. Because the measure does not identify each issuer's host-country reporting rule, it captures familiarity with foreign reporting generally. The result separates this broad exposure channel from the outcome-based learning tests.

'''
main=main[:main.index(r'\section{INTERNATIONAL POLICY DIFFUSION}')]+diffusion+main[main.index(r'\section{CONCLUSION}'):]
# Use liquidity as the economic outcome; retain the exact traded-cost proxy in technical descriptions.
replacements={
 'Quoted spreads are approximately 20.0\\% lower under equal family objective mass and 18.6\\% lower under market-cap objective mass in the three years after implementation relative to the pre-reform comparison.':'Stock liquidity improves around implementation: Bid-Ask Spread, our trading-cost proxy, is approximately 20.0\\% lower under equal family objective mass and 18.6\\% lower under market-cap objective mass in the three post-implementation years relative to the pre-reform comparison.',
 'Explicit family averages and covariance-weighted pooling also yield negative spread estimates.':'Explicit family averages and covariance-weighted pooling also indicate lower trading costs.',
 'We measure annual illiquidity using log quoted spread, log price impact and the fraction of observed daily returns equal to zero. Spread is the annual median relative bid--ask spread. Price impact is the annual median absolute return divided by dollar trading volume, adapting \\citet{amihud2002}.':'Following the liquidity framework in \\citet{krueger2024}, we use three proxies for stock liquidity: Bid-Ask Spread, Price Impact and Zero Return. Bid-Ask Spread is the annual median difference between the closing ask and bid prices, divided by their midpoint. Price Impact is the annual median absolute return divided by dollar trading volume, adapting \\citet{amihud2002}. Zero Return is the fraction of observed valid daily returns equal to zero.',
 'Positive spread and impact values are trimmed within year at the 1st and 99th percentiles before logging. We also report an equally weighted standardized index of the three measures. Lower values indicate greater liquidity.':'Positive Bid-Ask Spread and Price Impact values are trimmed within year at the 1st and 99th percentiles before logging. We also report an equally weighted standardized illiquidity index of the three proxies. Lower values indicate greater stock liquidity. Our index uses fixed standardization weights; it is not the factor-analysis measure in Krueger et al. The Zero Return denominator uses observed valid returns.',
 '\\subsection{The collective spread comparison}':'\\subsection{Stock liquidity around disclosure implementation}',
 'We regress country--stack--year log spread':'We regress country--stack--year log Bid-Ask Spread',
 'These values correspond to approximately 20.0\\% and 18.6\\% lower quoted spreads.':'These values indicate higher stock liquidity, with Bid-Ask Spread approximately 20.0\\% and 18.6\\% lower around implementation.',
 "Each supported family's spread coefficient is also negative in this common window. Figure~\\ref{fig:pooling} shows the pooled magnitudes and conditional intervals. The negative coefficients under all five pooling methods provide a consistent directional association between public disclosure and lower trading costs in the supported sample.":"Each supported family's Bid-Ask Spread coefficient is also negative in this common window. Figure~\\ref{fig:pooling}, Panel B, shows the implied reductions in trading costs and conditional intervals. All five pooling methods associate public disclosure with higher stock liquidity in the supported sample.",
 'the spread pattern':'the liquidity pattern',
 'The stacked coefficients remain negative':'The Bid-Ask Spread coefficients remain negative',
 'the negative spread pattern':'the liquidity improvement',
 'Spread measures the cost of immediately trading against quoted prices.':'Bid-Ask Spread measures the cost of immediately trading against quoted prices.',
 'the spread result':'the main liquidity result',
 'The negative spread estimates make timing and sample composition important next questions.':'The liquidity improvements make timing and sample composition important next questions.',
 'the spread pattern recur':'the liquidity pattern recur',
 'negative quoted-spread coefficients':'negative Bid-Ask Spread coefficients',
 'The two directly stacked estimates imply spreads approximately 20.0\\% and 18.6\\% lower around implementation':'The two directly stacked estimates imply higher stock liquidity, with Bid-Ask Spread approximately 20.0\\% and 18.6\\% lower around implementation',
 'Spread differences are present before implementation':'Differences in the trading-cost proxy are present before implementation'
}
for old,new in replacements.items():main=main.replace(old,new)
main=main.replace('The ten-family public corpus is reported separately from confidential tax reporting and broader institutional regulation.','The ten-family public corpus is reported separately from confidential tax reporting and broader institutional regulation. Figure~\\ref{fig:policy-coverage} shows all dated regulatory families in the register and the country coverage of the ten public-disclosure families. Countries are grouped by similar policy profiles, using no liquidity outcomes.')
start=main.index('\\singlespacing\n\\input{figures_tables/submission-main-tables.txt}')
mainfigures=r'''\singlespacing
\clearpage
\begin{figure}[p]
\centering
\includegraphics[width=\linewidth,height=.77\textheight,keepaspectratio]{figures_tables/submission-policy-country-overview.png}
\caption{Regulatory families and international policy coverage}\label{fig:policy-coverage}
{\footnotesize\raggedright This figure shows the policy register and country coverage. Panel A counts countries with documented implementations dated 2000--2025 across all 17 regulatory families, distinguishing ten public-disclosure families, confidential tax reporting and broader regulation. Panels B and C show the ten public-disclosure families in 56 countries; colour identifies the documented year. Countries are grouped by similarity in their recorded policy profiles using average-linkage clustering of Jaccard distances, without market outcomes. Red dots mark the 30 country--family implementations in the primary liquidity sample. Grey cells indicate no implementation dated 2000--2025 documented in this register, not verified nonadoption. Sources are the official laws, standards and implementation documents in the policy register.\par}
\end{figure}
\clearpage
\begin{figure}[p]
\centering
\includegraphics[width=\linewidth,height=.72\textheight,keepaspectratio]{figures_tables/submission-implementation-liquidity.png}
\caption{Public-disclosure implementation and stock liquidity}\label{fig:pooling}\label{fig:timing}
{\footnotesize\raggedright This figure combines the implementation chronology and the primary liquidity estimates. Panel A counts 198 documented country--family implementations dated 2000--2025 across ten public-disclosure families. Panel B reports trading-cost reductions, $100[1-\exp(\widehat\beta)]$, from the five models in Table 3, with transformed conditional 95\% intervals. Positive values indicate lower Bid-Ask Spread and therefore greater stock liquidity; they are not proportionate increases in liquidity itself. All five models use the same 1,002 country--stack--years, 46 countries and five supported families. GDP sets country weights; the five pooling rules differ in family aggregation. Shared-country scores preserve dependence across stacks, and GLS inference conditions on estimated covariance weights. Sources are Datastream and the official policy register.\par}
\end{figure}
\clearpage
\input{figures_tables/submission-main-tables.txt}
\clearpage
\end{document}
'''
main=main[:start]+mainfigures

def captions(s):
 if '\\usepackage{caption}' not in s:
  s=s.replace('\\usepackage[authoryear,round,longnamesfirst]{natbib}',r'''\usepackage{caption}
\captionsetup[figure]{justification=raggedright,singlelinecheck=false,font=small,labelfont=bf}
\usepackage[authoryear,round,longnamesfirst]{natbib}''')
 # Figure explanatory paragraphs are also explicitly left aligned.
 s=s.replace('{\\footnotesize This figure','{\\footnotesize\\raggedright This figure')
 return s
main=captions(main)
(R/'paper.tex').write_text(main,encoding='utf8')
app=captions((R/'appendix.tex').read_text(encoding='utf8'))
app=app.replace('\\input{figures_tables/submission-online-tables.txt}\n','')
app=app.replace('\\caption{Spread dynamics on the primary stacked sample}','\\caption{Stock-liquidity dynamics on the primary stacked sample}')
app=app.replace('Higher log spread indicates greater illiquidity.','Higher log Bid-Ask Spread indicates lower stock liquidity.')
app=app.replace('\\caption{Foreign emissions reductions and the portfolio-exposure slope}','\\caption{Foreign emissions reductions and the portfolio-exposure slope}\\label{fig:learning-slope}')
app=app.replace('\\end{document}','\\input{figures_tables/submission-online-tables.txt}\n\\clearpage\n\\end{document}')
(R/'appendix.tex').write_text(app,encoding='utf8')
extended=captions((R/'appendix_excess.tex').read_text(encoding='utf8'))
(R/'appendix_excess.tex').write_text(extended,encoding='utf8')
# The main source cannot reference an appendix-only label without external aux files.
main=main.replace('Figure~\\ref{fig:learning-slope}','Online Appendix Figure A2')
(R/'paper.tex').write_text(main,encoding='utf8')

# Keep the existing source generator synchronized with the files edited in place.
g=Path('work/diffusion-submission/write_paper.py');s=g.read_text(encoding='utf8')
preamble=main[:main.index('\\begin{document}')].replace('International Policy Diffusion}', 'International Policy DiffusionTITLE_SUFFIX}')
body=main[main.index('\\begin{document}'):]
appendix=app[app.index('\\renewcommand{\\thetable}'):]
excess=extended[extended.index('\\renewcommand{\\thetable}'):]
for var,content in [('preamble',preamble),('body',body),('appendix',appendix),('extended',excess)]:
 s,n=re.subn(r"(?ms)^"+var+r"=r'''(.*?)'''",lambda m:var+"=r'''"+content+"'''",s,count=1)
 assert n==1,var
g.write_text(s,encoding='utf8')
shutil.copy2(g,O/'scripts/write_paper.py')

# Presentation labels change; internal outcome names, estimation and results do not.
e=Path('work/diffusion-submission/exhibits.py');s=e.read_text(encoding='utf8')
for old,new in [
 ('Log spread','Log Bid-Ask Spread'),('log spread','log Bid-Ask Spread'),
 ('Public disclosure and quoted spreads: five pooling models','Public disclosure and stock liquidity: five pooling models'),
 ('Public disclosure and spreads with country controls','Stock liquidity with country controls'),
 ('Spread dynamics around public-disclosure implementation','Stock-liquidity dynamics around public-disclosure implementation'),
 ('Spread estimates across trimming, timing and windows','Stock-liquidity estimates across trimming, timing and windows'),
 ('primary pooled spread estimates','primary pooled liquidity estimates'),
 ('pooled spread specifications','pooled liquidity specifications'),
 ('Higher values mean more illiquidity.','Higher values mean less stock liquidity.')]:s=s.replace(old,new)
e.write_text(s,encoding='utf8')
f=Path('work/diffusion-submission/figures.py');s=f.read_text(encoding='utf8')
s=s.replace('Quoted spread difference (%)','Trading-cost difference (%; Bid-Ask Spread)').replace('Log spread relative to year −1','Log Bid-Ask Spread relative to year -1')
f.write_text(s,encoding='utf8')
note={'request':'Figures before tables; new policy-country overview; two-panel chronology/liquidity figure; liquidity terminology and explicit diffusion headings/findings.',
      'models_unchanged':['C03169','C03173','C03177','C03181','C03185'],
      'terminology':'Stock liquidity is the economic outcome. Bid-Ask Spread remains the named proxy. A 20% cost reduction is not described as a 20% liquidity increase.',
      'reference_read':'Krueger et al. local working paper, introduction and sections 3.3 and 4; preserve differences in index construction and Zero Return denominator.',
      'diffusion_channels':['Learning: liquidity, emissions and GDP-growth outcomes','Copying: fixed larger peer and language peers','Competition: export-pattern rivals','External pressure: financing dependence and coordinated obligations','Additional channel: cross-listing familiarity'],
      'introduction':'Two findings paragraphs precede the literature discussion; nine paragraphs in total.',
      'caption_format':'caption package: raggedright, singlelinecheck=false; explanatory paragraphs explicitly raggedright.',
      'figure_order':'Main and Online Appendix figures precede their tables.'}
(O/'audit/presentation-revision.json').write_text(json.dumps(note,indent=2),encoding='utf8')
shutil.copy2(__file__,O/'scripts'/Path(__file__).name)
print(json.dumps(note))
