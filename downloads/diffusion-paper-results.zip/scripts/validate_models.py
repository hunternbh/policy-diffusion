from pathlib import Path
import sys,json,hashlib
sys.path.insert(0,'work/empirical-deps')
import pandas as pd,numpy as np
from scipy.optimize import minimize
from scipy.special import expit
from scipy.stats import t
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from statsmodels.stats.multitest import multipletests
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'data/diffusion_submission_2026-10-26';F=pd.read_parquet(O/'data/diffusion-mechanism-panel.parquet').set_index('row_id');T=pd.read_csv(O/'tables/diffusion-coefficients.csv');M=pd.read_parquet(O/'audit/exact-model-memberships.parquet');D={d['fit_id']:d for d in json.loads((O/'audit/model-diagnostics.json').read_text())};sc={d['fit_id']:d['standardization'] for d in json.loads((O/'audit/model-standardizations.json').read_text())};checks=[]
def check(name,passed,detail=None):
 checks.append({'name':name,'passed':bool(passed),'detail':detail})
 if not passed:raise AssertionError((name,detail))
check('688_declared_fits',len(D)==688);check('16_theory_models',T.model.nunique()==16);check('all_focal_adjustments',np.allclose(T.loc[T.focal,'holm_all_focal_p'],multipletests(T.loc[T.focal,'p_value'].fillna(1),method='holm')[1]))
check('finite_adoption_risk_only',F.G.lt(9000).all() and (F.year<=F.G).all());check('no_future_positions',all((F[c+'_position_year'].dropna()<=F.loc[F[c+'_position_year'].notna(),'year']-1).all() for c in ['lag1','lag2','fixed2001']))
lock=pd.read_csv(O/'tables/retained-five-liquidity-models.csv');original=pd.read_csv(R/'data/collective_grid_2026-10-26/tables/collective-grid.csv').set_index('specification_id');check('five_liquidity_models_unchanged',all(np.isclose(r.estimate,original.loc[r.specification_id,'estimate'],atol=1e-15) for r in lock.itertuples()))
aliases={'P':'pip_exposure','S':'liquidity_success_share','Lexp':'liquidity_success_exposure','Lmag':'liquidity_magnitude_exposure','Ltop':'liquidity_threshold_exposure','H':'ghg_success_share','D':'domestic_liquidity','Q':'domestic_ghg','B':'nearest_larger_adoption','Bnew':'nearest_larger_recent','Bold':'nearest_larger_older','Cross':'l1_crosslisted_firms_share'}
def arrays(fit_id):
 meta=D[fit_id];a=M[M.fit_id.eq(fit_id)];x=F.loc[a.row_id].copy();w=a.weight.to_numpy();out=x.first_event.to_numpy(float);terms=meta['all_terms'];clock=meta['clock'];primitives=set('*'.join(terms).split('*'))
 for p in primitives:
  values=x[clock+'_'+aliases[p]] if p in ['P','S','Lexp','Lmag','Ltop','H'] else np.log(x['l1_ghg-emission']) if p=='Q' else x[aliases.get(p,p)];z=sc[fit_id][p];x['z_'+p]=(values-z['mean'])/z['sd']
 X=np.column_stack([np.prod(np.column_stack([x['z_'+p] for p in term.split('*')]),axis=1) for term in terms]);return meta,x,w,X,out
# Independent likelihood optimizer and full-dummy weighted least squares.
for fit_id in ['D0001','D0129','D0385','D0386','D0549','D0550','D0131','D0195','D0563','D0595']:
 meta,x,w,X,y=arrays(fit_id);saved=np.load(O/'audit'/(fit_id+'-fit.npz'));n=len(x);G=x.iso3.nunique();k=X.shape[1]
 if meta['estimator']=='logit_family_year':
  X=np.column_stack([np.ones(n),X,pd.get_dummies(x.family,drop_first=True,dtype=float),pd.get_dummies(x.year,drop_first=True,dtype=float)]);initial=saved['beta']+np.linspace(-.002,.002,X.shape[1]);fun=lambda b:float(np.sum(w*(np.logaddexp(0,X@b)-y*(X@b))));jac=lambda b:X.T@(w*(expit(X@b)-y));hess=lambda b:X.T@((w*expit(X@b)*(1-expit(X@b)))[:,None]*X);opt=minimize(fun,initial,jac=jac,hess=hess,method='trust-exact',options={'gtol':1e-9,'maxiter':400});b=opt.x;pred=expit(X@b);bread=np.linalg.inv(hess(b));res=y-pred
  check('independent_logit_beta_'+fit_id,np.allclose(b,saved['beta'],atol=2e-6),float(abs(b-saved['beta']).max()))
 else:
  g=pd.factorize(x.iso3+'_'+x.family)[0];h=pd.factorize(x.family+'_'+x.year.astype(str))[0];ng=g.max()+1;nh=h.max()+1;graph=coo_matrix((np.ones(n),(g,ng+h)),shape=(ng+nh,ng+nh));_,labels=connected_components(graph+graph.T,directed=False);remove={next(i for i in range(nh) if labels[ng+i]==component) for component in set(labels)};keep=[j for j in range(nh) if j not in remove];X=np.column_stack([X,np.eye(ng)[g],np.eye(nh)[h][:,keep]]);sw=np.sqrt(w);b=np.linalg.lstsq(X*sw[:,None],y*sw,rcond=None)[0];res=y-X@b;bread=np.linalg.inv(X.T@(w[:,None]*X));pred=None
  check('independent_dense_FE_beta_'+fit_id,np.allclose(b[:k],saved['beta'],atol=2e-8),float(abs(b[:k]-saved['beta']).max()))
 score=X*(w*res)[:,None];cc=pd.factorize(x.iso3)[0];S=np.column_stack([np.bincount(cc,weights=score[:,j],minlength=G) for j in range(X.shape[1])]);cov=bread@(S.T@S)@bread*G/(G-1)*(n-1)/(n-X.shape[1]);subset=slice(None) if pred is not None else slice(0,k);computed=cov[subset,subset]
 check('independent_country_covariance_'+fit_id,np.allclose(computed,saved['cov'],atol=2e-6,rtol=2e-6),float(abs(computed-saved['cov']).max()))
for fit_id,rows in T[T.status.eq('estimated')].groupby('fit_id'):
 s=np.load(O/'audit'/(fit_id+'-fit.npz'));names=list(s['names']);G=D[fit_id]['countries'];m=M[M.fit_id.eq(fit_id)];check('sample_membership_'+fit_id,len(m)==D[fit_id]['rows'])
 for r in rows.itertuples():
  j=names.index('z_'+r.term);se=np.sqrt(s['cov'][j,j]);p=2*t.sf(abs(s['beta'][j]/se),G-1);check('coefficient_inference_'+fit_id+'_'+r.term,np.isclose(r.estimate,s['beta'][j],atol=1e-12) and np.isclose(r.country_se,se,atol=1e-12) and np.isclose(r.p_value,p,atol=1e-10))
 if '*'.join(D[fit_id]['focal_terms']) in ['P*S*D','P*H*Q']:
  required={'P','S','D','P*S','P*D','S*D','P*S*D'} if 'P*S*D' in D[fit_id]['focal_terms'] else {'P','H','Q','P*H','P*Q','H*Q','P*H*Q'};check('all_lower_order_interactions_'+fit_id,required.issubset(set(D[fit_id]['all_terms'])))
result={'passed':True,'checks':len(checks),'independent_refits':10,'all_model_inference_reconstructed':True,'source_coverage_and_timing_checked':True,'checks_detail':checks};(O/'audit/validation-results.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps({k:v for k,v in result.items() if k!='checks_detail'}))
