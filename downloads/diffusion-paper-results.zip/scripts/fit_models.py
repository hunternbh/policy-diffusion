"""Predetermined diffusion designs, complete failures, country covariance and paired weights."""
import os
for k in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys,json,itertools,warnings,hashlib,time,shutil
sys.path.insert(0,'work/empirical-deps')
import pandas as pd,numpy as np,statsmodels.api as sm
from scipy.special import expit
from scipy.stats import t
from statsmodels.stats.multitest import multipletests
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'data/diffusion_submission_2026-10-26';F=pd.read_parquet(O/'data/diffusion-mechanism-panel.parquet');P=json.loads((R/'data/current/analysis-plan.json').read_text());C=['ln_gdp_pc','gdp_growth','trade_gdp'];cap=pd.read_csv(O/'tables/diffusion-family-weight-masses.csv').set_index('family').pre_adoption_market_cap_mass.to_dict();out=[];fits=[];members=[];scalings=[];ame=[];sid=0;start=time.time()
specs=[('portfolio_exposure',['P'],['P']),('liquidity_success_exposure',['P','Lexp'],['Lexp']),('liquidity_learning_double',['P','S','P*S'],['P*S']),('liquidity_learning_triple',['P','S','D','P*S','P*D','S*D','P*S*D'],['P*S*D']),('liquidity_learning_magnitude',['P','Lmag'],['Lmag']),('liquidity_learning_threshold',['P','Ltop'],['Ltop']),('ghg_learning_double',['P','H','P*H'],['P*H']),('ghg_learning_triple',['P','H','Q','P*H','P*Q','H*Q','P*H*Q'],['P*H*Q']),('nearest_larger_copying',['B'],['B']),('copying_recent_vs_old',['Bnew','Bold'],['Bnew','Bold']),('trade_competition',['trade_fixed2000'],['trade_fixed2000']),('language_copying',['language'],['language']),('external_finance',['financial_dependence'],['financial_dependence']),('crosslisting_substitution',['Cross'],['Cross']),('joint_available_channels',['P','Lexp','B','trade_fixed2000','language','financial_dependence'],['P','Lexp','B','trade_fixed2000','language','financial_dependence']),('gdp_learning_reference',['gdp_learning_known_universe'],['gdp_learning_known_universe'])]
clock_variants=[('lag1',.5,'main'),('lag2',.5,'positions_lag2'),('fixed2001',.5,'fixed_positions_2001'),('lag1',.8,'portfolio_history_80pct')]
aliases={'P':'pip_exposure','S':'liquidity_success_share','Lexp':'liquidity_success_exposure','Lmag':'liquidity_magnitude_exposure','Ltop':'liquidity_threshold_exposure','H':'ghg_success_share','D':'domestic_liquidity','Q':'domestic_ghg','B':'nearest_larger_adoption','Bnew':'nearest_larger_recent','Bold':'nearest_larger_older','Cross':'l1_crosslisted_firms_share'}
def demean(Z,w,g):
 total=np.bincount(g,weights=w);means=np.column_stack([np.bincount(g,weights=w*Z[:,j])/total for j in range(Z.shape[1])]);return Z-means[g]
def absorbed(g,h):
 ng=g.max()+1;nh=h.max()+1;parent=list(range(ng+nh))
 def root(i):
  while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
  return i
 for i,j in zip(g,h):parent[root(int(i))]=root(int(j)+ng)
 components=len({root(i) for i in range(ng+nh)});return int(ng+nh-components)
def fit_one(d,terms,scheme,estimator):
 n=len(d);G=d.iso3.nunique();mass={f:1. if scheme=='equal_family' else cap.get(f,0) for f in d.family.unique()};s=sum(mass.values());counts=d.family.value_counts();w=np.array([n*mass[f]/s/counts[f] for f in d.family]);X=d[terms].to_numpy(float);y=d.first_event.to_numpy(float);kfe=0
 if estimator=='logit_family_year':
  X=np.column_stack([np.ones(n),X,pd.get_dummies(d.family,drop_first=True,dtype=float),pd.get_dummies(d.year,drop_first=True,dtype=float)]);names=['intercept']+terms+['family_FE_'+str(v) for v in sorted(d.family.unique())[1:]]+['year_FE_'+str(v) for v in sorted(d.year.unique())[1:]]
 else:
  names=terms;g=pd.factorize(d.iso3+'_'+d.family)[0];h=pd.factorize(d.family+'_'+d.year.astype(str))[0];Z=np.column_stack([y,X])
  for it in range(10000):
   old=Z.copy();Z=demean(demean(Z,w,g),w,h)
   if np.max(abs(Z-old))<1e-10:break
  y=Z[:,0];X=Z[:,1:];kfe=absorbed(g,h)
 k=X.shape[1];sv=np.linalg.svd(X,compute_uv=False);rank=int(np.sum(sv>max(1e-9,sv.max()*1e-8)))
 if rank<k or n<=k+kfe+3 or np.std(y)<1e-9:return None,{'status':'rank_or_absorbed_outcome','rank':rank,'columns':k,'absorbed_df':kfe}
 warns=[]
 if estimator=='logit_family_year':
  with warnings.catch_warnings(record=True) as warning:
   warnings.simplefilter('always');fit=sm.GLM(y,X,family=sm.families.Binomial(),freq_weights=w).fit(maxiter=300,tol=1e-10)
  b=np.asarray(fit.params);pred=expit(X@b);bread=np.linalg.inv(X.T@((w*pred*(1-pred))[:,None]*X));score=X*(w*(y-pred))[:,None];warns=[str(v.message) for v in warning];stable=fit.converged and np.isfinite(b).all() and abs(b).max()<30 and abs(score.sum(axis=0)).max()<1e-5
  if not stable:return None,{'status':'unstable_logit','warnings':warns,'max_beta':float(abs(b).max())}
 else:
  bread=np.linalg.inv(X.T@(w[:,None]*X));b=bread@(X.T@(w*y));res=y-X@b;score=X*(w*res)[:,None];pred=None
 cc=pd.factorize(d.iso3)[0];S=np.column_stack([np.bincount(cc,weights=score[:,j],minlength=G) for j in range(k)]);IF=S@bread;cov=IF.T@IF*G/(G-1)*(n-1)/(n-k-kfe);se=np.sqrt(np.diag(cov))
 if not np.isfinite(se).all() or se.min()<1e-12:return None,{'status':'unstable_cluster_variance'}
 return {'beta':b,'se':se,'cov':cov,'names':names,'weights':w,'pred':pred,'X':X,'country_influence':IF,'countries':sorted(d.iso3.unique())},{'status':'estimated','rank':rank,'columns':k,'absorbed_df':kfe,'max_score':float(abs(score.sum(axis=0)).max()),'warnings':warns}
for label,rawterms,focal in specs:
 primitives=sorted(set('*'.join(rawterms).split('*')));portfolio='P' in primitives
 for clock,coverage,variant in (clock_variants if portfolio else clock_variants[:1]):
  for scope,choice,estimator in itertools.product(['public_disclosure','public_and_confidential'],['independent_choices','all_documented'],['logit_family_year','lpm_country_family_and_family_year']):
   wanted=P['headline_families'] if scope=='public_disclosure' else P['all_disclosure_families'];a=F[F.family.isin(wanted)].copy()
   if choice=='independent_choices':a=a[~a.known_collective_focal]
   for term in primitives:
    if term in ['P','S','Lexp','Lmag','Ltop','H']:a[term]=a[clock+'_'+aliases[term]]
    elif term=='Q':a[term]=np.log(a['l1_ghg-emission'].where(a['l1_ghg-emission'].gt(0)))
    else:a[term]=a[aliases.get(term,term)]
   if portfolio:a=a[a[clock+'_known_policy_portfolio_share'].ge(coverage)]
   a=a.dropna(subset=primitives+C+['first_event']).copy();original_n=len(a);dropped=[]
   if estimator=='logit_family_year':
    for _ in range(20):
     before=len(a)
     for group in ['family','year']:
      counts=a.groupby(group).first_event.nunique();remove=counts[counts<2].index;dropped.extend((group,str(v)) for v in remove);a=a[~a[group].isin(remove)]
     if len(a)==before:break
   # The same standardization/sample is used for the paired equal/cap fits.
   valid=True;sc={}
   for term in list(dict.fromkeys(primitives+C)):
    values=a[term];unique=set(values.unique());binary=unique.issubset({0.,1.});mean=0. if binary else values.mean();sd=1. if binary else values.std(ddof=0)
    if not np.isfinite(sd) or sd<1e-10:valid=False;sd=np.nan
    a['z_'+term]=(values-mean)/sd;sc[term]={'mean':float(mean),'sd':float(sd),'binary_unscaled':binary}
   for term in rawterms:
    a['z_'+term]=np.prod(np.column_stack([a['z_'+p] for p in term.split('*')]),axis=1)
   terms=['z_'+v for v in list(dict.fromkeys(rawterms+C))];n=len(a);G=a.iso3.nunique();events=int(a.first_event.sum());support=valid and n>=50 and G>=15 and events>=10 and n-events>=10
   for scheme in ['equal_family','market_cap_family']:
    sid+=1;fit_id=f'D{sid:04}';base={'fit_id':fit_id,'model':label,'variant':variant,'clock':clock,'coverage_minimum':coverage,'scope':scope,'choices':choice,'estimator':estimator,'family_weight':scheme,'rows_before_FE_pruning':original_n,'rows':n,'countries':G,'families':a.family.nunique(),'events':events,'status':'insufficient_sample_support','sample_sha256':hashlib.sha256(','.join(str(v) for v in sorted(a.row_id)).encode()).hexdigest()}
    fitted=None;diag={'status':base['status']}
    if support:
     try:fitted,diag=fit_one(a,terms,scheme,estimator)
     except Exception as e:diag={'status':'estimation_failed','error':str(e)}
    base['status']=diag['status'];fits.append({**base,**diag,'focal_terms':focal,'all_terms':rawterms+C,'dropped_FE_groups':dropped});scalings.append({'fit_id':fit_id,'standardization':sc})
    if fitted is None:
     out.extend({**base,'term':v,'focal':True,'p_value':1.} for v in focal);continue
    crit=t.ppf(.975,G-1)
    for term in list(dict.fromkeys(rawterms+C)):
     j=fitted['names'].index('z_'+term);b=float(fitted['beta'][j]);se=float(fitted['se'][j]);pv=float(2*t.sf(abs(b/se),G-1));out.append({**base,'term':term,'focal':term in focal,'estimate':b,'country_se':se,'p_value':pv,'ci_low':b-crit*se,'ci_high':b+crit*se,'coefficient_unit':'log_odds' if estimator=='logit_family_year' else 'probability','odds_ratio':float(np.exp(b)) if estimator=='logit_family_year' else np.nan})
    members.extend({'fit_id':fit_id,'row_id':int(i),'weight':float(w)} for i,w in zip(a.row_id,fitted['weights']))
    # Model-wide covariance is saved, including every lower-order interaction term.
    np.savez_compressed(O/'audit'/(fit_id+'-fit.npz'),beta=fitted['beta'],cov=fitted['cov'],names=np.array(fitted['names']),country_influence=fitted['country_influence'],countries=np.array(fitted['countries']))
    if estimator=='logit_family_year':
     for term in rawterms:
      if '*' in term:continue
      j=fitted['names'].index('z_'+term);ame.append({**base,'term':term,'average_marginal_derivative':float(np.mean(fitted['pred']*(1-fitted['pred']))*fitted['beta'][j]),'unit':'Probability derivative per standardized primitive, holding explicit interaction columns fixed; not total interaction marginal effect.'})
  print(json.dumps({'model':label,'variant':variant,'fits_attempted':sid,'seconds':round(time.time()-start)}),flush=True)
 T=pd.DataFrame(out);T.to_csv(O/'tables/diffusion-coefficients-progress.csv',index=False)
T=pd.DataFrame(out);primary=T.focal.fillna(False);T['holm_all_focal_p']=np.nan;T.loc[primary,'holm_all_focal_p']=multipletests(T.loc[primary,'p_value'].fillna(1),method='holm')[1];T.to_csv(O/'tables/diffusion-coefficients.csv',index=False);pd.DataFrame(members).to_parquet(O/'audit/exact-model-memberships.parquet',index=False);pd.DataFrame(ame).to_csv(O/'tables/logit-conditional-derivatives.csv',index=False);(O/'audit/model-diagnostics.json').write_text(json.dumps(fits,indent=2),encoding='utf8');(O/'audit/model-standardizations.json').write_text(json.dumps(scalings,indent=2),encoding='utf8');shutil.copy2(__file__,O/'scripts/fit_models.py');summary={'models_attempted':sid,'coefficient_rows':len(T),'focal_attempts':int(primary.sum()),'estimated_models':sum(v['status']=='estimated' for v in fits),'statuses':pd.Series([v['status'] for v in fits]).value_counts().to_dict(),'focal_Holm_below_05':int(T.holm_all_focal_p.lt(.05).sum()),'seconds':time.time()-start};(O/'audit/model-run-summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary))
