"""Policy coverage and two-panel liquidity figure; no model or sample changes."""
from pathlib import Path
import sys, json, shutil
sys.path.insert(0, 'work/empirical-deps')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import colors
from matplotlib.patches import Patch
from scipy.cluster.hierarchy import linkage, leaves_list
from scipy.spatial.distance import pdist

R = Path(r'C:\Users\hia_n\Desktop\policy-diffusion')
O = R/'data/diffusion_submission_2026-10-26'
E = R/'figures_tables'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,
                     'axes.spines.top':False,'axes.spines.right':False,
                     'figure.facecolor':'white','savefig.facecolor':'white'})
cal = pd.read_csv(R/'data/current/reviewed-policy-calendar.csv')
plan = json.loads((R/'data/current/analysis-plan.json').read_text())
public = list(plan['headline_families'])
dated = cal[cal.reviewed_G.between(2000,2025)].copy()
assert not dated.duplicated(['iso3','regulation_family']).any()
c = dated[dated.regulation_family.isin(public)].copy()
assert len(c)==198 and c.iso3.nunique()==56
names = {
 'AUDIT_REPORTING':'Auditor reporting', 'CBCR_BANK_PUBLIC':'Public bank country reports',
 'CBCR_PUBLIC':'Public multinational country reports', 'CLIMATE_DISCLOSURE':'Climate reporting',
 'ESG_MANDATORY_REVIEWED':'Mandatory ESG reporting', 'EXTRACTIVE_PAYMENTS':'Payments to governments',
 'IFRS':'IFRS financial reporting', 'SUPPLY_CHAIN':'Supply-chain reporting',
 'SUSTAINABILITY_FINANCIAL':'Sustainability financial reporting', 'XBRL':'Electronic financial reporting',
 'CBCR_CONFIDENTIAL':'Confidential tax country reports', 'AUDIT_OVERSIGHT':'Audit oversight',
 'BENEFICIAL_OWNERSHIP':'Beneficial ownership', 'CLIMATE_SECTORAL':'Sectoral climate regulation',
 'DIGITAL_ASSET':'Digital-asset regulation', 'GOVERNANCE':'Governance regulation',
 'SUSTAINABILITY_INFORMED':'Sustainability-informed regulation'}
counts = dated.groupby('regulation_family').iso3.nunique()
family_order = sorted(public,key=lambda f:(-counts[f],names[f]))
other = sorted(set(counts.index)-set(public)-{'CBCR_CONFIDENTIAL'},key=lambda f:(-counts[f],names[f]))
all_order=family_order+['CBCR_CONFIDENTIAL']+other
matrix = c.pivot(index='iso3',columns='regulation_family',values='reviewed_G').reindex(columns=family_order)
order = leaves_list(linkage(pdist(matrix.notna().astype(int).values,metric='jaccard'),
                           method='average',optimal_ordering=True))
country_order = list(matrix.index[order])
sample = pd.read_parquet(O/'data/primary-liquidity-country-stack-year.parquet')
primary = set(map(tuple,sample[sample.treated.eq(1)][['iso3','family']].drop_duplicates().values))
assert len(primary)==30
fig = plt.figure(figsize=(7.3,8.4))
gs = fig.add_gridspec(3,1,height_ratios=[2.8,1.65,1.65],hspace=.72,
                      left=.38,right=.96,top=.96,bottom=.10)
ax=fig.add_subplot(gs[0]); y=np.arange(len(all_order))
palette=['#1b5966' if f in public else '#b18b4e' if f=='CBCR_CONFIDENTIAL' else '#8a9397' for f in all_order]
ax.barh(y,[counts[f] for f in all_order],color=palette,height=.69)
ax.set_yticks(y,[names[f] for f in all_order],fontsize=9.5)
ax.invert_yaxis();ax.set_xlim(0,max(counts)*1.13)
for i,f in enumerate(all_order):ax.text(counts[f]+1.4,i,str(counts[f]),va='center',fontsize=8.5)
ax.set_title('A. Policy register: countries by regulatory family',loc='left',fontsize=11,pad=10)
ax.set_xlabel('Countries with a documented implementation dated 2000-2025',fontsize=9)
ax.grid(axis='x',alpha=.12);ax.set_axisbelow(True)
ax.legend(handles=[Patch(color='#1b5966',label='Public disclosure'),Patch(color='#b18b4e',label='Confidential reporting'),Patch(color='#8a9397',label='Broader regulation')],
          loc='lower left',bbox_to_anchor=(-.48,-.34),ncol=3,frameon=False,fontsize=8.5)
cmap=plt.get_cmap('YlGnBu').copy();cmap.set_bad('#eeeeeb');norm=colors.Normalize(2000,2025)
for i,group in enumerate([country_order[:28],country_order[28:]]):
 ax=fig.add_subplot(gs[i+1]);a=matrix.reindex(group).T
 im=ax.imshow(np.ma.masked_invalid(a.values),cmap=cmap,norm=norm,aspect='auto',interpolation='none')
 ax.set_yticks(range(len(family_order)),[names[f] for f in family_order],fontsize=9.3)
 ax.set_xticks(range(len(group)),group,rotation=90,fontsize=8.8)
 ax.set_xticks(np.arange(-.5,len(group),1),minor=True);ax.set_yticks(np.arange(-.5,len(family_order),1),minor=True)
 ax.grid(which='minor',color='white',linewidth=.8);ax.tick_params(which='both',length=0)
 for x,iso in enumerate(group):
  for yy,f in enumerate(family_order):
   if (iso,f) in primary:ax.plot(x,yy,'o',color='#c03232',markersize=2.5)
 ax.set_title(('B' if i==0 else 'C')+'. Public disclosure: country profiles',loc='left',fontsize=10,pad=9)
 for sp in ax.spines.values():sp.set_visible(False)
cax=fig.add_axes([.38,.048,.32,.012]);cb=fig.colorbar(im,cax=cax,orientation='horizontal',ticks=[2000,2005,2010,2015,2020,2025]);cb.ax.tick_params(labelsize=8);cb.set_label('Documented implementation year',fontsize=8,labelpad=1)
fig.text(.73,.053,'Red dot: primary liquidity case',fontsize=8,ha='left')
fig.canvas.draw()
renderer=fig.canvas.get_renderer();fw,fh=fig.canvas.get_width_height()
bad=[]
for obj in fig.findobj(matplotlib.text.Text):
 if not obj.get_visible() or not obj.get_text():continue
 box=obj.get_window_extent(renderer)
 if box.x0<-.5 or box.x1>fw+.5 or box.y0<-.5 or box.y1>fh+.5:bad.append(obj.get_text())
assert not bad,('Clipped figure labels',bad)
fig.savefig(E/'submission-policy-country-overview.png',dpi=300)
plt.close(fig)

lock=pd.read_csv(O/'tables/retained-five-liquidity-models.csv')
labels=['Stacked: equal family mass','Stacked: market-cap family mass',
        'Explicit equal-family average','Explicit market-cap average','GLS common effect']
fig,axes=plt.subplots(2,1,figsize=(8.5,7.1),gridspec_kw={'height_ratios':[1,1.2]})
counts_year=c.groupby('reviewed_G').size();ax=axes[0]
ax.bar(counts_year.index,counts_year.values,color='#1b5966',width=.8)
ax.set_title('A. International implementation of public disclosure requirements',loc='left',fontsize=11,pad=11)
ax.set_xlabel('Documented implementation year');ax.set_ylabel('Country-family implementations')
ax.set_xticks([2000,2005,2010,2015,2020,2025]);ax.grid(axis='y',alpha=.12);ax.set_axisbelow(True)
ax=axes[1];b=100*(1-np.exp(lock.estimate));lo=100*(1-np.exp(lock.ci_high));hi=100*(1-np.exp(lock.ci_low));y=np.arange(5)
ax.errorbar(b,y,xerr=[b-lo,hi-b],fmt='o',color='#1b5966',capsize=4,markersize=5)
ax.set_yticks(y,labels,fontsize=9);ax.invert_yaxis();ax.axvline(0,color='#87949a',linewidth=.9)
ax.set_title('B. Stock liquidity around disclosure implementation',loc='left',fontsize=11,pad=11)
ax.set_xlabel('Reduction in trading costs (%; Bid-Ask Spread)')
ax.grid(axis='x',alpha=.15);fig.tight_layout(h_pad=2.5)
fig.savefig(E/'submission-implementation-liquidity.png',dpi=300);plt.close(fig)

# Exact, public aggregate data underlying both figures.
pd.DataFrame([{'family':f,'label':names[f],'countries':int(counts[f]),'audience':
              'public_disclosure' if f in public else 'confidential' if f=='CBCR_CONFIDENTIAL' else 'broader_regulation'}
              for f in all_order]).to_csv(O/'tables/figure-policy-family-coverage.csv',index=False)
out=c[['iso3','regulation_family','reviewed_G']].copy()
out['primary_liquidity_case']=[(i,f) in primary for i,f in out[['iso3','regulation_family']].values]
out['country_cluster_order']=out.iso3.map({v:i+1 for i,v in enumerate(country_order)})
out.to_csv(O/'tables/figure-public-policy-country-coverage.csv',index=False)
pd.DataFrame({'year':counts_year.index,'country_family_implementations':counts_year.values}).to_csv(O/'tables/figure-public-implementation-timeline.csv',index=False)
meta={'register_implementations':len(dated),'register_countries':int(dated.iso3.nunique()),
      'register_families':len(all_order),'public_implementations':len(c),'public_countries':56,
      'public_families':10,'primary_liquidity_implementations':30,
      'country_order':'Average-linkage clustering of Jaccard distance between binary public-policy coverage profiles; optimal leaf ordering. Uses no market outcomes.',
      'empty_cell':'No implementation dated 2000-2025 documented in this register; does not establish nonadoption.',
      'liquidity_plot':'100*(1-exp(beta)); lower bound uses beta upper interval and conversely. Positive values indicate lower trading costs, not a proportionate increase in liquidity.'}
(O/'audit/revised-figure-definitions.json').write_text(json.dumps(meta,indent=2),encoding='utf8')
shutil.copy2(__file__,O/'scripts'/Path(__file__).name)
print(json.dumps(meta))
