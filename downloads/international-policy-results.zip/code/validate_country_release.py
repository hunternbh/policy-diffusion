from pathlib import Path
import sys,json,re,hashlib,shutil,zipfile,datetime
from urllib.parse import urlsplit,unquote
sys.path.insert(0,'work/empirical-deps')
import numpy as np,pandas as pd
from lxml import etree
from pypdf import PdfReader
from scipy.optimize import minimize
from scipy.special import expit
from statsmodels.stats.multitest import multipletests
R=Path(__import__('os').environ['POLICY_DIFFUSION_ROOT']);O=R/'25-country-level-main-paper/2026-10-19';P=R/'24-global-issuer-eligibility-audit/2026-10-19';S=R/'10-public-report';H=Path(__file__).parent;checks=[]
load=lambda p:json.loads(p.read_text(encoding='utf8'))
def ck(label,value):
 assert bool(value),label
 checks.append({'check':label,'passed':True})
Q=pd.read_csv(O/'tables/issuer-exposure-principal-estimates.csv');prior=pd.read_csv(P/'tables/issuer-exposure-principal-estimates.csv');keys=['target','configuration','within_weight','across_weight','outcome'];z=Q.merge(prior,on=keys,suffixes=('_country','_prior'),validate='one_to_one')
ck('country_estimator_reproduces_equivalent_prior_GDP_aggregation',len(z)==12 and np.allclose(z.estimate_country,z.estimate_prior,rtol=0,atol=1e-12))
ck('both_liquidity_weights_all_three_outcomes_two_windows',len(Q)==12 and Q.across_weight.nunique()==2 and Q.outcome.nunique()==3 and Q.target.nunique()==2)
cells=pd.read_csv(O/'tables/country-cohort-mean-changes.csv');gt=pd.read_csv(O/'tables/issuer-exposure-group-time-cells.csv');f=pd.read_csv(O/'tables/issuer-exposure-family-did.csv');w=pd.read_csv(O/'tables/issuer-exposure-family-weights.csv')
cellkeys=['target','configuration','family','within_weight','cohort','event_time','outcome']
reconstructed=[]
for key,c in cells.groupby(cellkeys):
 arm={arm:np.average(a.country_mean_change,weights=a.country_weight_mass) for arm,a in c.groupby('arm')}
 reconstructed.append(dict(zip(cellkeys,key),country_estimate=arm['treated']-arm['comparison']))
cc=pd.DataFrame(reconstructed).merge(gt,on=cellkeys,validate='one_to_one')
ck('all_group_time_estimates_reconstructed_from_country_cells',len(cc)==len(gt) and np.allclose(cc.country_estimate,cc.estimate,rtol=0,atol=1e-12))
for (target,config,within,across,out),a in w.groupby(['target','configuration','within_weight','across_weight','outcome']):
 ck('family_weights_'+str((target,config,within,across,out)),abs(a.family_weight.sum()-1)<1e-12)
 if across=='equal_family':assert np.allclose(a.family_weight,1/len(a))
 else:assert np.allclose(a.family_weight,a.baseline_sampled_issuer_cap_mass/a.baseline_sampled_issuer_cap_mass.sum())
 panel=pd.read_csv(O/'tables/issuer-exposure-pooled-did.csv');r=panel[panel.target.eq(target)&panel.configuration.eq(config)&panel.within_weight.eq(within)&panel.across_weight.eq(across)&panel.outcome.eq(out)].iloc[0]
 assert abs(np.dot(a.family_weight,a.family_estimate)-r.estimate)<1e-12
country=pd.read_parquet(O/'data/country-year-liquidity.parquet');agg=load(O/'audit/country-aggregation-verification.json')
ck('global_country_panel',len(country)==2050 and country.iso3.nunique()==90 and country.year.min()==2000 and country.year.max()==2025 and not country.duplicated(['iso3','year']).any())
ck('independent_raw_company_to_country_checks',agg['country_reexpression_checks']==558 and agg['maximum_absolute_difference_from_existing_main_cohort_estimates']<1e-12)
ck('fixed_support_no_relaxation',cells.sample_companies.ge(30).all())
F=pd.read_parquet(O/'data/lagged-mechanism-panel.parquet');F['row_id']=np.arange(len(F));D=pd.read_csv(O/'tables/country-diffusion-weighted-models.csv');primary=D[D.specification.eq('primary')];weights=pd.read_csv(O/'tables/country-diffusion-family-weights.csv');members=pd.read_parquet(O/'audit/weighted-diffusion-row-memberships-local.parquet');diagnostics=load(O/'audit/weighted-diffusion-diagnostics.json')
ck('global_diffusion_focal_country_universe',F.iso3.nunique()==90 and set(F.iso3)<=set(country.iso3))
ck('all_signals_precede_decision',F.maximum_information_year.lt(F.year).all())
ck('no_future_filled_trade_network',F.loc[F.year.lt(2014),'trade_fixed2013'].isna().all() and F.loc[F.year.gt(2015),'trade_annual'].isna().all())
ck('collective_waves_included_in_main_diffusion',F.loc[F.family.ne('PUBLISHED_ESG_BENCHMARK'),'known_collective_focal'].any())
ck('no_duplicate_country_family_year',not F.duplicated(['iso3','family','year']).any())
ck('eight_primary_diffusion_coefficients_preserved',len(primary)==8 and primary.term.nunique()==4)
for term,pair in primary.groupby('term'):
 ck('matched_diffusion_samples_'+term,pair.sample_sha256.nunique()==1 and pair.rows.nunique()==1 and pair.countries.nunique()==1 and pair.families.nunique()==1)
status=D[D.specification.eq('status_primary')]
ck('eight_status_sensitivity_coefficients_preserved',len(status)==8 and status.status.eq('estimated').all())
for term,pair in status.groupby('term'):
 ck('matched_status_samples_'+term,pair.sample_sha256.nunique()==1 and pair.rows.nunique()==1 and pair.countries.nunique()==1 and pair.families.nunique()==1)
ledger=pd.read_csv(O/'tables/country-diffusion-expanded-matrix.csv');ck('complete_broad_correction_ledger',len(ledger)==575 and np.allclose(multipletests(ledger.p_value,method='holm')[1],ledger.expanded_matrix_Holm_p,rtol=0,atol=1e-12))
ck('unweighted_status_findings_retained',ledger[ledger.model_block.eq('unweighted')].expanded_matrix_Holm_p.lt(.05).any())
ck('learning_not_fit_below_fixed_minimum',primary[primary.term.eq('gdp_learning')].status.eq('not_estimated_insufficient_support').all() and primary[primary.term.eq('gdp_learning')].rows.eq(41).all())
estimated=primary.status.eq('estimated');pv=primary.loc[estimated,'p_value'].to_numpy();expected=multipletests(np.r_[pv,np.ones(8-len(pv))],method='holm')[1][:len(pv)]
ck('primary_Holm_counts_all_eight_planned_tests',np.allclose(expected,primary.loc[estimated,'holm_primary_8_p'],rtol=0,atol=1e-12))
caps=w[w.target.eq('inclusive_first_year')&w.configuration.eq('baseline')&w.within_weight.eq('gdp_country_allocated')&w.across_weight.eq('baseline_market_cap_family')&w.outcome.eq('log_spread')].set_index('family').baseline_sampled_issuer_cap_mass.to_dict()
for (spec,terms,scheme),g in weights.groupby(['specification','terms','across_weight']):
 mass=np.ones(len(g)) if scheme=='equal_family' else g.family.map(caps).to_numpy()
 assert np.allclose(g.family_weight,mass/mass.sum(),rtol=0,atol=1e-12)
ck('all_diffusion_family_masses_match_declared_weighting',True)
for fit,g in members.groupby('fit_id'):
 r=weights[weights.fit_id.eq(fit)].set_index('family');q=g.merge(F[['row_id','family']],on='row_id',validate='one_to_one');observed=q.groupby('family').likelihood_weight.sum()/q.likelihood_weight.sum()
 assert np.allclose(observed.sort_index(),r.family_weight.sort_index(),rtol=0,atol=1e-12)
ck('all_diffusion_row_weights_have_correct_family_totals',True)
# Independent numerical likelihood optimisation and numerical Hessian for the
# principal external-finance models, rather than trusting the GLM covariance.
for scheme in ['equal_family','baseline_market_cap_family']:
 r=primary[primary.term.eq('financial_dependence')&primary.across_weight.eq(scheme)].iloc[0];m=members[members.fit_id.eq(r.fit_id)];d=m.merge(F,on='row_id',validate='one_to_one');diag=next(a for a in diagnostics if a['specification']=='primary' and a['terms']==['financial_dependence'] and a['across_weight']==scheme)
 X=pd.DataFrame({col:(d[col]-s['mean'])/s['sd'] if s['standardized'] else d[col] for col,s in diag['scaling'].items()});X.insert(0,'intercept',1.);X=pd.concat([X,pd.get_dummies(d.family+'_'+d.year.astype(str),drop_first=True,dtype=float)],axis=1);xx=X.to_numpy(float);y=d.first_event.to_numpy(float);ww=d.likelihood_weight.to_numpy(float)
 fun=lambda b:float(np.sum(ww*(np.logaddexp(0,xx@b)-y*(xx@b))))
 jac=lambda b:xx.T@(ww*(expit(xx@b)-y))
 fit=minimize(fun,np.zeros(xx.shape[1]),jac=jac,method='BFGS',options={'gtol':1e-9,'maxiter':3000});j=list(X.columns).index('financial_dependence')
 ck('independent_weighted_logit_coefficient_'+scheme,abs(fit.x[j]-r.coefficient)<1e-5 and np.max(abs(jac(fit.x)))<1e-5)
 eps=1e-5;eye=np.eye(len(fit.x))*eps;hessian=np.column_stack([(jac(fit.x+step)-jac(fit.x-step))/(2*eps) for step in eye]);bread=np.linalg.inv((hessian+hessian.T)/2);scores=pd.DataFrame(xx*(ww*(y-expit(xx@fit.x)))[:,None]);scores['iso3']=d.iso3.to_numpy();s=scores.groupby('iso3').sum().to_numpy();nc=d.iso3.nunique();n=len(d);k=xx.shape[1];cov=bread@(s.T@s)@bread*nc/(nc-1)*(n-1)/(n-k)
 ck('numerical_Hessian_country_cluster_SE_'+scheme,abs(np.sqrt(cov[j,j])-r.standard_error)<1e-5)
doc=load(O/'paper/manuscript-prose.json');h=(S/'index.html').read_text(encoding='utf8');tree=etree.HTML(h);ids=tree.xpath('//*[@id]/@id');text=lambda el:re.sub(r'\s+',' ',' '.join(el.itertext())).strip()
ck('unique_HTML_ids',len(ids)==len(set(ids)))
for link in sorted(set(tree.xpath('//@href|//@src'))):
 u=urlsplit(link)
 if u.scheme or u.netloc:continue
 if u.path:ck('local_file_'+link,(S/unquote(u.path)).is_file() or u.path=='downloads/international-policy-results.zip')
 elif u.fragment:ck('local_anchor_'+u.fragment,u.fragment in ids)
ck('sample_first',tree.xpath('//*[@id="main"]/section')[0].get('id')=='sample')
ck('two_main_parts_in_paper',[s[0] for s in doc['sections']]==['Introduction','1. Liquidity','2. Policy diffusion'])
ck('country_main_unit',doc['main_population']=='Country-average stock liquidity around national policy adoption')
ck('two_main_parts_in_HTML',text(tree.xpath('//*[@id="overview"]/h2')[0])=='1. Liquidity' and text(tree.xpath('//*[@id="diffusion"]/h2')[0])=='2. Policy diffusion')
for tid,table in zip(['family-coverage','main-results','diffusion-results'],doc['tables']):
 ck('paper_HTML_exact_'+tid,[text(row) for row in tree.xpath('//*[@id="'+tid+'"]//tbody/tr')]==[' '.join(c.replace('\n',' ') for c in row) for row in table['rows']])
ck('status_sensitivity_table_in_HTML',len(tree.xpath('//*[@id="status-results"]//tbody/tr'))==4 and doc['appendix_tables'][0]['title']=='Adoption-status sensitivity')
ck('status_findings_qualified_in_paper','Some unweighted adoption-status models show associations' in ' '.join(p for _,ps in doc['sections'] for p in ps))
ck('no_version_chronology_in_prose',all(v not in ' '.join(p for _,ps in doc['sections'] for p in ps).lower() for v in ['this version','release 25','recovered worldscope','previous version']))
ck('company_eligibility_only_appendix',bool(tree.xpath('//*[@id="appendix"]//*[@id="global-eligibility"]')) and 'Worldscope' not in text(tree.xpath('//*[@id="sample"]')[0]))
ck('source_reviews_retained',bool(tree.xpath('//a[@href="data/issuers/source-review-register.json"]')))
ck('caption_free_accessible_HTML',not tree.xpath('//figcaption|//h3|//script|//input|//select') and all(im.get('alt') for im in tree.xpath('//img')))
ck('charts_reserve_space_for_anchor_navigation',all(im.get('width') and im.get('height') for im in tree.xpath('//img')))
ck('details_summary_first',all(list(d)[0].tag=='summary' for d in tree.xpath('//details')))
paths=[O/'paper/expanded-policy-paper-draft.pdf',S/'downloads/paper.pdf',Path('outputs/expanded-policy-paper-draft.pdf'),R/'09-expanded-policy-paper/2026-10-18/paper/expanded-policy-paper-draft.pdf']
ck('current_PDF_copies_match',len({hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})==1)
pdf=PdfReader(paths[0]);pdftext='\n'.join(p.extract_text() for p in pdf.pages)
ck('five_pages_three_tables_two_figures',len(pdf.pages)==5 and len(doc['tables'])==3 and len(doc['figures'])==2)
ck('all_titles_present_in_PDF',all(t['title'] in pdftext for t in doc['tables']+doc['figures']))
ck('no_replacement_glyphs','\ufffd' not in pdftext and '\u25a0' not in pdftext)
ck('concise_accounting_prose',load(O/'paper/paper-data-snapshot.json')['prose_words']<1200)
for p in (S/'data/international').glob('*.csv'):
 ck('no_licensed_company_identifiers_'+p.name,not set(pd.read_csv(p,nrows=0).columns)&{'security_id','issuer_id','dscompcode','isin','cusip'})
result={'validated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':len(checks),'checks':checks,'main_unit':'Country-average market liquidity and national adoption decisions','liquidity_rerun':True,'diffusion_feature_rebuild_and_rerun':True,'both_weights_in_both_parts':True,'country_cohort_cells_reconstructed':len(cc),'independent_numerical_weighted_logit_and_cluster_checks':True,'visual_QA':'All five PDF pages rendered and inspected; browser verification recorded separately.'}
for p in [O/'audit/international-validation.json',S/'data/international/validation.json']:p.write_text(json.dumps(result,indent=2),encoding='utf8')
for p in H.glob('*.py'):shutil.copy2(p,O/'scripts'/p.name)
with zipfile.ZipFile(S/'downloads/international-policy-results.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted((S/'data/international').iterdir()):z.write(p,'results/'+p.name)
 plan=load(O/'international-analysis-plan.json');z.writestr('analysis-plan.json',json.dumps(plan,indent=2))
 for name in ['estimate_countries.py','aggregate_countries.py','build_country_mechanisms.py','fit_mechanisms.py','fit_weighted_diffusion.py','validate_country_release.py']:
  code=(H/name).read_text().replace("R=Path(r'C:\\Users\\hia_n\\Desktop\\policy-diffusion')","R=Path(__import__('os').environ['POLICY_DIFFUSION_ROOT'])");z.writestr('code/'+name,code)
 z.writestr('README.txt','Country-level national policy analysis. Two parts: market liquidity and policy diffusion, each with equal and market-cap family weights. Country-cohort mean changes permit reconstruction of the main liquidity comparisons; all source support failures and alternative models remain included. Full reconstruction of fixed company samples requires licensed Datastream inputs, company mappings, country macro data and the preserved peer-network file. Set POLICY_DIFFUSION_ROOT to a local research folder using the 25-country-level-main-paper/2026-10-19 layout. Raw company observations and identifiers are not published. Older eligibility-audit files remain historical supplementary evidence.\n')
with zipfile.ZipFile(S/'downloads/international-policy-results.zip') as z:assert z.testzip() is None
(O/'audit/code-manifest.json').write_text(json.dumps([{'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(H.glob('*.py'))],indent=2),encoding='utf8')
print(json.dumps({'checks_passed':len(checks),'country_cohort_cells_reconstructed':len(cc),'numerical_weighted_logit_and_cluster_checks':True}))
