"""Disclosed fixed matrix of conditional timing/status regressions, including all failures."""
import os
for key in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:os.environ[key]='1'
from pathlib import Path
import sys,json,warnings,hashlib,time,datetime
H=Path(__file__).parent;sys.path.insert(0,str(H.parent/'empirical-deps'));sys.path.insert(0,'work/empirical-deps')
import numpy as np,pandas as pd,statsmodels.api as sm
from scipy.stats import t as student_t
from statsmodels.stats.multitest import multipletests
R=Path(__import__('os').environ['POLICY_DIFFUSION_ROOT']);O=R/'24-global-issuer-eligibility-audit/2026-10-19';F=pd.read_parquet(O/'data/lagged-mechanism-panel.parquet');F['row_id']=np.arange(len(F))
features=['trade_fixed2000','trade_fixed2000_strict','trade_fixed2013','trade_annual','gdp_learning','gdppc_learning','liquidity_learning','liquidity_learning_continuous','benchmarked_liquidity_success','language','legal','igo','credit_gdp','aid_gdp','financial_dependence','financial_positive']
economic=['ln_gdp_pc','gdp_growth','trade_gdp'];results=[];fits=[];members=[];start=time.time();counter=0
panels={fam:q for fam,q in F.groupby('family')};panels['POOLED_DOCUMENTED_CASES']=F[F.family.ne('PUBLISHED_ESG_BENCHMARK')]
# The benchmark collective-wave restriction is a separately labelled sensitivity, not a promoted legal sample.
panels['PUBLISHED_ESG_INDEPENDENT_SENSITIVITY']=F[F.family.eq('PUBLISHED_ESG_BENCHMARK')&~F.known_collective_focal]
def design(q,outcome,terms,controlled):
 extras=[c+'_unknown' for c in terms if c+'_unknown' in q]
 if any('learning' in c or c=='benchmarked_liquidity_success' for c in terms):extras+=['geographic_known_fraction']
 nuisance=list(dict.fromkeys(extras+(economic if controlled else [])))
 keep=list(dict.fromkeys(terms+nuisance));d=q.dropna(subset=keep+[outcome]).copy();before=len(d)
 if len(d):
  d['stratum']=d.family+'_'+d.year.astype(str);variation=d.groupby('stratum')[outcome].nunique();d=d[d.stratum.isin(variation[variation.gt(1)].index)].copy()
 y=d[outcome].astype(float);x={};scaling={};dropped=[]
 for c in keep:
  vals=d[c].astype(float);s=vals.std(ddof=0)
  if not len(vals) or not np.isfinite(s) or s<1e-12:
   if c in terms:return d,y,None,{'reason':'constant_focal_measure','before_constant_strata':before,'dropped_nuisance':dropped}
   dropped.append(c);continue
  binary=set(vals.unique())<={0.,1.}
  x[c]=vals if binary else (vals-vals.mean())/s;scaling[c]={'mean':float(vals.mean()),'sd':float(s),'standardized':not binary}
 X=pd.DataFrame(x,index=d.index);X.insert(0,'intercept',1.)
 if len(d):X=pd.concat([X,pd.get_dummies(d.stratum,prefix='FE',drop_first=True,dtype=float)],axis=1)
 return d,y,X,{'before_constant_strata':before,'dropped_nuisance':dropped,'scaling':scaling}
def run(q,sample,kind,terms,controlled,label):
 global counter
 outcome='first_event' if kind=='first_recorded_implementation_timing' else 'status_event'
 q=q[q.in_first_event_risk] if outcome=='first_event' else q
 d,y,X,diag=design(q,outcome,terms,controlled);n=len(d);nc=d.iso3.nunique();ne=int(y.sum());counter+=1;fid=f'M{counter:05}'
 base={'fit_id':fid,'sample':sample,'outcome_design':kind,'specification':label,'controlled':controlled,'rows':n,'countries':nc,'events_or_status_ones':ne,'nonevents_or_status_zeros':n-ne,'strata':d.stratum.nunique() if 'stratum' in d else 0,'rows_before_missing_inputs':len(q),'rows_after_inputs_before_constant_strata':diag['before_constant_strata'],'status':'not_estimated_insufficient_support'}
 if n<50 or nc<15 or ne<10 or n-ne<10 or X is None:
  if X is None:base['status']='not_estimated_'+diag['reason']
  for est in ['logit','linear_probability']:
   for term in terms:results.append(dict(base,estimator=est,term=term))
  fits.append(dict(base,diagnostics=diag));return
 xx=X.to_numpy(float);rank=int(np.linalg.matrix_rank(xx));diag['design_columns']=len(X.columns);diag['rank']=rank
 if rank<len(X.columns) or n<=rank:
  for est in ['logit','linear_probability']:
   for term in terms:results.append(dict(base,estimator=est,term=term,status='not_estimated_rank_deficient'))
  fits.append(dict(base,status='not_estimated_rank_deficient',diagnostics=diag));return
 digest=hashlib.sha256(','.join(map(str,sorted(d.row_id))).encode()).hexdigest();base['sample_sha256']=digest
 members.extend({'fit_id':fid,'row_id':int(v)} for v in d.row_id)
 for est in ['logit','linear_probability']:
  status='estimated_exploratory';catch=[];modeldiag={}
  try:
   with warnings.catch_warnings(record=True) as ww:
    warnings.simplefilter('always')
    if est=='logit':fit=sm.GLM(y,X,family=sm.families.Binomial()).fit(maxiter=150,tol=1e-9,cov_type='cluster',cov_kwds={'groups':d.iso3.to_numpy(),'use_correction':True})
    else:fit=sm.OLS(y,X).fit(cov_type='cluster',cov_kwds={'groups':d.iso3.to_numpy(),'use_correction':True})
    catch=[str(w.message) for w in ww]
   pars=np.asarray(fit.params);ses=np.asarray(fit.bse);converged=bool(getattr(fit,'converged',True));modeldiag={'converged':converged,'warnings':catch,'maximum_abs_coefficient':float(np.max(np.abs(pars))),'all_standard_errors_finite_positive':bool(np.isfinite(ses).all() and (ses>0).all())}
   stable=converged and not catch and np.isfinite(pars).all() and np.isfinite(ses).all() and (ses>0).all() and np.max(np.abs(pars))<25
   if not stable:status='unstable_withheld'
   for term in terms:
    rr=dict(base,estimator=est,term=term,status=status)
    if stable:
     co=float(fit.params[term]);se=float(fit.bse[term]);crit=float(student_t.ppf(.975,nc-1));p=float(2*student_t.sf(abs(co/se),nc-1))
     rr.update(coefficient=co,standard_error=se,p_value=p,ci_low=co-crit*se,ci_high=co+crit*se,unit='binary_0_to_1' if not diag['scaling'][term]['standardized'] else 'one_sample_SD',odds_ratio=float(np.exp(co)) if est=='logit' else None)
    results.append(rr)
   if not stable:modeldiag['withheld_focal_diagnostics']={c:{'raw_coefficient':float(fit.params[c]),'raw_se':float(fit.bse[c])} for c in terms}
  except Exception as e:
   status='fit_failed_withheld';modeldiag={'error':str(e),'warnings':catch}
   for term in terms:results.append(dict(base,estimator=est,term=term,status=status))
  fits.append(dict(base,estimator=est,status=status,diagnostics=diag,fit_diagnostics=modeldiag))
for sample,q in panels.items():
 for kind in ['first_recorded_implementation_timing','absorbing_recorded_implementation_status_JIBS_comparison']:
  for term in features:
   for controlled in [False,True]:run(q,sample,kind,[term],controlled,'single_mechanism')
  for proxy in ['language','legal','igo']:
   run(q,sample,kind,['trade_fixed2000','gdp_learning',proxy,'financial_dependence'],True,'combined_four_mechanisms_'+proxy)
 print(json.dumps({'sample_done':sample,'attempted_designs':counter,'elapsed_seconds':round(time.time()-start,1)}),flush=True)
T=pd.DataFrame(results);ok=T.status.eq('estimated_exploratory');T['holm_all_focal_p_value']=np.nan
if ok.any():T.loc[ok,'holm_all_focal_p_value']=multipletests(T.loc[ok,'p_value'],method='holm')[1]
primary=ok&T.estimator.eq('logit')&~T.controlled&T.specification.eq('single_mechanism')&T['sample'].eq('POOLED_DOCUMENTED_CASES')&T.outcome_design.eq('first_recorded_implementation_timing')&T.term.isin(['trade_fixed2000','gdp_learning','language','financial_dependence'])
T['holm_primary_family_p_value']=np.nan
if primary.any():T.loc[primary,'holm_primary_family_p_value']=multipletests(T.loc[primary,'p_value'],method='holm')[1]
T.to_csv(O/'tables/jibs-mechanism-models-all.csv',index=False);pd.DataFrame(members).to_parquet(O/'audit/exact-model-row-membership.parquet',index=False)
def strict(value):
 if isinstance(value,dict):return {k:strict(v) for k,v in value.items()}
 if isinstance(value,list):return [strict(v) for v in value]
 if isinstance(value,float) and not np.isfinite(value):return None
 return value
(O/'audit/model-diagnostics.json').write_text(json.dumps(strict(fits),indent=2,allow_nan=False),encoding='utf-8')
summary={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'attempted_designs':counter,'coefficient_cells':len(T),'estimated_focal_coefficients':int(ok.sum()),'estimated_models':int(T.loc[ok,['fit_id','estimator']].drop_duplicates().shape[0]),'raw_p_below_05':int((ok&T.p_value.lt(.05)).sum()) if 'p_value' in T else 0,'holm_all_below_05':int((ok&T.holm_all_focal_p_value.lt(.05)).sum()),'status_counts':T.status.value_counts().to_dict(),'primary_family_estimable_coefficients':int(primary.sum()),'elapsed_seconds':time.time()-start,'inference':'Associations conditional on documented cases. Standard errors cluster by country; t reference countries-1df. Holm covers every stable focal coefficient including LPM sensitivities; no causal diffusion conclusion.'}
(O/'audit/diffusion-test-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps(summary),flush=True)
