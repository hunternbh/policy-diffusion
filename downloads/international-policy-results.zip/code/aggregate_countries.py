"""Country aggregation of the global Datastream panel; no issuer eligibility imputation."""
from pathlib import Path
import sys,json,datetime
sys.path.insert(0,'work/empirical-deps')
import pandas as pd,numpy as np,pyarrow.parquet as pq
R=Path(__import__('os').environ['POLICY_DIFFUSION_ROOT']);O=R/'25-country-level-main-paper/2026-10-19'
d=pd.read_parquet(R/'09-expanded-policy-paper/2026-10-18/data/security-year-liquidity.parquet')
q=pd.read_parquet(R/'17-issuer-regulation-expansion/2026-10-19/data/all-annual-company-mapping.parquet')
outs=['log_spread','log_impact','zero_fraction']
q=q[q.dscompcode.notna()].copy();amb=q.groupby(['security_id','year']).dscompcode.nunique();bad=set(amb[amb.gt(1)].index)
q=q[[tuple(x) not in bad for x in q[['security_id','year']].to_numpy()]].drop_duplicates(['security_id','year'])
x=d.merge(q[['security_id','year','dscompcode']],on=['security_id','year'],how='inner',validate='one_to_one')
selected=x.sort_values(['year','dscompcode','market_cap_usd','security_id'],ascending=[True,True,False,True],na_position='last').drop_duplicates(['year','dscompcode']).copy()
rows=[]
for (iso,year),z in selected.groupby(['iso3','year']):
 row={'iso3':iso,'year':int(year),'sample_company_records':len(z),'sample_market_cap_usd':float(z.loc[z.market_cap_usd.gt(0),'market_cap_usd'].sum())}
 for out in outs:
  v=z[np.isfinite(z[out])];v_cap=v[v.market_cap_usd.gt(0)&np.isfinite(v.market_cap_usd)]
  row[out+'_equal_company']=float(v[out].mean()) if len(v) else None
  row[out+'_market_cap']=float(np.average(v_cap[out],weights=v_cap.market_cap_usd)) if len(v_cap) else None
  row[out+'_company_count']=len(v)
 rows.append(row)
panel=pd.DataFrame(rows).sort_values(['iso3','year']);panel.to_parquet(O/'data/country-year-liquidity.parquet',index=False)
coverage=panel.groupby('iso3').agg(first_year=('year','min'),last_year=('year','max'),observed_years=('year','nunique'),company_year_records=('sample_company_records','sum')).reset_index()
coverage.to_json(O/'audit/country-panel-coverage.json',orient='records',indent=2)
# Re-express every main-specification cohort comparison as country means.
# Cohort membership is fixed by the estimator, so company composition is identical.
members=pd.read_parquet(O/'audit/issuer-exposure-exact-memberships-local.parquet')
macro=pd.read_csv(O/'data/macro-country-year.csv').set_index(['iso3','year'])
reference=pd.read_csv(O/'tables/issuer-exposure-group-time-cells.csv')
reference=reference[reference.configuration.eq('baseline')&reference.within_weight.eq('gdp_country_allocated')]
checks=[];country_rows=[]
for (target,family,g),m in members.groupby(['target','family','cohort']):
 g=int(g);events=[0] if target=='inclusive_first_year' else [-3,-2,0,1,2]
 base=d[d.year.eq(g-1)].set_index('security_id')
 for e in events:
  end=d[d.year.eq(g+e)].set_index('security_id')
  z=m[['security_id','iso3','arm']].copy()
  for out in outs:z[out]=z.security_id.map(end[out])-z.security_id.map(base[out])
  cm=z.groupby(['arm','iso3'])[outs].mean().reset_index()
  for r in cm.to_dict('records'):country_rows.append({'target':target,'family':family,'cohort':g,'event_time':e,**r})
  for out in outs:
   means={arm:float(np.average(c[out],weights=[macro.loc[(iso,g-1),'gdp_constant_usd'] for iso in c.iso3])) for arm,c in cm.groupby('arm')}
   actual=means['treated']-means['comparison']
   ref=reference[reference.target.eq(target)&reference.family.eq(family)&reference.cohort.eq(g)&reference.event_time.eq(e)&reference.outcome.eq(out)]
   assert len(ref)==1
   error=abs(actual-float(ref.iloc[0].estimate));assert error<1e-10,(target,family,g,e,out,error)
   checks.append(error)
pd.DataFrame(country_rows).to_parquet(O/'data/country-cohort-liquidity-changes.parquet',index=False)
root=Path(r'E:\6 Data\datastream');schema=[]
for directory in sorted(root.iterdir()):
 if directory.is_dir():
  paths=list(directory.glob('*.parquet'))
  if paths:schema.append({'period':directory.name,'files':len(paths),'representative_file':paths[0].name,'columns':pq.read_schema(paths[0]).names})
audit={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'raw_parquet_period_schema_checks':schema,'stock_year_rows':len(d),'sample_vendor_company_codes':int(x.dscompcode.nunique()),'company_year_records_after_share_line_selection':len(selected),'country_year_rows':len(panel),'jurisdictions':int(panel.iso3.nunique()),'years':[int(panel.year.min()),int(panel.year.max())],'ambiguous_security_year_mapping_keys_withheld':len(bad),'aggregation':'One share line per vendor company and year, largest available market cap; equal-company and sampled market-cap country averages. Country uses the existing cleaned panel country assignment. This descriptive series permits annual composition changes.','main_estimator':'Fixed cohort company samples; GDP-weighted country mean changes, with separate equal-family and pre-implementation market-cap family aggregation. The descriptive country-year series does not replace the fixed-cohort estimator.','country_reexpression_checks':len(checks),'maximum_absolute_difference_from_existing_main_cohort_estimates':max(checks),'eligibility':'Country aggregation measures exposure to national policy. It does not require company size fields, certify every company is legally treated, or certify complete coverage of every listed company.','worldscope_security_fields':'wssctyppi and wssctyppi2 identify securities; no revenue, total assets or employee field occurs in the representative raw schemas.'}
(O/'audit/country-aggregation-verification.json').write_text(json.dumps(audit,indent=2),encoding='utf8')
print(json.dumps({k:audit[k] for k in ['stock_year_rows','sample_vendor_company_codes','company_year_records_after_share_line_selection','country_year_rows','jurisdictions','years','country_reexpression_checks','maximum_absolute_difference_from_existing_main_cohort_estimates']}))
