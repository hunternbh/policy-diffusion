"""Global country-level lagged diffusion signals from preserved peer networks."""
from pathlib import Path
import sys,json,datetime,hashlib,shutil
sys.path.insert(0,'work/empirical-deps')
import pandas as pd,numpy as np
R=Path(__import__('os').environ['POLICY_DIFFUSION_ROOT']);O=R/'25-country-level-main-paper/2026-10-19';OLD=R/'09-expanded-policy-paper/2026-10-18';P=R/'06-capital-market-disclosure-research/outputs/research_project'
source=R/'21-fresnillo-and-carbon-issuer-review/2026-10-19/data/network-memberships.csv';N=pd.read_csv(source)
markets=set(pd.read_parquet(O/'data/country-year-liquidity.parquet').iso3)
def mapping(label,year=None):
 q=N[N.network.eq(label)]
 if year is not None:q=q[q.source_year.eq(year)]
 return {i:z.sort_values('rank').partner.tolist() for i,z in q.groupby('origin')}
networks={int(y):mapping('export_pattern',y) for y in N[N.network.eq('export_pattern')].source_year.unique()}
geonet=mapping('geographic10');langnet=mapping('official_language');legnet=mapping('legal_origin');igon=mapping('IGO_Jaccard',2000)
shutil.copy2(source,O/'data/network-memberships.csv')
events=pd.read_csv(O/'data/classified-dated-policy-cases.csv');events=events[events.regulation_family.ne('CBCR_BANK_FULL')].copy();events.loc[events.regulation_family.eq('CBCR_BANK_PARTIAL'),'regulation_family']='CBCR_BANK_PUBLIC';assert not events.duplicated(['iso3','regulation_family']).any();events['independent']=events.independent.astype(str).str.lower().eq('true')
E={f:q[['iso3','G','assignment_cluster','independent']].copy() for f,q in events.groupby('regulation_family')}
b=pd.read_csv(OLD/'data/esg-2023-published-sample.csv');b['G']=b.published_G.fillna(9999).astype(int);b['independent']=True;b['assignment_cluster']=b.iso3
eu={'AUT','BEL','BGR','HRV','CYP','CZE','DNK','EST','FIN','FRA','DEU','GRC','HUN','IRL','ITA','LVA','LTU','LUX','MLT','NLD','POL','PRT','ROU','SVK','SVN','ESP','SWE','GBR','NOR','ISL','LIE'}
b.loc[b.iso3.isin(eu)&b.G.isin([2016,2017]),'assignment_cluster']='EU_NFRD';E['PUBLISHED_ESG_BENCHMARK']=b
macro=pd.read_csv(O/'data/macro-country-year.csv').set_index(['iso3','year']);market=pd.read_parquet(O/'data/country-year-liquidity.parquet').sort_values(['iso3','year']);market['liquidity_improvement']=-market.groupby('iso3').log_spread_equal_company.diff();gap=market.groupby('iso3').year.diff();market.loc[gap.ne(1),'liquidity_improvement']=np.nan;market=market.set_index(['iso3','year'])
cells=pd.read_csv(O/'tables/country-cohort-mean-changes.csv');cells=cells[cells.configuration.eq('baseline')&cells.outcome.eq('log_spread')&cells.within_weight.eq('gdp_country_allocated')&cells.target.eq('inclusive_first_year')&cells.event_time.eq(0)].rename(columns={'country_mean_change':'delta'});cells.loc[cells.arm.eq('comparison'),'arm']='control';clusters=events.set_index(['regulation_family','iso3']).assignment_cluster.to_dict();cells['assignment_cluster']=[clusters.get((f,i),i) for f,i in zip(cells.family,cells.iso3)]
features=[]
def get(table,iso,yr,col):
 try:return float(table.loc[(iso,yr),col])
 except KeyError:return np.nan
def share(N,i,yr,dates,minimum):
 peers=N.get(i,[]);known=[p for p in peers if p in dates]
 n=len(peers);k=len(known);a=sum(dates[p]<=yr-1 for p in known)
 return (a/k if k>=minimum else np.nan,1-k/n if n else np.nan,a/n if n else np.nan,(a+n-k)/n if n else np.nan,k,n)
def learn(peers,yr,dates,col,table):
 before=[p for p in peers if p in dates and dates[p]<=yr-2];after=[p for p in peers if p in dates and dates[p]>yr-1]
 a=[get(table,p,yr-1,col) for p in before];c=[get(table,p,yr-1,col) for p in after]
 aa=[v for v in a if np.isfinite(v)];cc=[v for v in c if np.isfinite(v)]
 if not a or not c or len(aa)/len(a)<.8 or len(cc)/len(c)<.8:return np.nan,np.nan
 diff=float(np.median(aa)-np.median(cc));return float(diff>0),diff
for fam,ev in E.items():
 dates=dict(zip(ev.iso3,ev.G));clusters=dict(zip(ev.iso3,ev.assignment_cluster));fc=cells[cells.family.eq(fam)]
 begin,end=(2002,2020) if fam=='PUBLISHED_ESG_BENCHMARK' else (2001,2025)
 for row in ev.itertuples():
  if row.iso3 not in markets:continue
  for yr in range(begin,end+1):
   r={'iso3':row.iso3,'year':yr,'family':fam,'G':int(row.G),'assignment_cluster':row.assignment_cluster,'first_event':int(yr==row.G),'status_event':int(yr>=row.G),'in_first_event_risk':bool(yr<=row.G),'published_window_only':fam=='PUBLISHED_ESG_BENCHMARK','known_collective_focal':row.assignment_cluster!=row.iso3,'maximum_information_year':yr-1}
   i=row.iso3;peers=geonet.get(i,[])
   for name,N,minn in [('trade_fixed2000',networks.get(2000,{}),3),('trade_fixed2000_strict',networks.get(2000,{}),4),('trade_fixed2013',networks.get(2013,{}) if yr>=2014 else {},3),('trade_annual',networks.get(yr-1,{}) if yr<=2015 else {},3),('language',langnet,3),('legal',legnet,3),('igo',igon,3)]:
    v,u,lo,hi,k,n=share(N,i,yr,dates,minn);r[name]=v;r[name+'_unknown']=u;r[name+'_lower']=lo;r[name+'_upper']=hi;r[name+'_known']=k;r[name+'_peers']=n
   for name,col,table in [('gdp_learning','gdp_growth_pct',macro),('gdppc_learning','gdp_pc_growth_pct',macro),('liquidity_learning','liquidity_improvement',market)]:
    r[name],r[name+'_continuous']=learn(peers,yr,dates,col,table)
   # Foreign success contrasts exclude the focal country and every control in its assignment cluster.
   success=[];prior=[p for p in peers if p in dates and dates[p]<=yr-2]
   for p in prior:
    g=int(dates[p]);q=fc[fc.cohort.eq(g)];tr=q[q.arm.eq('treated')&q.iso3.eq(p)];co=q[q.arm.eq('control')&q.iso3.ne(i)&q.assignment_cluster.ne(row.assignment_cluster)]
    if len(tr)==1 and len(co)>=3:success.append(float(-(tr.delta.iloc[0]-co.delta.mean())))
   r['benchmarked_liquidity_success']=float(np.median(success)) if prior and len(success)/len(prior)>=.8 else np.nan;r['benchmarked_learning_coverage']=len(success)/len(prior) if prior else np.nan
   gdp=get(macro,i,yr-1,'gdp_current_usd');credit=get(macro,i,yr-1,'imf_credit_and_sdr_usd');aid=get(macro,i,yr-1,'net_aid_usd')
   r['credit_gdp']=100*credit/gdp if gdp>0 else np.nan;r['aid_gdp']=100*aid/gdp if gdp>0 else np.nan;r['financial_dependence']=r['credit_gdp']+r['aid_gdp'];r['financial_positive']=float(credit>0 or aid>0) if np.isfinite(credit) and np.isfinite(aid) else np.nan
   pc=get(macro,i,yr-1,'gdp_pc_constant');r['ln_gdp_pc']=np.log(pc) if pc>0 else np.nan;r['gdp_growth']=get(macro,i,yr-1,'gdp_growth_pct');r['trade_gdp']=get(macro,i,yr-1,'trade_gdp_pct')
   r['geographic_known_fraction']=sum(p in dates for p in peers)/len(peers) if peers else np.nan
   features.append(r)
 print('features',fam,len(features),flush=True)
F=pd.DataFrame(features)
# Scope/enforcement weakening prevents unqualified absorbing-status carry-forward.
for iso,fam,yr in [('USA','BENEFICIAL_OWNERSHIP',2025),('DEU','SUPPLY_CHAIN',2025)]:
 mask=F.iso3.eq(iso)&F.family.eq(fam)&F.year.ge(yr);F.loc[mask,'status_event']=np.nan;F.loc[mask,'status_history_censored']=True
F['status_history_censored']=F.status_history_censored.fillna(False).astype(bool)
assert not F.duplicated(['family','iso3','year']).any();assert F.maximum_information_year.lt(F.year).all();assert F.loc[F.year.lt(2014),'trade_fixed2013'].isna().all();assert F.loc[F.year.gt(2015),'trade_annual'].isna().all()
F.to_parquet(O/'data/lagged-mechanism-panel.parquet',index=False)
F.groupby('family').agg(rows=('iso3','size'),countries=('iso3','nunique'),first_events=('first_event','sum'),status_ones=('status_event','sum')).to_csv(O/'audit/mechanism-panel-support.csv')

audit={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':len(F),'market_jurisdictions':len(markets),'diffusion_jurisdictions':int(F.iso3.nunique()),'families_without_published_benchmark':int(F.loc[F.family.ne('PUBLISHED_ESG_BENCHMARK'),'family'].nunique()),'focal_rule':'All documented country histories in the 90-market universe, including collective waves; independent choices are separately estimated. Missing histories are not invented.','peer_histories':'May include documented countries outside the focal market universe. All adoption shares use t-1; learning uses prior adopters before t-1.','source_network':str(source.relative_to(R)),'source_network_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'source_calendar_sha256':hashlib.sha256((O/'data/classified-dated-policy-cases.csv').read_bytes()).hexdigest(),'country_liquidity_source':'country-year-liquidity.parquet; consecutive-year changes only','benchmarked_success':'Fixed-cohort country changes from current liquidity rerun; excludes focal country and shared assignment clusters from controls.','calendar_limit':'Recorded implementation phases; not certified earliest adoption or real-time-vintage macro data.'}
(O/'audit/mechanism-construction.json').write_text(json.dumps(audit,indent=2),encoding='utf8');print(json.dumps(audit),flush=True)
