"""Country-level staggered policy comparisons from fixed company samples."""
from pathlib import Path
import sys,json,time,hashlib
H=Path(__file__).parent;sys.path.insert(0,str(H.parent/'empirical-deps'));sys.path.insert(0,'work/empirical-deps')
import pandas as pd,numpy as np
from statsmodels.stats.multitest import multipletests
R=Path(__import__('os').environ['POLICY_DIFFUSION_ROOT']);O=R/'25-country-level-main-paper/2026-10-19';start=time.time();plan=json.loads((O/'geographic-analysis-plan.json').read_text());d=pd.read_parquet(R/'09-expanded-policy-paper/2026-10-18/data/security-year-liquidity.parquet');q=pd.read_parquet(R/'17-issuer-regulation-expansion/2026-10-19/data/all-annual-company-mapping.parquet');outcomes=plan['outcomes'];countries=sorted(d.iso3.unique());ci={v:k for k,v in enumerate(countries)};K=len(countries);M=np.random.default_rng(20261019).choice([-1.,1.],(1999,K));macro=pd.read_csv(O/'data/macro-country-year.csv').set_index(['iso3','year'])
q=q[q.dscompcode.notna()];amb=q.groupby(['security_id','year']).dscompcode.nunique();bad=set(amb[amb.gt(1)].index);q=q[[tuple(x) not in bad for x in q[['security_id','year']].to_numpy()]];q=q.drop_duplicates(['security_id','year']);d=d.merge(q[['security_id','year','dscompcode']],on=['security_id','year'],how='inner',validate='one_to_one');d['issuer_id']=d.dscompcode.astype(str);d.to_parquet(O/'data/vendor-issuer-annual-liquidity.parquet',index=False);d=d.set_index(['security_id','year']).sort_index();cache={};samples=[]
cases=pd.read_csv(O/'data/classified-dated-policy-cases.csv');cases=cases[cases.regulation_family.ne('CBCR_BANK_FULL')].copy();cases.loc[cases.regulation_family.eq('CBCR_BANK_PARTIAL'),'regulation_family']='CBCR_BANK_PUBLIC';assert cases.regulation_family.nunique()==17 and not cases.duplicated(['iso3','regulation_family']).any();cases.independent=cases.independent.astype(str).str.lower().eq('true');famnames=sorted(cases.regulation_family.unique())
def cohort_panel(target,g):
 key=(target,g)
 if key in cache:return cache[key]
 years=list(range(g-3,g+3)) if target=='balanced_mean_0_2' else [g-1,g];h=np.array([-3,-2,0,1,2]) if target=='balanced_mean_0_2' else np.array([0]);pre=d.xs(g-1,level='year').reset_index();pre=pre[pre.market_cap_usd.gt(0)].sort_values(['issuer_id','market_cap_usd','security_id'],ascending=[True,False,True]).drop_duplicates('issuer_id');chosen=pre[['security_id','issuer_id','iso3','market_cap_usd']].set_index('security_id');yy=[];valid=np.ones(len(chosen),bool)
 for year in years:
  annual=d.xs(year,level='year').reindex(chosen.index);valid &= annual.issuer_id.eq(chosen.issuer_id).to_numpy()&annual.iso3.eq(chosen.iso3).to_numpy()&np.isfinite(annual[outcomes]).all(axis=1).to_numpy();yy.append(annual[outcomes].to_numpy(float))
 chosen=chosen.iloc[np.flatnonzero(valid)].copy();y=np.stack(yy,axis=1)[valid];n=chosen.groupby('iso3').size();keep=chosen.iso3.map(n).ge(30).to_numpy();chosen=chosen.iloc[np.flatnonzero(keep)].copy();y=y[keep];n=chosen.groupby('iso3').size();base=years.index(g-1);delta=np.stack([y[:,years.index(g+int(e)),:]-y[:,base,:] for e in h],axis=1);iso=chosen.iso3.to_numpy();idx=np.array([ci[c] for c in iso]);gdp=np.array([macro.loc[(c,g-1),'gdp_constant_usd'] if (c,g-1) in macro.index else np.nan for c in iso],float);weights={'gdp_country_allocated':gdp/chosen.iso3.map(n).to_numpy(),'equal_issuer':np.ones(len(chosen)),'baseline_issuer_market_cap':chosen.market_cap_usd.to_numpy(float)};z={'units':chosen,'delta':delta,'iso':iso,'idx':idx,'weights':weights,'h':h};cache[key]=z;return z
def diag(x,inf):
 se=float(np.linalg.norm(inf));noise=M@inf;p=float((1+(np.abs(noise)>=abs(x)).sum())/2000) if se>1e-14 else None
 return {'estimate':float(x),'country_cluster_se_diagnostic':se,'conditional_ci_low':float(x-1.96*se),'conditional_ci_high':float(x+1.96*se),'multiplier_p':p}
def pretest(est,ifs,h):
 mask=np.isin(h,[-3,-2]);se=np.linalg.norm(ifs[mask],axis=1)
 if not mask.any() or not (se>1e-14).all():return None
 obs=np.max(np.abs(est[mask]/se));noise=M@ifs[mask].T;return float((1+(np.max(np.abs(noise/se),axis=1)>=obs).sum())/2000)
results={};familyrows=[];profiles=[];cohortrows=[];support=[];members=[];countrycells=[]
for target in ['inclusive_first_year','balanced_mean_0_2']:
 lo,hi=(2001,2025) if target=='inclusive_first_year' else (2003,2023)
 for config in ['baseline','public_availability_plus1','independent_choices_only']:
  for fam in famnames:
   ev=cases[cases.regulation_family.eq(fam)].copy()
   if config=='public_availability_plus1':ev.loc[ev.G.lt(9999),'G']+=1
   if config=='independent_choices_only':ev=ev[ev.independent]
   dates=ev.set_index('iso3').G.to_dict()
   for weightname in plan['within_family_weights']:
    cohorts=[]
    for g in sorted(ev.loc[ev.G.between(lo,hi),'G'].astype(int).unique()):
     z=cohort_panel(target,g);G=np.array([dates.get(c,np.nan) for c in z['iso']]);weight=z['weights'][weightname];ok=np.isfinite(weight)&(weight>0);end=g+(2 if target=='balanced_mean_0_2' else 0);tr=np.flatnonzero(ok&(G==g));co=np.flatnonzero(ok&(G>end));nc=len(set(z['iso'][co]));status='estimated' if len(tr)>=30 and len(co)>=30 and nc>=3 else 'unsupported_issuer_or_country_counts';support.append({'target':target,'configuration':config,'family':fam,'within_weight':weightname,'cohort':int(g),'treated_issuers':len(tr),'comparison_issuers':len(co),'comparison_countries':nc,'status':status})
     if status!='estimated':continue
     wt=weight[tr];wc=weight[co];arms={};ifs=np.zeros((len(z['h']),len(outcomes),K))
     for arm,ids in [('treated',tr),('comparison',co)]:
      cs=sorted(set(z['iso'][ids]));cm=[];mass=[]
      for c in cs:
       country_ids=ids[z['iso'][ids]==c];country_mass=float(weight[country_ids].sum());country_mean=np.average(z['delta'][country_ids],axis=0,weights=weight[country_ids]);cm.append(country_mean);mass.append(country_mass)
       for e,values in zip(z['h'],country_mean):
        for out,value in zip(outcomes,values):countrycells.append({'target':target,'configuration':config,'family':fam,'within_weight':weightname,'cohort':int(g),'arm':arm,'iso3':c,'event_time':int(e),'outcome':out,'country_mean_change':float(value),'country_weight_mass':country_mass,'sample_companies':len(country_ids)})
      cm=np.stack(cm);mass=np.array(mass);mean=np.average(cm,axis=0,weights=mass);arms[arm]=mean;correct=np.sqrt(len(cs)/(len(cs)-1)) if len(cs)>1 else 1
      for c,value,w in zip(cs,cm,mass):ifs[:,:,ci[c]]+=(1 if arm=='treated' else -1)*w/mass.sum()*(value-mean)*correct
     a=arms['treated'];b=arms['comparison'];est=a-b
     cohorts.append({'g':g,'estimate':est,'if':ifs,'mass':wt.sum(),'cap':float(z['units'].iloc[tr].market_cap_usd.sum()),'ntr':len(tr),'nco':len(co),'tc':set(z['iso'][tr]),'cc':set(z['iso'][co]),'h':z['h']})
     for e,values in zip(z['h'],est):
      for o,v in zip(outcomes,values):cohortrows.append({'target':target,'configuration':config,'family':fam,'within_weight':weightname,'cohort':int(g),'event_time':int(e),'outcome':o,'estimate':float(v),'treated_issuers':len(tr),'comparison_issuers':len(co)})
     if config=='baseline' and weightname=='gdp_country_allocated':
      for arm,ids in [('treated',tr),('comparison',co)]:members.extend({'target':target,'family':fam,'cohort':g,'security_id':int(z['units'].index[j]),'issuer_id':str(z['units'].iloc[j].issuer_id),'iso3':z['iso'][j],'arm':arm,'G':int(G[j])} for j in ids)
    if not cohorts:
     for out in outcomes:familyrows.append({'target':target,'configuration':config,'family':fam,'within_weight':weightname,'outcome':out,'status':'not_estimated_no_supported_cohort'})
     continue
    mass=np.array([v['mass'] for v in cohorts]);cw=mass/mass.sum();est=sum(w*v['estimate'] for w,v in zip(cw,cohorts));ifs=sum(w*v['if'] for w,v in zip(cw,cohorts));h=cohorts[0]['h'];post=h>=0;tc=set.union(*(v['tc'] for v in cohorts));cc=set.union(*(v['cc'] for v in cohorts));cap=sum(v['cap'] for v in cohorts)
    for j,out in enumerate(outcomes):
     att=est[post,j].mean();inf=ifs[post,j,:].mean(axis=0);row={'target':target,'configuration':config,'family':fam,'within_weight':weightname,'outcome':out,'status':'estimated_country_level_policy_exposure',**diag(att,inf),'cohorts':len(cohorts),'treated_issuer_cohort_count':sum(v['ntr'] for v in cohorts),'comparison_issuer_cohort_count':sum(v['nco'] for v in cohorts),'treated_countries':len(tc),'comparison_countries':len(cc),'family_baseline_market_cap_mass':cap,'joint_lead_p_diagnostic':pretest(est[:,j],ifs[:,j,:],h),'legal_eligibility_status':'not_established_by_country_assignment','inference_flag':'country_sampling_only; collective_waves_and_low_country_counts_limit_policy_inference'};familyrows.append(row);results[(target,config,fam,weightname,out)]={'row':row,'estimate':att,'if':inf,'events':est[:,j],'event_ifs':ifs[:,j,:],'h':h,'cap':cap}
     for e,x,ii in zip(h,est[:,j],ifs[:,j,:]):profiles.append({'target':target,'configuration':config,'family':fam,'within_weight':weightname,'outcome':out,'event_time':int(e),**diag(x,ii)})
   print('DONE',target,config,fam,round(time.time()-start),flush=True)
pool=[];weights=[];poolevents=[];allifs={}
for target in ['inclusive_first_year','balanced_mean_0_2']:
 for config in ['baseline','public_availability_plus1','independent_choices_only']:
  for within in plan['within_family_weights']:
   supported=[f for f in famnames if all((target,config,f,within,o) in results for o in outcomes)]
   for across in plan['across_family_weights']:
    for out in outcomes:
     values=[results[(target,config,f,within,out)] for f in supported]
     if not values:continue
     mass=np.ones(len(values)) if across=='equal_family' else np.array([v['cap'] for v in values]);ww=mass/mass.sum();att=sum(w*v['estimate'] for w,v in zip(ww,values));inf=sum(w*v['if'] for w,v in zip(ww,values));events=sum(w*v['events'] for w,v in zip(ww,values));eifs=sum(w*v['event_ifs'] for w,v in zip(ww,values));h=values[0]['h'];row={'target':target,'configuration':config,'within_weight':within,'across_weight':across,'outcome':out,**diag(att,inf),'families':len(supported),'family_names':';'.join(supported),'effective_families':float(1/np.sum(ww**2)),'largest_family':supported[np.argmax(ww)],'largest_family_weight':float(max(ww)),'joint_lead_p_diagnostic':pretest(events,eifs,h),'interpretation':'Country-average liquidity around national policy adoption; not verified covered-issuer ATT.'};pool.append(row)
     for f,w,v in zip(supported,ww,values):weights.append({'target':target,'configuration':config,'within_weight':within,'across_weight':across,'outcome':out,'family':f,'family_weight':w,'family_estimate':v['estimate'],'weighted_contribution':w*v['estimate'],'baseline_sampled_issuer_cap_mass':v['cap']})
     noise=M@eifs.T;se=np.linalg.norm(eifs,axis=1);critical=float(np.quantile(np.max(np.abs(noise/np.where(se>0,se,np.inf)),axis=1),.95))
     for e,x,ii,ss in zip(h,events,eifs,se):poolevents.append({'target':target,'configuration':config,'within_weight':within,'across_weight':across,'outcome':out,'event_time':int(e),'families':len(supported),**diag(x,ii),'simultaneous_low':float(x-critical*ss),'simultaneous_high':float(x+critical*ss)})
     if config=='baseline':allifs['|'.join([target,within,across,out])]={'estimate':float(att),'influence':inf.tolist()}
T=pd.DataFrame(pool);primary=T.configuration.eq('baseline')&T.within_weight.eq('gdp_country_allocated');T['holm_12_principal_p']=np.nan;T.loc[primary,'holm_12_principal_p']=multipletests(T.loc[primary,'multiplier_p'],method='holm')[1]
for name,rows in [('issuer-exposure-family-did.csv',familyrows),('issuer-exposure-family-events.csv',profiles),('issuer-exposure-group-time-cells.csv',cohortrows),('issuer-exposure-family-weights.csv',weights),('issuer-exposure-pooled-events.csv',poolevents),('issuer-exposure-support.csv',support)]:pd.DataFrame(rows).to_csv(O/'tables'/name,index=False)
T.to_csv(O/'tables/issuer-exposure-pooled-did.csv',index=False);T[primary].to_csv(O/'tables/issuer-exposure-principal-estimates.csv',index=False);pd.DataFrame(members).to_parquet(O/'audit/issuer-exposure-exact-memberships-local.parquet',index=False);(O/'audit/issuer-exposure-influences.json').write_text(json.dumps({'countries':countries,'cells':allifs},indent=2),encoding='utf8');summary={'annual_rows_with_unambiguous_vendor_company':len(d),'vendor_issuers':int(d.issuer_id.nunique()),'ambiguous_security_year_company_maps_excluded':len(bad),'families_attempted':17,'pooled_cells':len(T),'estimated_family_cells':sum(r['status'].startswith('estimated') for r in familyrows),'all_family_cells':len(familyrows),'individual_outcome_changes_fixed_in_cohort':True,'not_verified_legal_eligibility_panel':True,'elapsed_seconds':time.time()-start};(O/'audit/issuer-exposure-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary),flush=True)


pd.DataFrame(countrycells).to_csv(O/'tables/country-cohort-mean-changes.csv',index=False)
