"""Country adoption likelihoods with declared family masses and explicit cluster scores."""
import os
for name in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:os.environ[name]='1'
from pathlib import Path
import sys,json,warnings,hashlib,datetime
sys.path.insert(0,'work/empirical-deps')
import numpy as np,pandas as pd,statsmodels.api as sm
from scipy.special import expit
from scipy.stats import t
from statsmodels.stats.multitest import multipletests
R=Path(__import__('os').environ['POLICY_DIFFUSION_ROOT']);O=R/'25-country-level-main-paper/2026-10-19'
F=pd.read_parquet(O/'data/lagged-mechanism-panel.parquet');F['row_id']=np.arange(len(F))
caps=pd.read_csv(O/'tables/issuer-exposure-family-weights.csv');caps=caps[caps.target.eq('inclusive_first_year')&caps.configuration.eq('baseline')&caps.within_weight.eq('gdp_country_allocated')&caps.across_weight.eq('baseline_market_cap_family')&caps.outcome.eq('log_spread')].set_index('family').baseline_sampled_issuer_cap_mass.to_dict()
q=F[F.family.isin(caps)].copy();terms=['trade_fixed2000','gdp_learning','language','financial_dependence'];results=[];audits=[];weights=[];members=[];fitid=0
base_specs=[('primary',False,False,[v]) for v in terms]+[('economic_controls',True,False,[v]) for v in terms]+[('independent_national_choices',False,True,[v]) for v in terms]+[('liquidity_learning',False,False,['liquidity_learning'])]+[('combined_four_mechanisms',True,False,terms)]
specs=[(label,control,independent,focal,'first_event') for label,control,independent,focal in base_specs]+[('status_'+label,control,independent,focal,'status_event') for label,control,independent,focal in base_specs]
for label,controlled,independent,focal,outcome in specs:
 fitid+=1;sample=q[q.in_first_event_risk] if outcome=='first_event' else q
 sample=sample[~sample.known_collective_focal] if independent else sample
 extras=[c+'_unknown' for c in focal if c+'_unknown' in q]
 if any('learning' in c for c in focal):extras+=['geographic_known_fraction']
 cols=list(dict.fromkeys(focal+extras+(['ln_gdp_pc','gdp_growth','trade_gdp'] if controlled else [])))
 d=sample.dropna(subset=cols+[outcome]).copy();d['stratum']=d.family+'_'+d.year.astype(str);v=d.groupby('stratum')[outcome].nunique();d=d[d.stratum.isin(v[v.gt(1)].index)].copy();n=len(d);G=d.iso3.nunique();event=int(d[outcome].sum());nf=d.family.nunique();record={'specification':label,'outcome_design':outcome,'terms':focal,'rows':n,'countries':G,'families':nf,'events':event,'sample_sha256':hashlib.sha256(','.join(map(str,sorted(d.row_id))).encode()).hexdigest(),'family_names':sorted(d.family.unique())}
 X={};scale={};constant=[]
 for col in cols:
  x=d[col].astype(float);sd=x.std(ddof=0)
  if not np.isfinite(sd) or sd<1e-12:
   if col in focal:constant.append(col)
   continue
  binary=set(x.unique())<={0.,1.};X[col]=x if binary else (x-x.mean())/sd;scale[col]={'mean':float(x.mean()),'sd':float(sd),'standardized':not binary}
 X=pd.DataFrame(X,index=d.index);X.insert(0,'intercept',1.);X=pd.concat([X,pd.get_dummies(d.stratum,drop_first=True,dtype=float)],axis=1)
 xx=X.to_numpy(float);y=d[outcome].to_numpy(float);rank=np.linalg.matrix_rank(xx) if len(xx) else 0;k=xx.shape[1]
 unsupported=n<50 or G<15 or event<10 or n-event<10 or constant or rank<k or n<=k
 record.update(columns=k,rank=int(rank),scaling=scale,constant_focal=constant)
 for scheme in ['equal_family','baseline_market_cap_family']:
  base={k:record[k] for k in ['specification','outcome_design','rows','countries','families','events','sample_sha256']};base['across_weight']=scheme;base['fit_id']=f'W{fitid:03}_{scheme}';base['status']='not_estimated_insufficient_support' if unsupported else 'estimated'
  if unsupported:
   audits.append({**record,'across_weight':scheme,'status':'not_estimated_insufficient_support','reason':'Minimum row/country/event support, full rank and nonconstant focal predictors required before estimation.'})
   for term in focal:results.append({**base,'term':term})
   continue
  mass={f:1. if scheme=='equal_family' else caps[f] for f in d.family.unique()};total=sum(mass.values());counts=d.groupby('family').size().to_dict();fw={f:m/total for f,m in mass.items()};w=np.array([n*fw[f]/counts[f] for f in d.family])
  assert np.isclose(w.sum(),n)
  for f in sorted(fw):
   observed=float(w[d.family.eq(f).to_numpy()].sum()/w.sum());assert abs(observed-fw[f])<1e-12
   weights.append({'fit_id':base['fit_id'],'specification':label,'terms':';'.join(focal),'across_weight':scheme,'family':f,'family_weight':fw[f],'risk_set_rows':counts[f]})
  members.extend({'fit_id':base['fit_id'],'row_id':int(r),'likelihood_weight':float(v)} for r,v in zip(d.row_id,w))
  try:
   with warnings.catch_warnings(record=True) as warns:
    warnings.simplefilter('always');fit=sm.GLM(y,X,family=sm.families.Binomial(),freq_weights=w).fit(maxiter=200,tol=1e-10)
   beta=np.asarray(fit.params);p=expit(xx@beta);score=(w*(y-p))[:,None]*xx;bread=xx.T@((w*p*(1-p))[:,None]*xx);inv=np.linalg.inv(bread);S=np.stack([score[d.iso3.eq(c).to_numpy()].sum(axis=0) for c in sorted(d.iso3.unique())]);cov=inv@(S.T@S)@inv*G/(G-1)*(n-1)/(n-k);ses=np.sqrt(np.diag(cov));maxscore=float(np.max(np.abs(score.sum(axis=0))))
   stable=fit.converged and not warns and np.isfinite(beta).all() and np.isfinite(ses).all() and (ses>0).all() and max(abs(beta))<25 and maxscore<1e-5
   base['status']='estimated' if stable else 'unstable_withheld'
   audits.append({**record,'across_weight':scheme,'converged':bool(fit.converged),'max_abs_score':maxscore,'max_abs_coefficient':float(max(abs(beta))),'warnings':[str(w.message) for w in warns],'bread_condition_number':float(np.linalg.cond(bread)),'country_cluster_correction':float(G/(G-1)*(n-1)/(n-k))})
   for term in focal:
    row={**base,'term':term}
    if stable:
     j=list(X.columns).index(term);b=float(beta[j]);se=float(ses[j]);crit=t.ppf(.975,G-1);row.update(coefficient=b,standard_error=se,p_value=float(2*t.sf(abs(b/se),G-1)),ci_low=float(b-crit*se),ci_high=float(b+crit*se),unit='one_common_sample_SD' if scale[term]['standardized'] else 'binary_0_to_1')
    results.append(row)
  except Exception as e:
   for term in focal:results.append({**base,'term':term,'status':'fit_failed_withheld'})
   audits.append({**record,'across_weight':scheme,'error':str(e)})
T=pd.DataFrame(results);ok=T.status.eq('estimated');primary=T.specification.eq('primary');T['holm_primary_8_p']=np.nan;T['holm_weighted_matrix_p']=np.nan;T['holm_expanded_matrix_p']=np.nan
if (ok&primary).any():
 principal_p=T.loc[ok&primary,'p_value'].to_numpy();planned_p=np.r_[principal_p,np.ones(8-len(principal_p))]
 T.loc[ok&primary,'holm_primary_8_p']=multipletests(planned_p,method='holm')[1][:len(principal_p)]
if ok.any():T.loc[ok,'holm_weighted_matrix_p']=multipletests(T.loc[ok,'p_value'],method='holm')[1]
old=pd.read_csv(O/'tables/jibs-mechanism-models-all.csv');other=old.loc[old.status.eq('estimated_exploratory'),'p_value'].to_numpy();pvalues=np.r_[T.loc[ok,'p_value'].to_numpy(),other]
if len(pvalues):
 expanded_adj=multipletests(pvalues,method='holm')[1];T.loc[ok,'holm_expanded_matrix_p']=expanded_adj[:ok.sum()]
 ledger=pd.concat([T.loc[ok].assign(model_block='weighted'),old.loc[old.status.eq('estimated_exploratory')].assign(model_block='unweighted')],ignore_index=True)
 ledger['expanded_matrix_Holm_p']=expanded_adj;ledger.to_csv(O/'tables/country-diffusion-expanded-matrix.csv',index=False)
T.to_csv(O/'tables/country-diffusion-weighted-models.csv',index=False);T[primary].to_csv(O/'tables/country-diffusion-primary.csv',index=False);pd.DataFrame(weights).to_csv(O/'tables/country-diffusion-family-weights.csv',index=False);pd.DataFrame(members).to_parquet(O/'audit/weighted-diffusion-row-memberships-local.parquet',index=False)
T[T.specification.eq('status_primary')].to_csv(O/'tables/country-diffusion-adoption-status.csv',index=False)
(O/'audit/weighted-diffusion-diagnostics.json').write_text(json.dumps(audits,indent=2),encoding='utf8')
summary={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'primary_attempted_coefficients':int(primary.sum()),'primary_stable_coefficients':int((primary&ok).sum()),'primary_Holm_below_05':int((T.holm_primary_8_p<.05).sum()),'weighted_attempted_coefficients':len(T),'weighted_stable_coefficients':int(ok.sum()),'weighted_matrix_Holm_below_05':int((T.holm_weighted_matrix_p<.05).sum()),'expanded_matrix_coefficients':len(pvalues),'expanded_matrix_Holm_below_05':int((T.holm_expanded_matrix_p<.05).sum()),'status_counts':T.status.value_counts().to_dict(),'weights':'Equal total likelihood mass per family or baseline sampled adoption-cohort market-cap mass; divided by usable risk-set row count. Weights conditional on observed adoption calendar.','inference':'Explicit country-cluster score sandwich; t reference countries minus one. Collective waves and historical policy-selection errors are not absorbed by this uncertainty measure.'}
(O/'audit/country-diffusion-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary));print(T[primary].to_string(index=False))
summary['expanded_unweighted_Holm_below_05']=int((expanded_adj[int(ok.sum()):]<.05).sum())
summary['status_primary_stable_coefficients']=int((ok&T.specification.eq('status_primary')).sum())
summary['status_primary_expanded_Holm_below_05']=int((T.specification.eq('status_primary')&T.holm_expanded_matrix_p.lt(.05)).sum())
(O/'audit/country-diffusion-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
