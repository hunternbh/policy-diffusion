from pathlib import Path
import sys,json,itertools
sys.path.insert(0,'work/empirical-deps')
import pandas as pd,numpy as np
from scipy.stats import t
from statsmodels.stats.multitest import multipletests
# Recompute the declared main contrasts to preserve shared country covariance.
p=Path(__file__).parent/'liquidity_grid.py';source=p.read_text(encoding='utf8');ns={'__file__':str(p)};exec(compile(source[:source.index('rows=[];familyrows=')],str(p),'exec'),ns)
O=ns['O'];C=ns['c'];primary=pd.read_csv(O/'tables/liquidity-primary.csv');records=[];influences=[];family_stats=[]
for out,window in itertools.product(ns['outcomes'],['first_year','mean_0_2']):
 results=[]
 for fam,ev in C.groupby('regulation_family'):
  fit=ns['estimate_family'](ev,'reviewed_G',window,'gdp_country',False,out,1)
  if fit:
   results.append((fam,fit));se=float(np.linalg.norm(fit['influence']));family_stats.append({'family':fam,'outcome':out,'post_window':window,'estimate':fit['estimate'],'conditional_country_se':se,'ci_low':fit['estimate']-1.96*se,'ci_high':fit['estimate']+1.96*se,'treated_countries':fit['treated_countries'],'comparison_countries':fit['comparison_countries'],'cohorts':fit['cohorts'],'cohort_years':fit['cohort_years'],'cap_mass':fit['cap']})
 pooled={}
 for weight in ['equal_family','baseline_market_cap_family']:
  mass=np.ones(len(results)) if weight=='equal_family' else np.array([v['cap'] for _,v in results]);mass/=mass.sum();estimate=sum(w*v['estimate'] for w,(_,v) in zip(mass,results));inf=sum(w*v['influence'] for w,(_,v) in zip(mass,results));ref=primary[primary.outcome.eq(out)&primary.post_window.eq(window)&primary.family_weight.eq(weight)].iloc[0];assert abs(estimate-ref.estimate)<1e-12;pooled[weight]=(estimate,inf)
  influences.extend({'specification_id':ref.specification_id,'iso3':iso,'country_influence':float(value)} for iso,value in zip(ns['isos'],inf))
 delta=pooled['baseline_market_cap_family'][0]-pooled['equal_family'][0];inf=pooled['baseline_market_cap_family'][1]-pooled['equal_family'][1];records.append({'outcome':out,'post_window':window,**ns['diagnostics'](delta,inf),'comparison':'market_cap_minus_equal_on_identical_family_estimates'})
D=pd.DataFrame(records);D['holm_six_weight_differences_p']=multipletests(D.p_value,method='holm')[1];D.to_csv(O/'tables/formal-weight-differences.csv',index=False);pd.DataFrame(influences).to_parquet(O/'audit/primary-country-influences.parquet',index=False)
pd.DataFrame(family_stats).to_csv(O/'tables/primary-family-estimates.csv',index=False)
# Country-level adaptation of Krueger's level regression, separately labelled.
panel=pd.read_parquet(O/'data/country-year-liquidity.parquet');macro=pd.read_csv(O/'data/macro-country-year.csv');b=pd.read_csv(O/'data/esg-2023-published-sample.csv');b['G']=b.published_G.fillna(9999);market=panel.rename(columns={out+'_equal_company':out for out in ns['outcomes']});market['year']-=1;macro['year']+=1;macro['ln_pc']=np.log(macro.gdp_pc_constant.where(macro.gdp_pc_constant.gt(0)));base=market.merge(b[['iso3','G']],on='iso3',validate='many_to_one').merge(macro[['iso3','year','ln_pc','gdp_growth_pct','trade_gdp_pct','gdp_constant_usd']],on=['iso3','year'],how='left',validate='one_to_one');base=base[base.year.between(2002,2019)].copy();base['post']=base.year.ge(base.G).astype(float);reg=[]
for out,controlled,within in itertools.product(ns['outcomes'],[False,True],['equal_country','gdp_country']):
 fields=[out,'post']+(['ln_pc','gdp_growth_pct','trade_gdp_pct'] if controlled else [])+(['gdp_constant_usd'] if within=='gdp_country' else []);z=base.dropna(subset=fields).copy();X=pd.DataFrame({'intercept':1.,'post':z.post},index=z.index)
 if controlled:
  for col in ['ln_pc','gdp_growth_pct','trade_gdp_pct']:X[col]=(z[col]-z[col].mean())/z[col].std(ddof=0)
 X=pd.concat([X,pd.get_dummies(z.iso3,prefix='C',drop_first=True,dtype=float),pd.get_dummies(z.year,prefix='Y',drop_first=True,dtype=float)],axis=1);xx=X.to_numpy(float);y=z[out].to_numpy(float);w=np.ones(len(z)) if within=='equal_country' else z.gdp_constant_usd.to_numpy(float,copy=True);w/=w.mean();n,k=xx.shape;nc=z.iso3.nunique()
 if np.linalg.matrix_rank(xx)<k:reg.append({'outcome':out,'controlled':controlled,'country_weight':within,'status':'rank_deficient'});continue
 inv=np.linalg.inv(xx.T@(w[:,None]*xx));beta=inv@(xx.T@(w*y));score=xx*(w*(y-xx@beta))[:,None];s=np.stack([score[z.iso3.eq(iso).to_numpy()].sum(axis=0) for iso in z.iso3.unique()]);cov=inv@(s.T@s)@inv*nc/(nc-1)*(n-1)/(n-k);j=list(X.columns).index('post');se=np.sqrt(cov[j,j]);reg.append({'outcome':out,'controlled':controlled,'country_weight':within,'status':'estimated_country_level_adaptation','estimate':float(beta[j]),'standard_error':float(se),'p_value':float(2*t.sf(abs(beta[j]/se),nc-1)),'country_year_rows':n,'countries':nc,'treatment_calendar':'supplied_Krueger_2023_Table_1','outcome_alignment':'liquidity_at_t_plus_1_policy_at_t','fixed_effects':'country_and_year','scope':'Not exact firm-level replication; firm controls and industry-year effects unavailable globally; annual composition may change.'})
T=pd.DataFrame(reg);ok=T.status.eq('estimated_country_level_adaptation');T['holm_12_benchmark_p']=np.nan;T.loc[ok,'holm_12_benchmark_p']=multipletests(T.loc[ok,'p_value'],method='holm')[1];T.to_csv(O/'tables/Krueger-country-regression-benchmark.csv',index=False)
print(json.dumps({'formal_weight_contrasts':len(D),'shared_country_influences_saved':True,'published_ESG_country_regressions':len(T),'benchmark_Holm_below_05':int(T.holm_12_benchmark_p.lt(.05).sum())}))
