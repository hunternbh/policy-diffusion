from pathlib import Path
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion')
for root in [R/'10-public-report/assets',R/'26-adoption-weighting-and-design-audit/2026-10-19/figures']:
 for p in root.glob('audit-*.svg'):p.write_text('\n'.join(line.rstrip() for line in p.read_text(encoding='utf8').splitlines())+'\n',encoding='utf8')
