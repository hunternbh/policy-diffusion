from pathlib import Path
import sys,json,datetime
sys.path.insert(0,'work/empirical-deps')
import pandas as pd,numpy as np
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'26-adoption-weighting-and-design-audit/2026-10-19';P=R/'25-country-level-main-paper/2026-10-19'
F=pd.read_parquet(P/'data/lagged-mechanism-panel.parquet');F['previous_gdp_learning']=F.gdp_learning;C=pd.read_csv(O/'data/reviewed-policy-calendar.csv');N=pd.read_csv(O/'data/network-memberships.csv');macro=pd.read_csv(O/'data/macro-country-year.csv');values=macro.set_index(['iso3','year']).to_dict('index');dates={f:z.set_index('iso3').reviewed_G.to_dict() for f,z in C.groupby('regulation_family')}
benchmark=pd.read_csv(O/'data/esg-2023-published-sample.csv');dates['PUBLISHED_ESG_BENCHMARK']=benchmark.set_index('iso3').published_G.fillna(9999).to_dict()
def network(label,yr=None):
 z=N[N.network.eq(label)]
 if yr is not None:z=z[z.source_year.eq(yr)]
 return {i:g.sort_values('rank').partner.tolist() for i,g in z.groupby('origin')}
geo=network('geographic10');trade={int(y):network('export_pattern',y) for y in N[N.network.eq('export_pattern')].source_year.unique()};lang=network('official_language');legal=network('legal_origin');igo=network('IGO_Jaccard',2000)
def share(peers,when,known_dates,minimum):
 known=[p for p in peers if p in known_dates]
 return (sum(known_dates[p]<=when for p in known)/len(known) if len(known)>=minimum else np.nan,1-len(known)/len(peers) if peers else np.nan)
def learning(iso,when,known_dates,field,minimum):
 peers=geo.get(iso,[])[:10];known=[p for p in peers if p in known_dates]
 if len(peers)!=10 or len(known)<minimum:return np.nan,'history_incomplete'
 adopters=[p for p in known if known_dates[p]<=when];non=[p for p in known if known_dates[p]>when]
 if not adopters:
  return (0.,'no_adopters_zero') if len(known)==10 else (np.nan,'unknown_prevents_zero')
 av=[values.get((p,when),{}).get(field,np.nan) for p in adopters];av=[v for v in av if np.isfinite(v)]
 if len(av)/len(adopters)<.8:return np.nan,'adopter_macro_missing'
 if not non:
  focal=values.get((iso,when),{}).get(field,np.nan)
  return (float(np.median(av)>focal),'all_adopters_vs_focal') if len(known)==10 and np.isfinite(focal) else (np.nan,'all_adopters_incomplete')
 nv=[values.get((p,when),{}).get(field,np.nan) for p in non];nv=[v for v in nv if np.isfinite(v)]
 if len(nv)/len(non)<.8:return np.nan,'nonadopter_macro_missing'
 return float(np.median(av)>np.median(nv)),'adopter_nonadopter_comparison'
records=[]
for row in F.to_dict('records'):
 i=row['iso3'];yr=int(row['year']);known=dates[row['family']];g=int(known[i]);row.update(G=g,first_event=int(yr==g),in_first_event_risk=yr<=g,status_event=np.nan if row['status_history_censored'] else int(yr>=g))
 for name,peers,minimum in [('trade_fixed2000',trade.get(2000,{}).get(i,[]),3),('trade_fixed2000_strict',trade.get(2000,{}).get(i,[]),5),('trade_annual',trade.get(yr-1,{}).get(i,[]) if yr<=2015 else [],3),('language',lang.get(i,[]),3),('legal',legal.get(i,[]),3),('igo',igo.get(i,[]),3)]:row[name],row[name+'_unknown']=share(peers,yr-1,known,minimum)
 for name,field,minimum in [('gdp_learning','gdp_growth_pct',10),('gdp_learning_80pct','gdp_growth_pct',8),('gdppc_learning','gdp_pc_growth_pct',10)]:row[name],row[name+'_case']=learning(i,yr-1,known,field,minimum)
 row['geographic_known_fraction']=sum(p in known for p in geo.get(i,[]))/10 if len(geo.get(i,[]))==10 else np.nan;records.append(row)
F=pd.DataFrame(records);F.to_parquet(O/'data/lagged-mechanism-panel.parquet',index=False)
F.groupby(['family','gdp_learning_case']).size().reset_index(name='rows').to_csv(O/'tables/learning-edge-case-audit.csv',index=False)
summary={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rows':len(F),'countries':int(F.iso3.nunique()),'prior_nonmissing_learning_rows':int(F.previous_gdp_learning.notna().sum()),'corrected_strict_learning_rows':int(F.gdp_learning.notna().sum()),'corrected_80pct_history_rows':int(F.gdp_learning_80pct.notna().sum()),'edge_cases':F.gdp_learning_case.value_counts().to_dict(),'definition':'At t use known peer adoption status and growth at t-1. No adopters =>0 only with all 10 histories known. All 10 adopters => compare median growth with focal growth. Otherwise compare adopter and nonadopter medians. At least 80% macro coverage per group.','reference':'Supplied Koning et al. 2018, learning definition and edge-case notes. Complete histories required for primary; no unknown policy recoded as zero.','emulation_limit':'Language-share proxy, not Berry administrative distance.','source_dates':'Reviewed phase calendar. Published complete-topic ESG benchmark remains separate.'};(O/'audit/JIBS-feature-audit.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary))
