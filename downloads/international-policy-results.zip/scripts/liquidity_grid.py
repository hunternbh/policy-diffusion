"""Declared 1,296-cell country-level specification grid; retain every result."""
import os
for key in ['OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS']:os.environ[key]='1'
from pathlib import Path
import sys,json,itertools,time
sys.path.insert(0,'work/empirical-deps')
import pandas as pd,numpy as np
from statsmodels.stats.multitest import multipletests
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'26-adoption-weighting-and-design-audit/2026-10-19';start=time.time();plan=json.loads((O/'analysis-plan.json').read_text());c=pd.read_csv(O/'data/reviewed-policy-calendar.csv');c.independent=c.independent.astype(str).str.lower().eq('true');d=pd.read_parquet(R/'09-expanded-policy-paper/2026-10-18/data/security-year-liquidity.parquet');q=pd.read_parquet(R/'17-issuer-regulation-expansion/2026-10-19/data/all-annual-company-mapping.parquet');q=q[q.dscompcode.notna()].drop_duplicates(['security_id','year']);assert not q.duplicated(['security_id','year']).any();d=d.merge(q[['security_id','year','dscompcode']],on=['security_id','year'],validate='one_to_one');outcomes=plan['grid']['outcomes'];isos=sorted(d.iso3.unique());idx={c:j for j,c in enumerate(isos)};K=len(isos);M=np.random.default_rng(20261019).choice([-1.,1.],(99999,K));annual={int(y):z.set_index('security_id') for y,z in d.groupby('year')};macro=pd.read_csv(O/'data/macro-country-year.csv').set_index(['iso3','year']);cache={}
def scalar(iso,year,field):
 try:return float(macro.loc[(iso,year),field])
 except KeyError:return np.nan
def panel(g,offset,window):
 key=(g,offset,window)
 if key in cache:return cache[key]
 post={'first_year':[offset],'second_year':[offset+1],'mean_0_2':[offset,offset+1,offset+2]}[window];yrs=[g-1]+[g+e for e in post]
 if any(y not in annual for y in yrs):cache[key]=None;return None
 pre=annual[g-1];chosen=pre[pre.market_cap_usd.gt(0)].reset_index().sort_values(['dscompcode','market_cap_usd','security_id'],ascending=[True,False,True]).drop_duplicates('dscompcode').set_index('security_id');valid=np.ones(len(chosen),bool);values=[]
 for year in yrs:
  a=annual[year].reindex(chosen.index);valid&=a.dscompcode.eq(chosen.dscompcode).to_numpy()&a.iso3.eq(chosen.iso3).to_numpy()&np.isfinite(a[outcomes]).all(axis=1).to_numpy();values.append(a[outcomes].to_numpy(float))
 x=chosen.iloc[np.flatnonzero(valid)];delta=(np.stack(values[1:],axis=1).mean(axis=1)-values[0])[valid];rows=[]
 for iso,ids in x.groupby('iso3').indices.items():
  if len(ids)<30:continue
  pc=scalar(iso,g-1,'gdp_pc_constant');z={'iso3':iso,'country_index':idx[iso],'companies':len(ids),'cap':float(x.iloc[ids].market_cap_usd.sum()),'gdp':scalar(iso,g-1,'gdp_constant_usd'),'ln_pc':np.log(pc) if pc>0 else np.nan,'growth':scalar(iso,g-1,'gdp_growth_pct'),'trade':scalar(iso,g-1,'trade_gdp_pct')}
  z.update({out:float(delta[ids,j].mean()) for j,out in enumerate(outcomes)});rows.append(z)
 result=(pd.DataFrame(rows),g+max(post));cache[key]=result;return result
def estimate_family(ev,calendar,window,country_weight,controlled,out,offset=0,end_limit=2025):
 dates=ev.set_index('iso3')[calendar].to_dict();cohorts=[];family=ev.regulation_family.iloc[0] if len(ev) and 'regulation_family' in ev else 'PUBLISHED_ESG_BENCHMARK'
 for g in sorted(ev.loc[ev[calendar].between(2001,2024 if offset else 2025),calendar].astype(int).unique()):
  p=panel(g,offset,window)
  if p is None:continue
  a,end=p
  if end>end_limit or a.empty:continue
  a=a.copy();a['G']=a.iso3.map(dates);a=a[a.G.eq(g)|a.G.gt(end)].copy()
  if end>=2025:
   for iso,affected in [('USA','BENEFICIAL_OWNERSHIP'),('DEU','SUPPLY_CHAIN')]:
    if family==affected:a=a[~a.iso3.eq(iso)].copy()
  a['T']=a.G.eq(g).astype(float);a['w']=1. if country_weight=='equal_country' else a.gdp if country_weight=='gdp_country' else a.cap
  fields=[out,'w']+(['ln_pc','growth','trade'] if controlled else []);a=a.replace([np.inf,-np.inf],np.nan).dropna(subset=fields);a=a[a.w.gt(0)];tr=a['T'].eq(1);nt=int(tr.sum());nc=int((~tr).sum())
  if nt<1 or nc<3:continue
  X=np.column_stack([np.ones(len(a)),a['T']]+([a.ln_pc,a.growth,a.trade] if controlled else []));weight=a.w.to_numpy(float);weight=weight/weight.mean();y=a[out].to_numpy(float);n,k=X.shape
  if (controlled and n<k+3) or n<=k or np.linalg.matrix_rank(X)<k:continue
  inv=np.linalg.inv(X.T@(weight[:,None]*X));b=inv@(X.T@(weight*y));res=y-X@b;unit=(X@inv[:,1])*weight*res*np.sqrt(n/(n-k));inf=np.zeros(K);inf[a.country_index.astype(int)]=unit
  # Arm-specific finite-country correction matches the unadjusted benchmark.
  if not controlled:
   tm=np.average(y[tr],weights=weight[tr]);cm=np.average(y[~tr],weights=weight[~tr]);inf[:]=0
   for mask,mean,sign in [(tr,tm,1),(~tr,cm,-1)]:
    count=int(mask.sum());corr=np.sqrt(count/(count-1)) if count>1 else 1.;ii=a.loc[mask,'country_index'].astype(int).to_numpy();wa=weight[mask];inf[ii]=sign*wa/wa.sum()*(y[mask]-mean)*corr
  us_real=scalar('USA',g-1,'gdp_constant_usd');us_nominal=scalar('USA',g-1,'gdp_current_usd');factor=us_real/us_nominal if us_real>0 and us_nominal>0 else np.nan
  cohorts.append({'g':g,'estimate':float(b[1]),'influence':inf,'mass':float(a.loc[tr,'w'].sum()),'cap':float(a.loc[tr,'cap'].sum()),'real_cap':float(a.loc[tr,'cap'].sum()*factor),'treated_countries':set(a.loc[tr,'iso3']),'comparison_countries':set(a.loc[~tr,'iso3']),'treated_companies':int(a.loc[tr,'companies'].sum())})
 if not cohorts:return None
 cw=np.array([v['mass'] for v in cohorts]);cw/=cw.sum();return {'estimate':sum(w*v['estimate'] for w,v in zip(cw,cohorts)),'influence':sum(w*v['influence'] for w,v in zip(cw,cohorts)),'cap':sum(v['cap'] for v in cohorts),'real_cap':sum(v['real_cap'] for v in cohorts),'cohorts':len(cohorts),'cohort_years':';'.join(str(v['g']) for v in cohorts),'treated_countries':len(set.union(*(v['treated_countries'] for v in cohorts))),'comparison_countries':len(set.union(*(v['comparison_countries'] for v in cohorts))),'treated_company_cohorts':sum(v['treated_companies'] for v in cohorts)}
def diagnostics(value,inf):
 se=float(np.linalg.norm(inf));p=float((1+(np.abs(M@inf)>=abs(value)).sum())/100000) if se>1e-14 else 1.;return {'estimate':float(value),'conditional_country_se':se,'ci_low':float(value-1.96*se),'ci_high':float(value+1.96*se),'p_value':p}
rows=[];familyrows=[];contributions=[];familycache={};counter=0
for cal,out,within,window,scope,focal,control in itertools.product(plan['grid']['calendars'],outcomes,plan['grid']['country_weights'],plan['grid']['post_windows'],plan['grid']['policy_scopes'],plan['grid']['focal_cases'],plan['grid']['controls']):
 offset=int(cal=='reviewed_following_year_outcome');calendar='inherited_G' if cal=='inherited_phase' else 'reviewed_G';families=sorted(c.regulation_family.unique()) if scope=='all_recorded_families' else plan['public_disclosure_scope'];results=[]
 for fam in families:
  ev=c[c.regulation_family.eq(fam)];ev=ev[ev.independent] if focal=='independent_national_choices' else ev;key=(cal,out,within,window,focal,control,fam)
  if key not in familycache:familycache[key]=estimate_family(ev,calendar,window,within,control!='none',out,offset)
  r=familycache[key]
  if r is not None:results.append((fam,r))
 context={'calendar':cal,'outcome':out,'country_weight':within,'post_window':window,'policy_scope':scope,'focal_cases':focal,'controls':control}
 for across in plan['grid']['family_weights']:
  counter+=1;row={**context,'family_weight':across,'status':'not_estimated_no_supported_family','families':len(results),'specification_id':f'L{counter:04}'}
  if results:
   mass=np.ones(len(results)) if across=='equal_family' else np.array([r['cap'] for _,r in results]);ww=mass/mass.sum();value=sum(w*r['estimate'] for w,(_,r) in zip(ww,results));inf=sum(w*r['influence'] for w,(_,r) in zip(ww,results));row.update(status='estimated_country_exposure',**diagnostics(value,inf),family_names=';'.join(f for f,_ in results),largest_family=results[int(np.argmax(ww))][0],largest_weight=float(max(ww)),effective_families=float(1/sum(ww**2)))
   for w,(fam,r) in zip(ww,results):contributions.append({**context,'family_weight':across,'specification_id':row['specification_id'],'family':fam,'family_weight_value':float(w),'family_estimate':r['estimate'],'weighted_contribution':float(w*r['estimate']),'pre_cap_mass':r['cap'],'constant_dollar_pre_cap_mass':r['real_cap'],'cohorts':r['cohorts'],'cohort_years':r['cohort_years'],'treated_countries':r['treated_countries'],'comparison_countries':r['comparison_countries'],'treated_company_cohorts':r['treated_company_cohorts']})
  rows.append(row)
 if counter%108==0:print(json.dumps({'grid_cells':counter,'family_fits_cached':len(familycache),'seconds':round(time.time()-start)}),flush=True)
family_audit=[]
for (cal,out,within,window,focal,control,fam),fit in familycache.items():
 base={'calendar':cal,'outcome':out,'country_weight':within,'post_window':window,'focal_cases':focal,'controls':control,'family':fam,'status':'estimated' if fit else 'no_supported_cohort_under_declared_rules'}
 if fit:base.update(estimate=fit['estimate'],cohorts=fit['cohorts'],cohort_years=fit['cohort_years'],treated_countries=fit['treated_countries'],comparison_countries=fit['comparison_countries'],pre_cap_mass=fit['cap'])
 family_audit.append(base)
pd.DataFrame(family_audit).to_csv(O/'tables/liquidity-family-fit-ledger.csv',index=False)
T=pd.DataFrame(rows);assert len(T)==1296;ok=T.status.eq('estimated_country_exposure');T['holm_grid_p']=np.nan;T.loc[ok,'holm_grid_p']=multipletests(T.loc[ok,'p_value'],method='holm')[1];T.to_csv(O/'tables/liquidity-specification-grid.csv',index=False);W=pd.DataFrame(contributions);W.to_csv(O/'tables/liquidity-grid-family-contributions.csv',index=False)
primary=T[T.calendar.eq('reviewed_following_year_outcome')&T.country_weight.eq('gdp_country')&T.post_window.isin(['first_year','mean_0_2'])&T.policy_scope.eq('all_recorded_families')&T.focal_cases.eq('all_documented')&T.controls.eq('none')].copy();primary['holm_primary_12_p']=multipletests(primary.p_value,method='holm')[1];primary.to_csv(O/'tables/liquidity-primary.csv',index=False)
# Leave-one-family-out and common-dollar cap normalisation are diagnostics;
# neither changes the declared main family weighting by observed result.
sens=[]
for _,p in primary.iterrows():
 z=W[W.specification_id.eq(p.specification_id)]
 for omit in ['NONE']+list(z.family):
  a=z[z.family.ne(omit)];mass=np.ones(len(a)) if p.family_weight=='equal_family' else a.pre_cap_mass.to_numpy();mass=mass/mass.sum();sens.append({'outcome':p.outcome,'post_window':p.post_window,'family_weight':p.family_weight,'omitted_family':omit,'estimate':float(np.dot(mass,a.family_estimate)),'diagnostic':'leave_one_family_out_not_main_selection'})
 if p.family_weight=='baseline_market_cap_family':
  a=z[z.constant_dollar_pre_cap_mass.notna()];mass=a.constant_dollar_pre_cap_mass/a.constant_dollar_pre_cap_mass.sum();sens.append({'outcome':p.outcome,'post_window':p.post_window,'family_weight':p.family_weight,'omitted_family':'NONE_CONSTANT_DOLLARS','estimate':float(np.dot(mass,a.family_estimate)),'diagnostic':'US_GDP_deflator_proxy_for_common_dollar_pre_cap'})
pd.DataFrame(sens).to_csv(O/'tables/weight-diagnostics.csv',index=False)
# Published complete-topic ESG calendar: separate benchmark, not an extra family.
b=pd.read_csv(O/'data/esg-2023-published-sample.csv');b['reviewed_G']=b.published_G.fillna(9999);bench=[]
for out,within,window in itertools.product(outcomes,['equal_country','gdp_country'],['first_year','mean_0_2']):
 r=estimate_family(b,'reviewed_G',window,within,False,out,offset=1,end_limit=2020)
 bench.append({'outcome':out,'country_weight':within,'post_window':window,'status':'estimated' if r else 'unsupported',**(diagnostics(r['estimate'],r['influence']) if r else {})})
pd.DataFrame(bench).to_csv(O/'tables/published-ESG-country-benchmark.csv',index=False)
summary={'grid_planned':1296,'grid_recorded':len(T),'estimated_grid_cells':int(ok.sum()),'negative_estimates':int((T.estimate.lt(0)&ok).sum()),'positive_estimates':int((T.estimate.gt(0)&ok).sum()),'grid_Holm_below_05':int(T.holm_grid_p.lt(.05).sum()),'country_weight_choices':3,'family_weight_choices':2,'no_sign_selection':True,'family_fit_cache':len(familycache),'elapsed_seconds':time.time()-start,'inference':'Conditional country sampling diagnostics; grid is retrospective and dependent, not 1296 independent confirmations.'};(O/'audit/liquidity-grid-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print(json.dumps(summary));print(primary.to_string(index=False))
