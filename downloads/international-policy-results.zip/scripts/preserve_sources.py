from pathlib import Path
import urllib.request,hashlib,json,datetime,concurrent.futures
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'26-adoption-weighting-and-design-audit/2026-10-19'
sources=[('FRC-extended-audit-2013.html','https://www.frc.org.uk/news-and-events/news/2013/06/frc-issues-revised-auditing-standard-making-auditors-work-more-transparent-to-investors/'),('IRS-country-report-rules.html','https://www.irs.gov/businesses/international-businesses/us-multinational-enterprises'),('OECD-CbCR-implementation-handbook.pdf','https://www.oecd.org/content/dam/oecd/en/topics/policy-sub-issues/cbcr/country-by-country-reporting-handbook-on-effective-implementation.pdf')]
def save(item):
 name,url=item;p=O/'sources'/name
 if not p.exists():
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Research source preservation'}),timeout=45) as f:p.write_bytes(f.read())
 return {'file':name,'url':url,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(save,sources))
(O/'audit/new-source-manifest.json').write_text(json.dumps(rows,indent=2),encoding='utf8');print(json.dumps({'primary_sources_preserved':len(rows)}))
