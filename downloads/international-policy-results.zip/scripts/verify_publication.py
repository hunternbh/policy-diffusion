from pathlib import Path
import json,hashlib,urllib.request,concurrent.futures,datetime,subprocess
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'26-adoption-weighting-and-design-audit/2026-10-19';S=R/'10-public-report';commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip();base='https://hunternbh.github.io/policy-diffusion/'
names=subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',commit],cwd=S,text=True).splitlines();names+=['assets/report.css','assets/registry-only.js','assets/coverage.js','assets/staggered.js','data/coverage/banking-historical-group-roster.json','data/regulations/regulations.json'];names=sorted(set(names))
(O/'audit/publication-file-manifest.json').write_text(json.dumps(names,indent=2),encoding='utf8')
def one(name):
 p=S/name;url=base+name+'?verify='+commit[:12]
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Policy-diffusion-publication-check','Cache-Control':'no-cache'}),timeout=35) as f:b=f.read();status=f.status
  expected=p.read_bytes();istext=p.suffix in ['.json','.csv','.html','.md','.txt','.svg','.css','.js'];equal=b.replace(b'\r\n',b'\n')==expected.replace(b'\r\n',b'\n') if istext else b==expected
  return {'path':name,'HTTP_status':status,'matches_local_content':equal,'remote_sha256':hashlib.sha256(b).hexdigest(),'text_newlines_normalized':istext,'bytes':len(b)}
 except Exception as e:return {'path':name,'error':str(e),'matches_local_content':False}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rows=list(ex.map(one,names))
result={'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commit':commit,'site':base,'anonymous_HTTP_checks':len(rows),'matches':sum(r['matches_local_content'] for r in rows),'checks':rows};(O/'audit/published-verification.json').write_text(json.dumps(result,indent=2),encoding='utf8');print(json.dumps({'checks':len(rows),'matches':result['matches'],'commit':commit,'failures':[r for r in rows if not r['matches_local_content']]}));assert all(r['matches_local_content'] for r in rows)
