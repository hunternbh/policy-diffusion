from pathlib import Path
import sys,json,datetime,shutil
sys.path.insert(0,'work/empirical-deps')
import pandas as pd,numpy as np
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'26-adoption-weighting-and-design-audit/2026-10-19';F=pd.read_parquet(O/'data/lagged-mechanism-panel.parquet');C=pd.read_csv(O/'data/reviewed-policy-calendar.csv');geo=pd.read_excel(R/'21-fresnillo-and-carbon-issuer-review/2026-10-19/sources/dist_cepii.xls');geo=geo[geo.iso_o.ne(geo.iso_d)&geo.distcap.notna()];macro=pd.read_csv(O/'data/macro-country-year.csv').set_index(['iso3','year']);histories={f:z.set_index('iso3').reviewed_G.to_dict() for f,z in C.groupby('regulation_family')};b=pd.read_csv(O/'data/esg-2023-published-sample.csv');histories['PUBLISHED_ESG_BENCHMARK']=b.set_index('iso3').published_G.fillna(9999).to_dict();peers={};records=[]
for family,dates in histories.items():
 for iso,z in geo[geo.iso_d.isin(dates)].groupby('iso_o'):
  near=z.sort_values(['distcap','iso_d']).head(10).iso_d.tolist()
  if len(near)==10:peers[(family,iso)]=near
  records.extend({'family':family,'origin':iso,'partner':p,'rank':j+1,'peer_universe':'documented_policy_histories'} for j,p in enumerate(near))
def value(i,y):
 try:return float(macro.loc[(i,y),'gdp_growth_pct'])
 except KeyError:return np.nan
def learn(f,i,y):
 dates=histories[f];p=peers.get((f,i),[])
 if len(p)<10:return np.nan,'fewer_than_10_documented_peers'
 a=[j for j in p if dates[j]<=y];c=[j for j in p if dates[j]>y]
 if not a:return 0.,'no_adopters_zero'
 av=[value(j,y) for j in a];av=[v for v in av if np.isfinite(v)]
 if len(av)/len(a)<.8:return np.nan,'adopter_macro_missing'
 if not c:
  focal=value(i,y);return (float(np.median(av)>focal),'all_adopters_vs_focal') if np.isfinite(focal) else (np.nan,'focal_growth_missing')
 cv=[value(j,y) for j in c];cv=[v for v in cv if np.isfinite(v)]
 if len(cv)/len(c)<.8:return np.nan,'nonadopter_macro_missing'
 return float(np.median(av)>np.median(cv)),'adopter_nonadopter_comparison'
result=[learn(r.family,r.iso3,int(r.year)-1) for r in F.itertuples()];F['gdp_learning_known_universe']=[r[0] for r in result];F['known_universe_learning_case']=[r[1] for r in result];F.to_parquet(O/'data/lagged-mechanism-panel.parquet',index=False);pd.DataFrame(records).to_csv(O/'tables/known-history-geographic-peers.csv',index=False)
for name in ['JIBS-aligned-diffusion-models.csv','diffusion-primary.csv']:
 if (O/'tables'/name).exists():shutil.copy2(O/'tables'/name,O/'audit'/('strict-world-neighbours-'+name))
audit={'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'known_universe_learning_rows':int(F.gdp_learning_known_universe.notna().sum()),'strict_world_learning_rows':int(F.gdp_learning.notna().sum()),'edge_case_counts':F.known_universe_learning_case.value_counts().to_dict(),'definition':'Ten nearest countries among the family-specific documented-history universe; country of origin excluded. Chosen by distance, never by growth or model coefficients. Histories outside this universe are not imputed.','reason':'Reference-style learning assumes observable peer adoption states. A full-world network mixed observed countries with unknown histories. Both network definitions and the failed strict joint models are retained.','caution':'The register is retrospectively observed and selected. This is a documented-history peer-network adaptation, not a reproduction of the original 168-country IFRS panel.'};(O/'audit/known-history-peer-audit.json').write_text(json.dumps(audit,indent=2),encoding='utf8');print(json.dumps(audit))
