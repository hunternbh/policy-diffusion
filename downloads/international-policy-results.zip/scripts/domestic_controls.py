from pathlib import Path
import sys,json,urllib.request,concurrent.futures,zipfile
sys.path.insert(0,'work/empirical-deps')
import pandas as pd,numpy as np
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'26-adoption-weighting-and-design-audit/2026-10-19';P=R/'06-capital-market-disclosure-research/outputs/research_project'
def fetch(item):
 name,indicator=item;p=O/'sources'/('WDI-'+indicator+'.json');url=f'https://api.worldbank.org/v2/country/all/indicator/{indicator}?date=2000:2025&format=json&per_page=20000'
 try:
  if not p.exists():
   with urllib.request.urlopen(url,timeout=40) as f:p.write_bytes(f.read())
  raw=json.loads(p.read_text(encoding='utf8'));assert isinstance(raw[1],list)
  return name,pd.DataFrame([{'iso3':r['countryiso3code'],'year':int(r['date']),name:r['value']} for r in raw[1] if r['countryiso3code']]),url,None
 except Exception as e:return name,pd.DataFrame(columns=['iso3','year',name]),url,str(e)
items=[('fdi_gdp','BX.KLT.DINV.WD.GD.ZS'),('imports_gdp','NE.IMP.GNFS.ZS'),('reg_quality','GOV_WGI_RQ_EST'),('market_cap_gdp_current','CM.MKT.LCAP.GD.ZS')]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(fetch,items))
macro=pd.read_csv(O/'data/macro-country-year.csv');out=macro[['iso3','year','gdp_growth_pct']].copy()
for name,frame,url,error in results:out=out.merge(frame,on=['iso3','year'],how='left',validate='one_to_one')
cached=pd.read_csv(P/'data/wdi_covariates.csv')[['iso3','year','stock_market_cap_gdp_pct']];out=out.merge(cached,on=['iso3','year'],how='left',validate='one_to_one');out['stock_market_cap_gdp_pct']=out.market_cap_gdp_current.combine_first(out.stock_market_cap_gdp_pct)
cross=pd.read_csv(P/'data/cow_iso_crosswalk.csv').dropna(subset=['ccodecow']);codes=dict(zip(cross.ccodecow.astype(int),cross.ccodealp));base={'AUT','BEL','DNK','FIN','FRA','DEU','GRC','IRL','ITA','LUX','NLD','PRT','ESP','SWE','GBR'};added2004={'CYP','CZE','EST','HUN','LVA','LTU','MLT','POL','SVK','SVN'};parts=[]
with zipfile.ZipFile(P/'sources/networks/cow_trade.zip') as z:
 name=next(n for n in z.namelist() if n.endswith('Dyadic_COW_4.0.csv'))
 for ch in pd.read_csv(z.open(name),usecols=['ccode1','ccode2','year','flow1','flow2'],chunksize=200000):
  ch=ch[ch.year.between(2000,2014)].copy();ch['a']=ch.ccode1.map(codes);ch['b']=ch.ccode2.map(codes);ch=ch.dropna(subset=['a','b'])
  for year,g in ch.groupby('year'):
   eu=base|(added2004 if year>=2004 else set())|({'BGR','ROU'} if year>=2007 else set())|({'HRV'} if year>=2013 else set())
   flows=pd.concat([g[['a','b','flow2']].rename(columns={'a':'iso3','b':'destination','flow2':'exports'}),g[['b','a','flow1']].rename(columns={'b':'iso3','a':'destination','flow1':'exports'})]);flows=flows[flows.exports.ge(0)].copy();flows['EU_exports']=np.where(flows.destination.isin(eu),flows.exports,0.);tot=flows.groupby('iso3')[['exports','EU_exports']].sum();tot['year']=int(year);parts.append(tot.reset_index())
trade=pd.concat(parts).groupby(['iso3','year'])[['exports','EU_exports']].sum().reset_index();trade['eu_export_share']=trade.EU_exports/trade.exports.replace(0,np.nan);out=out.merge(trade[['iso3','year','eu_export_share']],on=['iso3','year'],how='left',validate='one_to_one');out.to_csv(O/'data/JIBS-domestic-controls.csv',index=False)
audit={'sources':[{'variable':name,'url':url,'error':error,'observed_rows':int(out[name].notna().sum())} for name,frame,url,error in results],'EU_exports':'Historical EU membership; usable COW exports to EU divided by usable total exports, years 2000-2014 only. No future filling.','stock_market_cap':'Cached World Bank stock-market-cap/GDP source; missing values are not replaced by zero.','controls':'Lag all six domains: GDP growth, EU export share, FDI/GDP, imports/GDP, regulatory quality, stock market cap/GDP.','complete_rows':int(out[['gdp_growth_pct','eu_export_share','fdi_gdp','imports_gdp','reg_quality','stock_market_cap_gdp_pct']].notna().all(axis=1).sum())};(O/'audit/domestic-control-coverage.json').write_text(json.dumps(audit,indent=2),encoding='utf8');print(json.dumps(audit))
