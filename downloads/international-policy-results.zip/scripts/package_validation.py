from pathlib import Path
import json,shutil,zipfile,hashlib
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'26-adoption-weighting-and-design-audit/2026-10-19';S=R/'10-public-report';H=Path('work/design-audit');pub=S/'data/design-audit'
validation=json.loads((O/'audit/release-validation.json').read_text(encoding='utf8'));assert validation['all_passed']
for name in ['release-validation.json','independent-country-reconstruction.json']:shutil.copy2(O/'audit'/name,pub/name)
for p in H.glob('*.py'):shutil.copy2(p,O/'scripts'/p.name)
with zipfile.ZipFile(S/'downloads/international-policy-results.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(pub.iterdir()):z.write(p,'aggregate/'+p.name)
 for p in sorted((O/'scripts').glob('*.py')):z.write(p,'scripts/'+p.name)
 z.writestr('README.txt','Global country-level study, liquidity then diffusion. All 1296 retrospective liquidity specifications, 5508 attempted family fits and 104 diffusion coefficient attempts are retained. Aggregate family contributions reconstruct pooled point estimates. Independent validation reconstructs 42 raw country adoption cohorts, 39 main family/outcome estimates and a weighted logit with numerical Hessian and country-cluster errors. Full fixed-company reconstruction requires licensed local Datastream observations. No raw company data or company identifiers are included. Run scripts from the task workspace with work/empirical-deps; adapt the absolute project root and preserved source paths to a local installation. This is a retrospective audit, not a prospective preregistration or exact replication of the reference studies.\n')
with zipfile.ZipFile(S/'downloads/international-policy-results.zip') as z:assert z.testzip() is None
(O/'audit/code-manifest.json').write_text(json.dumps([{'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(H.glob('*.py'))],indent=2),encoding='utf8')
print(json.dumps({'public_validation_checks':validation['checks_passed'],'public_aggregate_files':len(list(pub.iterdir()))}))
