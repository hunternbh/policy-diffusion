"""Independent numerical and publication checks of the design audit."""
from pathlib import Path
import sys,json,itertools,hashlib,zipfile
sys.path.insert(0,'work/empirical-deps')
import pandas as pd,numpy as np
from scipy.optimize import root
from scipy.optimize._numdiff import approx_derivative
from scipy.special import expit
from statsmodels.stats.multitest import multipletests
from lxml import html
from pypdf import PdfReader
R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'26-adoption-weighting-and-design-audit/2026-10-19';S=R/'10-public-report';checks=[]
def check(label,value):
 checks.append({'check':label,'passed':bool(value)})
 if not value:raise AssertionError(label)
Q=pd.read_csv(O/'tables/liquidity-primary.csv');T=pd.read_csv(O/'tables/liquidity-specification-grid.csv');W=pd.read_csv(O/'tables/liquidity-grid-family-contributions.csv');C=pd.read_csv(O/'data/reviewed-policy-calendar.csv');P=json.loads((O/'analysis-plan.json').read_text(encoding='utf8'));F=pd.read_csv(O/'tables/primary-family-estimates.csv');D=pd.read_csv(O/'tables/JIBS-aligned-diffusion-models.csv');L=pd.read_csv(O/'tables/liquidity-family-fit-ledger.csv')
keys=['calendar','outcome','country_weight','family_weight','post_window','policy_scope','focal_cases','controls'];axes=['calendars','outcomes','country_weights','family_weights','post_windows','policy_scopes','focal_cases','controls'];expected=set(itertools.product(*[P['grid'][k] for k in axes]));check('all 1296 declared cells, unique and unfiltered',set(T[keys].itertuples(index=False,name=None))==expected and len(T)==1296);check('all attempted family fits retained, including unsupported',len(L)==5508 and L.status.ne('estimated').any());check('both signs retained',T.estimate.lt(0).any() and T.estimate.gt(0).any());check('no duplicate bank phase',C.regulation_family.nunique()==17 and not C.duplicated(['iso3','regulation_family']).any() and not C.regulation_family.isin(['CBCR_BANK_FULL','CBCR_BANK_PARTIAL']).any())
for sid,z in W.groupby('specification_id'):
 r=T[T.specification_id.eq(sid)].iloc[0];check(sid+' normalised positive weights and reconstructed estimate',np.all(z.family_weight_value.gt(0)) and abs(z.family_weight_value.sum()-1)<1e-12 and abs(z.weighted_contribution.sum()-r.estimate)<1e-11)
 if r.family_weight=='equal_family':check(sid+' equal weights',np.max(np.abs(z.family_weight_value-1/len(z)))<1e-12)
 else:check(sid+' cap weights follow positive mass',np.max(np.abs(z.family_weight_value-z.pre_cap_mass/z.pre_cap_mass.sum()))<1e-12)
check('grid Holm uses all 1296 estimates',np.max(np.abs(multipletests(T.p_value,method='holm')[1]-T.holm_grid_p))<1e-12);check('primary tests retained and adjusted together',len(Q)==12 and np.max(np.abs(multipletests(Q.p_value,method='holm')[1]-Q.holm_primary_12_p))<1e-12)
# Rebuild the main GDP-weighted family point estimates directly from raw annual
# rows using independent wide joins and weighted group means, not the estimator.
raw=pd.read_parquet(R/'09-expanded-policy-paper/2026-10-18/data/security-year-liquidity.parquet');mapping=pd.read_parquet(R/'17-issuer-regulation-expansion/2026-10-19/data/all-annual-company-mapping.parquet');raw=raw.merge(mapping[['security_id','year','dscompcode']].drop_duplicates(['security_id','year']),on=['security_id','year'],validate='one_to_one');outcomes=P['grid']['outcomes'];annual={int(y):z for y,z in raw.groupby('year')};macro=pd.read_csv(O/'data/macro-country-year.csv').set_index(['iso3','year']);cache={};cohortchecks=0
def country_changes(g):
 if g in cache:return cache[g]
 pre=annual[g-1].query('market_cap_usd>0').sort_values(['dscompcode','market_cap_usd','security_id'],ascending=[True,False,True]).drop_duplicates('dscompcode');end=annual[g+1];z=pre.merge(end[['security_id','dscompcode','iso3']+outcomes],on=['security_id','dscompcode','iso3'],suffixes=('_pre','_post'),validate='one_to_one');z=z.replace([np.inf,-np.inf],np.nan).dropna(subset=[c+'_'+s for c in outcomes for s in ['pre','post']]);z=z[z.groupby('iso3').security_id.transform('size').ge(30)]
 for col in outcomes:z[col]=z[col+'_post']-z[col+'_pre']
 a=z.groupby('iso3')[outcomes].mean();a['gdp']=[macro.loc[(i,g-1),'gdp_constant_usd'] if (i,g-1) in macro.index else np.nan for i in a.index];a=a[a.gdp.gt(0)];cache[g]=a;return a
independent=[]
for fam,ev in C.groupby('regulation_family'):
 estimates=[];mass=[]
 for g in sorted(ev.reviewed_G.astype(int).unique()):
  if g<2001 or g>2024:continue
  a=country_changes(g).copy();a['G']=a.index.map(ev.set_index('iso3').reviewed_G);a=a[a.G.eq(g)|a.G.gt(g+1)]
  if g+1>=2025 and fam in ['BENEFICIAL_OWNERSHIP','SUPPLY_CHAIN']:a=a.drop(index='USA' if fam=='BENEFICIAL_OWNERSHIP' else 'DEU',errors='ignore')
  tr=a[a.G.eq(g)];co=a[a.G.gt(g+1)]
  if tr.empty or len(co)<3:continue
  estimates.append(np.average(tr[outcomes],weights=tr.gdp,axis=0)-np.average(co[outcomes],weights=co.gdp,axis=0));mass.append(tr.gdp.sum());cohortchecks+=1
 if mass:
  fit=np.average(estimates,weights=mass,axis=0)
  for col,value in zip(outcomes,fit):
   r=F[F.family.eq(fam)&F.outcome.eq(col)&F.post_window.eq('first_year')].iloc[0];check(fam+' '+col+' independently rebuilt from raw country changes',abs(r.estimate-value)<1e-10);independent.append({'family':fam,'outcome':col,'independent_point_estimate':float(value)})
check('all 13 supported main families independently reconstructed',len(independent)==39)
# Reconstruct learning directly from saved peer lists, including none/all edges.
features=pd.read_parquet(O/'data/lagged-mechanism-panel.parquet');peers=pd.read_csv(O/'tables/known-history-geographic-peers.csv');pn={(f,i):z.sort_values('rank').partner.tolist() for (f,i),z in peers.groupby(['family','origin'])};calendar={f:z.set_index('iso3').reviewed_G.to_dict() for f,z in C.groupby('regulation_family')};count=0
for case in ['no_adopters_zero','all_adopters_vs_focal','adopter_nonadopter_comparison']:
 sample=features[features.family.isin(calendar)&features.known_universe_learning_case.eq(case)].head(25)
 for r in sample.itertuples():
  pp=pn[(r.family,r.iso3)];year=int(r.year)-1;aa=[i for i in pp if calendar[r.family][i]<=year];bb=[i for i in pp if calendar[r.family][i]>year]
  if not aa:value=0.
  else:
   av=[macro.loc[(i,year),'gdp_growth_pct'] if (i,year) in macro.index else np.nan for i in aa];cv=[macro.loc[(i,year),'gdp_growth_pct'] if (i,year) in macro.index else np.nan for i in bb] if bb else [macro.loc[(r.iso3,year),'gdp_growth_pct']];value=float(np.nanmedian(av)>np.nanmedian(cv))
  check('lagged learning '+case+f' {count}',value==r.gdp_learning_known_universe and r.iso3 not in pp);count+=1
check('annual trade not extrapolated beyond source window',features.loc[features.year.gt(2015),'trade_annual'].isna().all())
for key,z in D.groupby(['specification','term']):
 if len(z)!=2:raise AssertionError('missing paired weight')
 check('paired diffusion sample '+str(key),z.sample_sha256.nunique()==1 and z.rows.nunique()==1)
check('failed and unsupported diffusion attempts retained',len(D)==104 and D.status.eq('unstable_withheld').sum()==4 and D.status.eq('not_estimated_insufficient_support').any());check('unstable fits have no reported coefficient',D.loc[D.status.ne('estimated'),'coefficient'].isna().all())
# Independent weighted logit root and numerical Hessian for the joint model.
features['row_id']=np.arange(len(features));members=pd.read_parquet(O/'audit/JIBS-exact-memberships-local.parquet');fitid='J001_equal_family';m=members[members.fit_id.eq(fitid)];z=m.merge(features,on='row_id',validate='one_to_one');terms=['trade_fixed2000','gdp_learning_known_universe','language','financial_dependence'];xx=np.column_stack([np.ones(len(z)),z.trade_fixed2000/.1,z.gdp_learning_known_universe,z.language/.1,z.financial_dependence,pd.get_dummies(z.family,drop_first=True,dtype=float),pd.get_dummies(z.year,drop_first=True,dtype=float)]);y=z.status_event.to_numpy();w=z.likelihood_weight.to_numpy();score=lambda b:xx.T@(w*(y-expit(xx@b)));start=np.zeros(xx.shape[1]);fit=root(score,start,tol=1e-10);check('independent joint logit stationary point',np.max(abs(score(fit.x)))<1e-8);bread=np.linalg.inv(-approx_derivative(score,fit.x));s=xx*(w*(y-expit(xx@fit.x)))[:,None];clusters=pd.DataFrame(s).assign(iso=z.iso3.to_numpy()).groupby('iso').sum().to_numpy();nc=z.iso3.nunique();n,k=xx.shape;cov=bread@(clusters.T@clusters)@bread.T*nc/(nc-1)*(n-1)/(n-k);se=np.sqrt(np.diag(cov));ref=D[D.fit_id.eq(fitid)].set_index('term')
for j,term in enumerate(terms,1):check('independent logit coefficient and clustered error '+term,abs(ref.loc[term,'coefficient']-fit.x[j])<1e-8 and abs(ref.loc[term,'standard_error']-se[j])<1e-7)
jointfamilies=sorted(z.family.unique());check('one joint family makes both weights identical',len(jointfamilies)==1 and np.max(abs(D[D.specification.eq('primary_joint')&D.family_weight.eq('equal_family')].coefficient.to_numpy()-D[D.specification.eq('primary_joint')&D.family_weight.eq('baseline_market_cap_family')].coefficient.to_numpy()))<1e-12)
doc=json.loads((O/'paper/manuscript-prose.json').read_text(encoding='utf8'));page=html.fromstring((S/'index.html').read_bytes());ids=page.xpath('//@id');check('HTML IDs unique',len(ids)==len(set(ids)));missing=[]
for href in page.xpath('//@href|//@src'):
 if href.startswith(('https:','http:','data:')):continue
 if href.startswith('#'):
  if href[1:] not in ids:missing.append(href)
 else:
  target=href.split('#')[0].split('?')[0]
  if not (S/target).is_file():missing.append(href)
check('all local HTML links and anchors resolve',not missing)
for table,tid in zip(doc['tables'],['family-coverage','main-results','diffusion-results']):
 actual=[[c.text_content().strip().replace('\n','') for c in row.xpath('./td')] for row in page.xpath(f'//table[@id="{tid}"]/tbody/tr')];expected=[[v.replace('\n','') for v in row] for row in table['rows']];check('HTML matches paper '+tid,actual==expected)
publicC=pd.read_csv(S/'data/design-audit/policy-calendar.csv');check('public primary calendar uses reviewed date',np.array_equal(publicC.G,publicC.reviewed_G));check('UK covered period not overwritten',int(publicC.loc[publicC.iso3.eq('GBR')&publicC.regulation_family.eq('AUDIT_REPORTING'),'G'].iloc[0])==2013)
for name in ['liquidity-specification-grid.csv','liquidity-primary.csv','JIBS-aligned-diffusion-models.csv','liquidity-family-fit-ledger.csv']:check('public ledger matches '+name,(O/'tables'/name).read_bytes()==(S/'data/design-audit'/name).read_bytes())
pdf=PdfReader(O/'paper/expanded-policy-paper-draft.pdf');check('concise five-page paper',len(pdf.pages)==5);pdftext='\n'.join(p.extract_text() for p in pdf.pages);check('paper all key tables and both figures',all(s in pdftext for s in ['Table 1.','Table 2.','Table 3.','Figure 1.','Figure 2.','1,296','25 of 31']));check('canonical public PDF matches',hashlib.sha256((S/'downloads/paper.pdf').read_bytes()).hexdigest()==hashlib.sha256((O/'paper/expanded-policy-paper-draft.pdf').read_bytes()).hexdigest())
with zipfile.ZipFile(S/'downloads/international-policy-results.zip') as z:check('package has no raw vendor observations',not any(n.endswith(('.parquet','.sas7bdat')) for n in z.namelist()) and 'aggregate/liquidity-family-fit-ledger.csv' in z.namelist())
result={'checks_passed':len(checks),'all_passed':True,'independent_raw_cohorts':cohortchecks,'independent_main_family_outcome_estimates':len(independent),'independent_learning_rows':count,'joint_model_families':jointfamilies,'independent_logit_estimate_and_numerical_hessian_verified':True,'no_results_filtered_by_sign':True,'checks':checks};(O/'audit/release-validation.json').write_text(json.dumps(result,indent=2),encoding='utf8');(O/'audit/independent-country-reconstruction.json').write_text(json.dumps(independent,indent=2),encoding='utf8');print(json.dumps({k:v for k,v in result.items() if k!='checks'}))
