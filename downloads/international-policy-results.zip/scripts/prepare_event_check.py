from pathlib import Path
import json,shutil
H=Path(__file__).parent;R=Path(r'C:\Users\hia_n\Desktop\policy-diffusion');O=R/'26-adoption-weighting-and-design-audit/2026-10-19';E=O/'event-diagnostics'
for name in ['data','audit','tables']:(E/name).mkdir(parents=True,exist_ok=True)
shutil.copy2(O/'data/macro-country-year.csv',E/'data/macro-country-year.csv');shutil.copy2(O/'data/reviewed-policy-calendar.csv',E/'data/classified-dated-policy-cases.csv')
plan={'outcomes':['log_spread','log_impact','zero_fraction'],'within_family_weights':['gdp_country_allocated'],'across_family_weights':['equal_family','baseline_market_cap_family']};(E/'geographic-analysis-plan.json').write_text(json.dumps(plan),encoding='utf8')
code=(H.parent/'country-main/estimate_countries.py').read_text(encoding='utf8').replace("O=R/'25-country-level-main-paper/2026-10-19'","O=R/'26-adoption-weighting-and-design-audit/2026-10-19/event-diagnostics'")
code=code.replace("['inclusive_first_year','balanced_mean_0_2']","['balanced_mean_0_2']").replace("['baseline','public_availability_plus1','independent_choices_only']","['baseline']").replace('list(range(g-3,g+3))','list(range(g-3,g+4))').replace('[-3,-2,0,1,2]','[-3,-2,0,1,2,3]').replace('(2003,2023)','(2003,2022)').replace("g+(2 if target=='balanced_mean_0_2' else 0)","g+(3 if target=='balanced_mean_0_2' else 0)").replace('post=h>=0','post=h>=1')
code=code.replace("cases.independent=", "cases['G']=cases.reviewed_G;cases.independent=")
(H/'event_diagnostics.py').write_text(code,encoding='utf8')
